<!--start sidebar -->
<aside class="sidebar-wrapper" data-simplebar="true">
    <div class="sidebar-header">
      <div>
        <img src="<?php echo e(asset($websetting->logo)); ?>" class="logo-icon" alt="logo icon">
      </div>
      <div>
        <h4 class="logo-text"><?php echo e($websetting->website_name); ?></h4>
      </div>
      <div class="toggle-icon ms-auto"> <i class="bi bi-list"></i>
      </div>
    </div>
    <!--navigation-->
    <ul class="metismenu" id="menu">

      <li>
        <a href="<?php echo e(route('vendor.dashboard')); ?>">
          <div class="parent-icon"><i class="bi bi-house-fill"></i>
          </div>
          <div class="menu-title">Dashboard</div>
        </a>
      </li>s

      <li class="menu-label">Product Menagement</li>
      <li>
        <a href="javascript:;" class="has-arrow">
          <div class="parent-icon"><i class="bi bi-droplet-fill"></i>
          </div>
          <div class="menu-title"> Self Products</div>
        </a>
        <ul>
          <li> <a href="<?php echo e(route('vendor.product.index')); ?>"><i class="bi bi-circle"></i>Product List</a>
          </li>
          <li> <a href="<?php echo e(route('vendor.product.create')); ?>"><i class="bi bi-circle"></i>Create Product</a>
          </li>
        </ul>
      </li>
      <li>
        <a href="<?php echo e(route('vendor.order.all')); ?>" class="has-arrow">
            <div class="parent-icon"><i class="bi bi-droplet-fill"></i>
            </div>
            <div class="menu-title">Order</div>
          </a>

      </li>


    </ul>
    <!--end navigation-->
 </aside>
 <!--end sidebar -->

 <!--Start Back To Top Button-->
 <a href="javaScript:;" class="back-to-top"><i class='bx bxs-up-arrow-alt'></i></a>
 <!--End Back To Top Button-->
<?php /**PATH D:\local_server\htdocs\dajajah\resources\views/account/layouts/inc/vendor-sidebar.blade.php ENDPATH**/ ?>