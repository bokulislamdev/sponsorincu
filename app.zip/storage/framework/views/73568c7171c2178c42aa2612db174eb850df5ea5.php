 <!--    HEADER SECTION-->
 <header class="py-0 py-md-1 py-lg-3">
  <div class="container">
      <div class="row align-items-center">
          <div class="col-12 col-lg-3 d-lg-none">
              <div class="logo menubar-mobile d-flex justify-content-between align-items-center" onclick="mobileClick()">
                  <div class="logo-image">
                      <a href="#">
                          <img src="<?php echo e(asset('web')); ?>/images/logo/logo.png" alt="">
                      </a>
                  </div>
                  <i class="fa fa-bars d-lg-none"></i>
              </div>
          </div>
          <div class="col-12 d-none d-lg-block">
              <div class="row align-items-center">
                  <div class="col-2">
                      <div class="logo-image">
                          <a href="<?php echo e(route('homepage')); ?>">
                              <img src="<?php echo e(asset('web')); ?>/images/logo/logo.png" alt="">
                          </a>
                      </div>
                  </div>
                  <div class="col-10">
                      <div class="menubar d-flex align-items-center justify-content-between">
                          <ul>
                              <li>
                                  <a href="<?php echo e(route('homepage')); ?>" class="<?php echo e('/' == request()->path() ? 'menu-active' : ''); ?>">
                                      <?php echo app('translator')->get('home.Homepage'); ?>
                                  </a>
                              </li>
                              <li>
                                  <a href="<?php echo e(route('about')); ?>" class="<?php echo e('about' == request()->path() ? 'menu-active' : ''); ?>">
                                      <?php echo app('translator')->get('home.About_Us'); ?>
                                  </a>
                              </li>
                              <li>
                                  <a href="<?php echo e(route('services')); ?>" class="<?php echo e('services' == request()->path() ? 'menu-active' : ''); ?>">
                                      <?php echo app('translator')->get('home.Our_Services'); ?>
                                  </a>
                              </li>
                              <li>
                                  <a href="<?php echo e(route('awareness')); ?>" class="<?php echo e('awareness' == request()->path() ? 'menu-active' : ''); ?>">
                                      <?php echo app('translator')->get('home.Awareness'); ?>
                                  </a>
                              </li>
                              <li>
                                  <a href="<?php echo e(route('partner')); ?>" class="<?php echo e('partner' == request()->path() ? 'menu-active' : ''); ?>">
                                      <?php echo app('translator')->get('home.Our_partners'); ?>
                                  </a>
                              </li>
                              <li>
                                  <a href="<?php echo e(route('traning')); ?>" class="<?php echo e('traning' == request()->path() ? 'menu-active' : ''); ?>">
                                      <?php echo app('translator')->get('home.Training'); ?>
                                  </a>
                              </li>
                              <li>
                                  <a href="<?php echo e(route('contact')); ?>" class="<?php echo e('contact' == request()->path() ? 'menu-active' : ''); ?>">
                                      <?php echo app('translator')->get('home.Contact_Us'); ?>
                                  </a>
                              </li>

                              <li class="sub-btn no-border">
                                <a class="no-border <?php echo e('register' == request()->path() || 'login' == request()->path() ? 'menu-active' : ''); ?>" href="javascript:void(0)"><?php echo app('translator')->get('home.Accounts'); ?> 
                                    <i data-feather="chevron-down"></i>
                                </a>
                                <div class="sub-menu">
                                  <?php if(auth()->guard()->check()): ?>
          
                                    <?php if(Auth::user()->role == 1): ?>
                                    <a href="<?php echo e(route('dashboard')); ?>"><?php echo app('translator')->get('home.Dashboard'); ?></a>
                                    <?php elseif(Auth::user()->role == 3): ?>
                                    <a href="<?php echo e(route('admin.dashboard')); ?>"><?php echo app('translator')->get('home.Dashboard'); ?></a>
                                    <?php endif; ?>
          
                                    <a href="javascript:void(0)">
                                      <form action="<?php echo e(route('logout')); ?>" method="post">
                                        <?php echo csrf_field(); ?>
                                          <button type="submit" style="background: none"> <?php echo app('translator')->get('home.Logout'); ?> </button>
                                      </form>
                                  </a>
          
                                  <?php endif; ?>
          
                                  <?php if(auth()->guard()->guest()): ?>
                                    <a href="<?php echo e(route('register')); ?>"><?php echo app('translator')->get('home.Signup'); ?></a>
                                    <a href="<?php echo e(route('login')); ?>"><?php echo app('translator')->get('home.Sign_In'); ?></a>
                                  <?php endif; ?>
          
          
                                    
          
                                </div>
                              </li>

                          </ul>
                          <ul>
                              <li>
                                <?php if($locale == 'en'): ?>
                                <a  class="no-border head-lang-button" href="<?php echo e(request()->fullUrlWithQuery(['lang' => 'ar'])); ?>">Arabic</a>
                                <?php elseif($locale == 'ar'): ?>
                                <a  class="no-border head-lang-button" href="<?php echo e(request()->fullUrlWithQuery(['lang' => 'en'])); ?>">English</a>
                                <?php endif; ?>
                                  
                              </li>
                              
                          </ul>
                      </div>
                  </div>
              </div>
          </div>
      </div>
  </div>
</header>
<!--    HEADER SECTION END-->

<!--    MOBILE MENU-->
<div id="mobile-menu" class="mobile-menu">
  <!-- accordion-->
  <div class="accordion accordion-flush" id="accordionFlushExample">

      <div class="mobile-logo mb-3">
          <a href="<?php echo e(route('homepage')); ?>">
              <img src="<?php echo e(asset('web')); ?>/images/logo/logo.png" alt="mobile-logo">
          </a>
          <i id="mobile-cross" class="fa fa-times" onClick="mobileClick()"></i>
      </div>



      


      <div class="accordion-item custom ">
          <h2 class="accordion-header" id="flush-headingThree">
              <a href="<?php echo e(route('homepage')); ?>">
                  <button class="accordion-button custom collapsed none" type="button">
                      <?php echo app('translator')->get('home.Homepage'); ?>
                  </button>
              </a>
          </h2>
      </div>
      <div class="accordion-item custom">
          <h2 class="accordion-header" id="flush-headingThree">
              <a href="<?php echo e(route('about')); ?>">
                  <button class="accordion-button custom collapsed none" type="button">
                      <?php echo app('translator')->get('home.About_Us'); ?>
                  </button>
              </a>
          </h2>
      </div>
      <div class="accordion-item custom">
          <h2 class="accordion-header" id="flush-headingThree">
              <a href="<?php echo e(route('services')); ?>">
                  <button class="accordion-button custom collapsed none" type="button">
                      <?php echo app('translator')->get('home.Our_Services'); ?>
                  </button>
              </a>
          </h2>
      </div>

      <div class="accordion-item custom">
          <h2 class="accordion-header" id="flush-headingThree">
              <a href="<?php echo e(route('awareness')); ?>">
                  <button class="accordion-button custom collapsed none" type="button">
                    <?php echo app('translator')->get('home.Awareness'); ?>
                  </button>
              </a>
          </h2>
      </div>
      
      <div class="accordion-item custom">
          <h2 class="accordion-header" id="flush-headingThree">
              <a href="<?php echo e(route('partner')); ?>">
                  <button class="accordion-button custom collapsed none" type="button">
                    <?php echo app('translator')->get('home.Our_partners'); ?>
                  </button>
              </a>
          </h2>
      </div>
    <div class="accordion-item custom">
          <h2 class="accordion-header" id="flush-headingThree">
              <a href="<?php echo e(route('traning')); ?>">
                  <button class="accordion-button custom collapsed none" type="button">
                    <?php echo app('translator')->get('home.Training'); ?>
                  </button>
              </a>
          </h2>
      </div>
      
      <div class="accordion-item custom">
          <h2 class="accordion-header" id="flush-headingThree">
              <a href="<?php echo e(route('contact')); ?>">
                  <button class="accordion-button custom collapsed none" type="button">
                    <?php echo app('translator')->get('home.Contact_Us'); ?>
                  </button>
              </a>
          </h2>
      </div>

      <div class="accordion-item">
        <h2 class="accordion-header" id="flush-headingTwo">
            <button class="accordion-button custom collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#two" aria-expanded="false" aria-controls="flush-collapseTwo">
                <?php echo app('translator')->get('home.Accounts'); ?>
            </button>
        </h2>
        <div id="two" class="accordion-collapse collapse" aria-labelledby="two" data-bs-parent="#accordionFlushExample">
            <div class="accordion-body custom">
                <ul>
                    <?php if(auth()->guard()->guest()): ?>
                    <li><a href="<?php echo e(route('login')); ?>"><i class="fa fa-chevron-right"></i><?php echo app('translator')->get('home.Login'); ?></a></li>
                    <li><a href="<?php echo e(route('register')); ?>"><i class="fa fa-chevron-right"></i><?php echo app('translator')->get('home.Signup'); ?></a></li>
                    <?php endif; ?>
                    <?php if(auth()->guard()->check()): ?>

                    <?php if(Auth::user()->role == 1): ?>
                    <li>
                        
                        <a href="<?php echo e(route('admin.dashboard')); ?>">
                            <i class="fa fa-chevron-right"></i>
                            <?php echo app('translator')->get('home.Dashboard'); ?>
                        </a>
                    </li>
                    <?php elseif(Auth::user()->role == 3): ?>
                    <li>
                        <a href="<?php echo e(route('user.dashboard')); ?>">
                            <i class="fa fa-chevron-right"></i>
                            <?php echo app('translator')->get('home.Dashboard'); ?>
                        </a>
                    </li>
                    <?php endif; ?>

                    <li class="d-flex"><a href="javascript:void(0)">
                        <form action="<?php echo e(route('logout')); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <i class="fa fa-chevron-right"></i>
                            <button type="submit" style="background:none"> <?php echo app('translator')->get('home.Logout'); ?></button>
                        </form>
                    </a></li>
                    <?php endif; ?>
                </ul>
            </div>
        </div>
    </div>

    <div class="accordion-item custom">
        <h2 class="accordion-header" id="flush-headingThree">
            <?php if($locale == 'en'): ?>
            <a href="<?php echo e(request()->fullUrlWithQuery(['lang' => 'ar'])); ?>">
                <button class="accordion-button custom collapsed none" type="button">
                    Arabic
                </button>
            </a>
            <?php elseif($locale == 'ar'): ?>
            <a href="<?php echo e(request()->fullUrlWithQuery(['lang' => 'en'])); ?>">
                <button class="accordion-button custom collapsed none" type="button">
                    English
                </button>
            </a>
            <?php endif; ?>
        </h2>
    </div>


  </div>

</div>
<div id="mobileOverlay" class="mobile-overlay" onClick="mobileClick()"></div>
<!--    MOBILE MENU END--><?php /**PATH D:\local_server\htdocs\blaghat\resources\views/web/layouts/inc/header.blade.php ENDPATH**/ ?>