

<?php $__env->startSection('content'); ?>
	       <!--start content-->
           <main class="page-content">

            <!--breadcrumb-->
            <div class="page-breadcrumb d-none d-sm-flex align-items-center">
              <div class="breadcrumb-title pe-3 text-white">Pages</div>
              <div class="ps-3">
                <nav aria-label="breadcrumb">
                  <ol class="breadcrumb mb-0 p-0">
                    <li class="breadcrumb-item"><a href="javascript:;"><i class="bx bx-home-alt text-white"></i></a>
                    </li>
                    <li class="breadcrumb-item active text-white" aria-current="page">Edit User Profile</li>
                  </ol>
                </nav>
              </div>
              <div class="ms-auto">
                
                    <a href="<?php echo e(route('account.profile.index')); ?>" class="btn btn-success px-5 radius-30"><i class="fadeIn animated bx bx-user" style="margin-right: 8px;"></i>Profile</a>
                
                
              </div>
            </div>
            <!--end breadcrumb-->
           
            <div class="profile-cover bg-dark"></div>

            <div class="row">
              <div class="col-12 col-lg-8 m-auto">
                <div class="card shadow-sm border-0">
                  <div class="card-body">
                      <h5 class="mb-0">My Account</h5>
                      <hr>
                      
                      <div class="card shadow-none border">
                        <div class="card-header">
                          <h6 class="mb-0">USER INFORMATION</h6>
                        </div>
                        <div class="card-body">
                          <form class="row g-3" action="<?php echo e(route('account.profile.update',$profile->id)); ?>" method="POST" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('put'); ?>
                            <div class="col-6">
                                <label class="form-label">Username <span class="text-danger">*</span></label>
                                <input type="text" class="form-control" value="<?php echo e($profile->username); ?>" name="username">
                                <span class="text-danger"><?php echo e($errors->first('username')); ?></span>
                             </div>
                             <div class="col-6">
                              <label class="form-label">Full Name <span class="text-danger">*</span></label>
                              <input type="text" class="form-control" value="<?php echo e($profile->name); ?>" name="name">
                              <span class="text-danger"><?php echo e($errors->first('name')); ?></span>
                            </div>
                            <div class="col-6">
                                <label class="form-label">Email <span class="text-danger">*</span></label>
                                <input type="text" class="form-control" value="<?php echo e($profile->email); ?>" name="email">
                                <span class="text-danger"><?php echo e($errors->first('email')); ?></span>
                             </div>
                             <div class="col-6">
                              <label class="form-label">Phone</label>
                              <input type="text" class="form-control" value="<?php echo e($profile->phone); ?>" name="phone">
                            </div>
                           
                             <div class="col-6">
                                <label class="form-label">City</label>
                                <input type="text" class="form-control" value="<?php echo e($profile->city); ?>" name="city">
                             </div>
                             <div class="col-6">
                              <label class="form-label">Country</label>
                              <input type="text" class="form-control" value="<?php echo e($profile->country); ?>" name="country">
                            </div>
                            <div class="col-12">
                                <label class="form-label">Address</label>
                                <input type="text" class="form-control" value="<?php echo e($profile->address); ?>" name="address">
                            </div>
                            <div class="col-6">
                                <label class="form-label">
                                    <img src="<?php echo e(asset($profile->image ? $profile->image : 'uploads/userprofile/default.png')); ?>" alt="Profile Photo" style="width: 100px;">
                                </label>
                             </div>
                             <div class="col-6">
                              <label class="form-label">Profile Photo</label>
                              <input type="file" class="form-control" name="image">
                            </div>

                            <div class="text-end">
                                <button type="submit" class="btn btn-primary px-4">Save Changes</button>
                              </div>
                          </form>
                        </div>
                      </div>
                      
                  </div>
                </div>
              </div>

            </div>
            <!--end row-->

          </main>
       <!--end page main-->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('account.layouts.app',['title' => 'Edit User Profile'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\halalincu\resources\views/account/profile/edit.blade.php ENDPATH**/ ?>