

<link href="https://cdn.jsdelivr.net/npm/summernote@0.8.18/dist/summernote.min.css" rel="stylesheet">
<link rel="stylesheet" href="https://cdn.bootcss.com/toastr.js/latest/css/toastr.min.css"/><?php /**PATH D:\local_server\htdocs\disclea\resources\views/web/layouts/inc/css-default.blade.php ENDPATH**/ ?>