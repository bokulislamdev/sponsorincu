


<?php $__env->startSection('content'); ?>

<main class="full-body">

    <section class="project-slider-section section">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12">
                    <div class="project-heading">
                        <h1><?php echo app('translator')->get('home.Our_methodology'); ?></h1>
                        <hr>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- ==========================================================================
PROJECT-SLIDER SECTION END
==========================================================================  -->




    <!-- ==========================================================================
PROJECT SERVICES SECTION START
==========================================================================  -->
    <section class="project-incubator-platform">
        <div class="container">
            <div class="project-incubator-heading">
                <h1><?php echo app('translator')->get('home.Our_projects_are_in_line'); ?></span></h1>
            </div>

            <div class="row">
                <div class="project-custom">
                    <div class="card card-lead h-100">
                        <div class="card-body proud-content">
                            <p class="card-text">
                                <?php echo app('translator')->get('home.Our_projects_are_in_line_li1'); ?>
                            </p>
                        </div>
                    </div>
                </div>

                <div class="project-custom">
                    <div class="card card-lead h-100">
                        <div class="card-body proud-content">
                            <p class="card-text">
                                <?php echo app('translator')->get('home.Our_projects_are_in_line_li2'); ?>
                               
                            </p>
                        </div>
                    </div>
                </div>
                <div class="project-custom">
                    <div class="card card-lead h-100">
                        <div class="card-body proud-content">
                            <p class="card-text">
                                <?php echo app('translator')->get('home.Our_projects_are_in_line_li3'); ?>
                            </p>
                        </div>
                    </div>
                </div>

                <div class="project-custom">
                    <div class="card card-lead h-100">
                        <div class="card-body proud-content">
                            <p class="card-text"><?php echo app('translator')->get('home.Our_projects_are_in_line_li4'); ?>
                            </p>
                        </div>
                    </div>
                </div>

                <div class="project-custom">
                    <div class="card card-lead h-100">
                        <div class="card-body proud-content">
                            <p class="card-text"><?php echo app('translator')->get('home.Our_projects_are_in_line_li5'); ?>
                            </p>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </section>

    <!-- ==========================================================================
PROJECT SERVICES SECTION  END
==========================================================================  -->







    <!-- ==========================================================================
            PROJECT PROMOTION SECTION START
==========================================================================  -->

    <section class="solution-center-advisement">
        <div class="container">
            <div class="promotion-heading">
                <h1>
                    <?php echo app('translator')->get('home.Promotion_of_memberships'); ?>
                </h1>
            </div>

            <div class="row">
                <div class="col-lg-6 col-md-6 col-sm-12">
                    <div class="advisement-desc">
                        <ul>
                            <li>
                                <span class="adv-number">01</span>
                                <?php echo app('translator')->get('home.Promotion_of_memberships_li1'); ?>
                            </li>

                            <li>
                                <span class="adv-number">03</span>
                                <?php echo app('translator')->get('home.Promotion_of_memberships_li3'); ?>
                            </li>

                            <li>
                                <span class="adv-number">05</span>
                                <?php echo app('translator')->get('home.Promotion_of_memberships_li5'); ?>
                            </li>

                            <li>
                                <span class="adv-number">07</span>
                                <?php echo app('translator')->get('home.Promotion_of_memberships_li8'); ?>
                            </li>

                        </ul>
                    </div>
                </div>


                <div class="col-lg-6 col-md-6 col-sm-12">
                    <div class="advisement-desc">
                        <ul>
                            <li>
                                <span class="adv-number">02</span>
                                <?php echo app('translator')->get('home.Promotion_of_memberships_li2'); ?>
                            </li>

                            <li>
                                <span class="adv-number">04</span>
                                <?php echo app('translator')->get('home.Promotion_of_memberships_li4'); ?>
                            </li>

                            <li>
                                <span class="adv-number">06</span>
                                <?php echo app('translator')->get('home.Promotion_of_memberships_li6'); ?>
                                <?php echo app('translator')->get('home.Promotion_of_memberships_li7'); ?>

                            </li>

                            <li>
                                <span class="adv-number">08</span>
                                <?php echo app('translator')->get('home.Promotion_of_memberships_li9'); ?>
                            </li>

                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </section>


    <!-- ==========================================================================
    PROJECT PROMOTION SECTION END
==========================================================================  -->



    <!-- ==========================================================================
PROJECT SERVICES SECTION START
==========================================================================  -->
    <section class="project-incubator-platform">
        <div class="container">
            <div class="project-incubator-heading">
                <h1><?php echo app('translator')->get('home.Attracting_global_leaders'); ?> </h1>
            </div>

            <div class="row">
                <div class="col-lg-3 col-md-6 col-sm-12 pb-4">
                    <div class="card card-lead h-100">
                        <div class="card-body proud-content">
                            <p class="card-text"><?php echo app('translator')->get('home.Attracting_global_leaders_li1'); ?>
                            </p>
                        </div>
                    </div>
                </div>

                <div class="col-lg-3 col-md-6 col-sm-12 pb-4">
                    <div class="card card-lead h-100">
                        <div class="card-body proud-content">
                            <p class="card-text"><?php echo app('translator')->get('home.Attracting_global_leaders_li2'); ?>

                            </p>
                        </div>
                    </div>
                </div>

                <div class="col-lg-3 col-md-6 col-sm-12 pb-4">
                    <div class="card card-lead h-100">
                        <div class="card-body proud-content">
                            <p class="card-text"><?php echo app('translator')->get('home.Attracting_global_leaders_li3'); ?>
                            </p>
                        </div>
                    </div>
                </div>

                <div class="col-lg-3 col-md-6 col-sm-12 pb-4">
                    <div class="card card-lead h-100">
                        <div class="card-body proud-content">
                            <p class="card-text"><?php echo app('translator')->get('home.Attracting_global_leaders_li4'); ?>
                        </div>
                    </div>
                </div>

                


                <div class="col-lg-3 col-md-6 col-sm-12 pb-4">
                    <div class="card card-lead h-100">
                        <div class="card-body proud-content">
                            <p class="card-text"><?php echo app('translator')->get('home.Attracting_global_leaders_li6'); ?>
                            </p>
                        </div>
                    </div>
                </div>


                <div class="col-lg-3 col-md-6 col-sm-12 pb-4">
                    <div class="card card-lead h-100">
                        <div class="card-body proud-content">
                            <p class="card-text"><?php echo app('translator')->get('home.Attracting_global_leaders_li7'); ?>
                            </p>
                        </div>
                    </div>
                </div>


                <div class="col-lg-3 col-md-6 col-sm-12 pb-4">
                    <div class="card card-lead h-100">
                        <div class="card-body proud-content">
                            <p class="card-text"><?php echo app('translator')->get('home.Attracting_global_leaders_li8'); ?>

                            </p>
                        </div>
                    </div>
                </div>



                <div class="col-lg-3 col-md-6 col-sm-12 pb-4">
                    <div class="card card-lead h-100">
                        <div class="card-body proud-content">
                            <p class="card-text"><?php echo app('translator')->get('home.Attracting_global_leaders_li9'); ?>
                            </p>
                        </div>
                    </div>
                </div>

                

                <div class="col-lg-3 col-md-6 col-sm-12 pb-4">
                    <div class="card card-lead h-100">
                        <div class="card-body proud-content">
                            <p class="card-text"><?php echo app('translator')->get('home.Attracting_global_leaders_li11'); ?>
                            </p>
                        </div>
                    </div>
                </div>

                <div class="col-lg-3 col-md-6 col-sm-12 pb-4">
                    <div class="card card-lead h-100">
                        <div class="card-body proud-content">
                            <p class="card-text"><?php echo app('translator')->get('home.Attracting_global_leaders_li12'); ?>
                            </p>
                        </div>
                    </div>
                </div>



            </div>
        </div>
    </section>

    <!-- ==========================================================================
PROJECT SERVICES SECTION  END
==========================================================================  -->


    <!-- ==========================================================================
            PROJECT PROJECT ELECTRONIC PLATFORM SECTION START
==========================================================================  -->

    <section class="solution-center-advisement">
        <div class="container">
            <div class="promotion-heading">
                <h1><?php echo app('translator')->get('home.An_electronic_platform'); ?></h1>
            </div>

            <div class="row">
                <div class="col-lg-6 col-md-6 col-sm-12">
                    <div class="advisement-desc">
                        <ul>
                            <li>
                                <span class="adv-number">01</span>
                                <?php echo app('translator')->get('home.An_electronic_platform_li1'); ?>
                            </li>

                            <li>
                                <span class="adv-number">03</span>
                                <?php echo app('translator')->get('home.An_electronic_platform_li3'); ?>
                            </li>

                            <li>
                                <span class="adv-number">05</span>
                                <?php echo app('translator')->get('home.An_electronic_platform_li5'); ?>
                            </li>

                        </ul>
                    </div>
                </div>


                <div class="col-lg-6 col-md-6 col-sm-12">
                    <div class="advisement-desc">
                        <ul>
                            <li>
                                <span class="adv-number">02</span>
                                <?php echo app('translator')->get('home.An_electronic_platform_li2'); ?>
                            </li>

                            <li>
                                <span class="adv-number">04</span>
                                <?php echo app('translator')->get('home.An_electronic_platform_li4'); ?>
                            </li>

                            <li>
                                <span class="adv-number">06</span>
                                <?php echo app('translator')->get('home.An_electronic_platform_li6'); ?>
                            </li>

                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </section>


    <!-- ==========================================================================
    PROJECT ELECTRONIC PLATFORM SECTION END
==========================================================================  -->


    <!-- ==========================================================================
Encyclopedia of leaders and development leaders SECTION START
==========================================================================  -->
    <section class="project-incubator-platform">
        <div class="container">
            <div class="project-incubator-heading">
                <h1><?php echo app('translator')->get('home.Encyclopedia_of_leaders'); ?> </h1>
                <hr>
            </div>

            <div class="row">
                <div class="col-lg-3 col-md-6 col-sm-12 pb-4">
                    <div class="card card-lead h-100">
                        <div class="card-body proud-content">
                            <p class="card-text"><?php echo app('translator')->get('home.Encyclopedia_of_leaders_li1'); ?>
                            </p>
                        </div>
                    </div>
                </div>

                <div class="col-lg-3 col-md-6 col-sm-12 pb-4">
                    <div class="card card-lead h-100">
                        <div class="card-body proud-content">
                            <p class="card-text"><?php echo app('translator')->get('home.Encyclopedia_of_leaders_li2'); ?>
                            </p>
                        </div>
                    </div>
                </div>

                <div class="col-lg-3 col-md-6 col-sm-12 pb-4">
                    <div class="card card-lead h-100">
                        <div class="card-body proud-content">
                            <p class="card-text"><?php echo app('translator')->get('home.Encyclopedia_of_leaders_li3'); ?>
                            </p>
                        </div>
                    </div>
                </div>

                <div class="col-lg-3 col-md-6 col-sm-12 pb-4">
                    <div class="card card-lead h-100">
                        <div class="card-body proud-content">
                            <p class="card-text"><?php echo app('translator')->get('home.Encyclopedia_of_leaders_li4'); ?>
                            </p>
                        </div>
                    </div>
                </div>

                <div class="col-lg-3 col-md-6 col-sm-12 pb-4">
                    <div class="card card-lead h-100">
                        <div class="card-body proud-content">
                            <p class="card-text"><?php echo app('translator')->get('home.Encyclopedia_of_leaders_li5'); ?>
                            </p>
                        </div>
                    </div>
                </div>


                <div class="col-lg-3 col-md-6 col-sm-12 pb-4">
                    <div class="card card-lead h-100">
                        <div class="card-body proud-content">
                            <p class="card-text"><?php echo app('translator')->get('home.Encyclopedia_of_leaders_li6'); ?>
                            </p>
                        </div>
                    </div>
                </div>


                <div class="col-lg-3 col-md-6 col-sm-12 pb-4">
                    <div class="card card-lead h-100">
                        <div class="card-body proud-content">
                            <p class="card-text"><?php echo app('translator')->get('home.Encyclopedia_of_leaders_li7'); ?>
                            </p>
                        </div>
                    </div>
                </div>


                <div class="col-lg-3 col-md-6 col-sm-12 pb-4">
                    <div class="card card-lead h-100">
                        <div class="card-body proud-content">
                            <p class="card-text"><?php echo app('translator')->get('home.Encyclopedia_of_leaders_li8'); ?>

                            </p>
                        </div>
                    </div>
                </div>



                <div class="col-lg-3 col-md-6 col-sm-12 pb-4">
                    <div class="card card-lead h-100">
                        <div class="card-body proud-content">
                            <p class="card-text"><?php echo app('translator')->get('home.Encyclopedia_of_leaders_li9'); ?>
                            </p>
                        </div>
                    </div>
                </div>

                <div class="col-lg-3 col-md-6 col-sm-12 pb-4">
                    <div class="card card-lead h-100">
                        <div class="card-body proud-content">
                            <p class="card-text"><?php echo app('translator')->get('home.Encyclopedia_of_leaders_li10'); ?>
                            </p>
                        </div>
                    </div>
                </div>

                <div class="col-lg-3 col-md-6 col-sm-12 pb-4">
                    <div class="card card-lead h-100">
                        <div class="card-body proud-content">
                            <p class="card-text"><?php echo app('translator')->get('home.Encyclopedia_of_leaders_li11'); ?>
                            </p>
                        </div>
                    </div>
                </div>

                <div class="col-lg-3 col-md-6 col-sm-12 pb-4">
                    <div class="card card-lead h-100">
                        <div class="card-body proud-content">
                            <p class="card-text"><?php echo app('translator')->get('home.Encyclopedia_of_leaders_li12'); ?>
                            </p>
                        </div>
                    </div>
                </div>

                <div class="col-lg-3 col-md-6 col-sm-12 pb-4">
                    <div class="card card-lead h-100">
                        <div class="card-body proud-content">
                            <p class="card-text"><?php echo app('translator')->get('home.Encyclopedia_of_leaders_li13'); ?>
                            </p>
                        </div>
                    </div>
                </div>

                <div class="col-lg-3 col-md-6 col-sm-12 pb-4">
                    <div class="card card-lead h-100">
                        <div class="card-body proud-content">
                            <p class="card-text"><?php echo app('translator')->get('home.Encyclopedia_of_leaders_li14'); ?>
                            </p>
                        </div>
                    </div>
                </div>

                <div class="col-lg-3 col-md-6 col-sm-12 pb-4">
                    <div class="card card-lead h-100">
                        <div class="card-body proud-content">
                            <p class="card-text"><?php echo app('translator')->get('home.Encyclopedia_of_leaders_li15'); ?>

                            </p>
                        </div>
                    </div>
                </div>

                

                <div class="col-lg-3 col-md-6 col-sm-12 pb-4">
                    <div class="card card-lead h-100">
                        <div class="card-body proud-content">
                            <p class="card-text"><?php echo app('translator')->get('home.Encyclopedia_of_leaders_li17'); ?>
                            </p>
                        </div>
                    </div>
                </div>

                <div class="col-lg-3 col-md-6 col-sm-12 pb-4">
                    <div class="card card-lead h-100">
                        <div class="card-body proud-content">
                            <p class="card-text"><?php echo app('translator')->get('home.Encyclopedia_of_leaders_li18'); ?>
                            </p>
                        </div>
                    </div>
                </div>

                <div class="col-lg-3 col-md-6 col-sm-12 pb-4">
                    <div class="card card-lead h-100">
                        <div class="card-body proud-content">
                            <p class="card-text">
                                <?php echo app('translator')->get('home.An_electronic_platform_li6'); ?>
                            </p>
                        </div>
                    </div>
                </div>

                <div class="col-lg-3 col-md-6 col-sm-12 pb-4">
                    <div class="card card-lead h-100">
                        <div class="card-body proud-content">
                            <p class="card-text"><?php echo app('translator')->get('home.Encyclopedia_of_leaders_li19'); ?>
                            </p>
                        </div>
                    </div>
                </div>



            </div>
        </div>
    </section>

    <!-- ==========================================================================
Encyclopedia of leaders and development leaders SECTION  END
==========================================================================  -->


    <!-- ==========================================================================
            PROJECT INTERNATIONAL SPEAKERS SECTION START
==========================================================================  -->

    <section class="solution-center-advisement">
        <div class="container">
            <div class="promotion-heading">
                <h1><?php echo app('translator')->get('home.Promote_memberships'); ?> </h1>
            </div>

            <div class="row">
                <div class="col-lg-6 col-md-6 col-sm-12">
                    <div class="advisement-desc">
                        <ul>
                            <li>
                                <span class="adv-number">01</span>
                                <?php echo app('translator')->get('home.Promote_memberships_li1'); ?>
                                <?php echo app('translator')->get('home.Promote_memberships_li2'); ?>
                                <?php echo app('translator')->get('home.Promote_memberships_li3'); ?>
                                <?php echo app('translator')->get('home.Promote_memberships_li4'); ?>



                            </li>

                            <li>
                                <span class="adv-number">03</span>
                                <?php echo app('translator')->get('home.Promote_memberships_li6'); ?>
                            </li>


                        </ul>
                    </div>
                </div>


                <div class="col-lg-6 col-md-6 col-sm-12">
                    <div class="advisement-desc">
                        <ul>
                            <li>
                                <span class="adv-number">02</span>
                                <?php echo app('translator')->get('home.Promote_memberships_li5'); ?>
                            </li>

                            <li>
                                <span class="adv-number">04</span>
                                <?php echo app('translator')->get('home.Promote_memberships_li7'); ?>

                            </li>

                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </section>


    <!-- ==========================================================================
    PROJECT INTERNATIONAL SPEAKERS SECTION END
==========================================================================  -->



    <!-- ==========================================================================
            Administrative succession program SECTION START
==========================================================================  -->

    <section class="administrative-succession-section">
        <div class="container">
            <div class="administrative-heading">
                <h1> <?php echo app('translator')->get('home.Administrative_succession_program'); ?> </h1>
                <hr>
            </div>

            <div class="row">
                <div class="col-lg-6 col-md-6 col-sm-12">
                    <div class="administrative-desc">
                        <ul>
                            <li>
                                <span class="adv-number1">01</span>
                                <?php echo app('translator')->get('home.Administrative_succession_program_li1'); ?>


                            </li>

                            <li>
                                <span class="adv-number1">03</span>
                                <?php echo app('translator')->get('home.Administrative_succession_program_li3'); ?>
                            </li>

                            <li>
                                <span class="adv-number1">05</span>
                                <?php echo app('translator')->get('home.Administrative_succession_program_li5'); ?>
                            </li>


                        </ul>
                    </div>
                </div>


                <div class="col-lg-6 col-md-6 col-sm-12">
                    <div class="administrative-desc">
                        <ul>
                            <li>
                                <span class="adv-number1">02</span>
                                <?php echo app('translator')->get('home.Administrative_succession_program_li2'); ?>
                            </li>

                            <li>
                                <span class="adv-number1">04</span>
                                <?php echo app('translator')->get('home.Administrative_succession_program_li4'); ?>
                            </li>

                            <li>
                                <span class="adv-number1">06</span>
                                <?php echo app('translator')->get('home.Administrative_succession_program_li6'); ?>
                            </li>

                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </section>


    <!-- ==========================================================================
    Administrative succession program SECTION END
==========================================================================  -->



    <!-- ==========================================================================
        PROJECT LEADERS CLUB SECTION START
    ==========================================================================  -->

    <section class="administrative-succession-section">
        <div class="container">
            <div class="administrative-heading">
                <h6 style="text-transform: capitalize"> <?php echo app('translator')->get('home.Leaders_Club'); ?></h6>
                <hr>
            </div>

            <div class="row">
                <div class="col-lg-6 col-md-6 col-sm-12">
                    <div class="administrative-desc">
                        <ul>
                            <li>
                                <span class="adv-round"></span>
                                <?php echo app('translator')->get('home.Leaders_Club_li1'); ?>

                            </li>

                            <li>
                                <span class="adv-round"></span>
                                <?php echo app('translator')->get('home.Leaders_Club_li3'); ?>
                            </li>

                         

                            <li>
                                <span class="adv-round"></span>
                                <?php echo app('translator')->get('home.Leaders_Club_li_5'); ?>
                            </li>

                          

                            <li>
                                <span class="adv-round"></span>
                                <?php echo app('translator')->get('home.Leaders_Club_li_7'); ?>
                            </li>

                           

                            <li>
                                <span class="adv-round"></span>
                                <?php echo app('translator')->get('home.Leaders_Club_li_9'); ?>
                            </li>

                            <li>
                                <span class="adv-round"></span>
                                <?php echo app('translator')->get('home.Leaders_Club_li_11'); ?>
                            </li>

                            <li>
                                <span class="adv-round"></span>
                                <?php echo app('translator')->get('home.Leaders_Club_li_13'); ?>
                            </li>

                            
                            <li>
                                <span class="adv-round"></span>
                                <?php echo app('translator')->get('home.Leaders_Club_li_15'); ?>
                            </li>

                            <li>
                                <span class="adv-round"></span>
                                <?php echo app('translator')->get('home.Leaders_Club_li_17'); ?>
                            </li>


                        </ul>
                    </div>
                </div>


                <div class="col-lg-6 col-md-6 col-sm-12">
                    <div class="administrative-desc">
                        <ul>
                            <li>
                                <span class="adv-round"></span>
                                <?php echo app('translator')->get('home.Leaders_Club_li2'); ?>
                            </li>

                            <li>
                                <span class="adv-round"></span>
                                <?php echo app('translator')->get('home.Leaders_Club_li4'); ?>
                            </li>

                            <li>
                                <span class="adv-round"></span>
                                <?php echo app('translator')->get('home.Leaders_Club_li_6'); ?>
                            </li>

                            <li>
                                <span class="adv-round"></span>
                                <?php echo app('translator')->get('home.Leaders_Club_li_8'); ?>
                            </li>
                            <li>
                                <span class="adv-round"></span>
                                <?php echo app('translator')->get('home.Leaders_Club_li_10'); ?>
                            </li>

                           

                            <li>
                                <span class="adv-round"></span>
                                <?php echo app('translator')->get('home.Leaders_Club_li_12'); ?>
                            </li>

                         

                            <li>
                                <span class="adv-round"></span>
                                <?php echo app('translator')->get('home.Leaders_Club_li_14'); ?>
                            </li>


                            <li>
                                <span class="adv-round"></span>
                                <?php echo app('translator')->get('home.Leaders_Club_li_16'); ?>
                            </li>

                          

                            <li>
                                <span class="adv-round"></span>
                               <?php echo app('translator')->get('home.Leaders_Club_li_18'); ?>
                               <br>
                               <?php echo app('translator')->get('home.Leaders_Club_li_19'); ?>

                            </li>

                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </section>


    <!-- ==========================================================================
                PROJECT LEADERS CLUB SECTION END
    ==========================================================================  -->



    <!-- ==========================================================================
                PROJECT RESEARCH AND STUDIES SECTION START
                ==========================================================================  -->

    <section class="administrative-succession-section">
        <div class="container">
            <div class="administrative-heading">
                <h6 style="text-transform: capitalize"> <?php echo app('translator')->get('home.Research_and_studies'); ?></h6>
                <hr>
            </div>

            <div class="row">
                <div class="col-lg-6 col-md-6 col-sm-12">
                    <div class="administrative-desc">
                        <ul>
                            <li>
                                <span class="adv-round"></span>
                                <?php echo app('translator')->get('home.Research_and_studies_li1'); ?>
                            </li>

                            <li>
                                <span class="adv-round"></span>
                                <?php echo app('translator')->get('home.Research_and_studies_li3'); ?>
                            </li>

                            <li>
                                <span class="adv-round"></span>
                                <?php echo app('translator')->get('home.Research_and_studies_li5'); ?>
                            </li>

                            <li>
                                <span class="adv-round"></span>
                                <?php echo app('translator')->get('home.Research_and_studies_li7'); ?>
                            </li>

                            <li>
                                <span class="adv-round"></span>
                                <?php echo app('translator')->get('home.Research_and_studies_li9'); ?>
                            </li>

                        </ul>
                    </div>
                </div>


                <div class="col-lg-6 col-md-6 col-sm-12">
                    <div class="administrative-desc">
                        <ul>
                            <li>
                                <span class="adv-round"></span>
                                <?php echo app('translator')->get('home.Research_and_studies_li2'); ?>
                                
                            </li>

                            <li>
                                <span class="adv-round"></span>
                                <?php echo app('translator')->get('home.Research_and_studies_li4'); ?>
                                
                                
                            </li>

                            <li>
                                <span class="adv-round"></span>
                                <?php echo app('translator')->get('home.Research_and_studies_li6'); ?>
                            </li>

                            <li>
                                <span class="adv-round"></span>
                                <?php echo app('translator')->get('home.Research_and_studies_li8'); ?>
                            </li>

                          

                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </section>


    <!-- ==========================================================================
                            PROJECT RESEARCH AND STUDIES SECTION END
                ==========================================================================  -->



    <!-- =========================================================================
         PROJECT RE-ORIENTATION PROJECT SECTION START
 ==========================================================================  -->

    <section class="administrative-succession-section">
        <div class="container">
            <div class="administrative-heading">
                <h1> <?php echo app('translator')->get('home.Re_orientation'); ?> </h1>
                <h2 style="font-size: 25px; font-weight: 600; margin-bottom: 30px; text-transform:uppercase;"><?php echo app('translator')->get('home.Our_role_is_to'); ?></h2>
            </div>

            <div class="row">
                <div class="col-lg-6 col-md-6 col-sm-12">
                    <div class="administrative-desc">
                        <ul>
                            <li>
                                <span class="adv-round"></span>
                                <?php echo app('translator')->get('home.Re_orientation_li1'); ?>

                            </li>

                            <li>
                                <span class="adv-round"></span>
                                <?php echo app('translator')->get('home.Re_orientation_li2'); ?>
                            </li>

                           

                        </ul>
                    </div>
                </div>


                <div class="col-lg-6 col-md-6 col-sm-12">
                    <div class="administrative-desc">
                        <ul>
                            <li>
                                <span class="adv-round"></span>
                                <?php echo app('translator')->get('home.Re_orientation_li2'); ?>
                            </li>

                        </ul>
                    </div>
                </div>

                <div class="col-12">
                    <div class="administrative-desc">
                        <ul>
                            <li>
                                <span class="adv-round"></span>
                                <?php echo app('translator')->get('home.Re_orientation_li4'); ?>
                                <br>
                                <?php echo app('translator')->get('home.Re_orientation_li5'); ?>
                            </li>

                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </section>


    <!-- ==========================================================================
    PROJECT RE-ORIENTATION PROJECT SECTION END
==========================================================================  -->


    <!-- ==========================================================================
    PROJECT MARKETING FOR INTERNATIONAL SECTION START
==========================================================================  -->

    <section class="solution-center-advisement">
        <div class="container">
            <div class="promotion-heading">
                <h1> <?php echo app('translator')->get('home.Marketing_for_international'); ?> </h1>
            </div>

            <div class="row">
                <div class="col-lg-6 col-md-6 col-sm-12">
                    <div class="advisement-desc">
                        <ul>
                            <li>
                                <span class="adv-number">01</span>
                                <?php echo app('translator')->get('home.Marketing_for_international_li1'); ?>
                            </li>

                            <li>
                                <span class="adv-number">03</span>
                                <?php echo app('translator')->get('home.Marketing_for_international_li3'); ?>
                            </li>

                        </ul>
                    </div>
                </div>


                <div class="col-lg-6 col-md-6 col-sm-12">
                    <div class="advisement-desc">
                        <ul>
                            <li>
                                <span class="adv-number">02</span>
                                <?php echo app('translator')->get('home.Marketing_for_international_li2'); ?>
                            </li>

                            <li>
                                <span class="adv-number">04</span>
                                <?php echo app('translator')->get('home.Marketing_for_international_li4'); ?>
                            </li>

                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </section>


    <!-- ==========================================================================
        PROJECT MARKETING FOR INTERNATIONAL SECTION END
==========================================================================  -->

    <!-- =========================================================================
        PROJECT RE-ORIENTATION PROJECT SECTION START
==========================================================================  -->

    <section class="administrative-succession-section">
        <div class="container">
            <div class="administrative-heading">
                <h6>  <?php echo app('translator')->get('home.Corporate_University'); ?> </h6>
                <hr>
            </div>

            <div class="row">
                <div class="col-lg-6 col-md-6 col-sm-12">
                    <div class="administrative-desc">
                        <ul>
                            <li>
                                <span class="adv-round"></span>
                                <?php echo app('translator')->get('home.Corporate_University_li1'); ?>

                            </li>

                            <li>
                                <span class="adv-round"></span>
                                <?php echo app('translator')->get('home.Corporate_University_li2'); ?>
                            </li>

                            <li>
                                <span class="adv-round"></span>
                                <?php echo app('translator')->get('home.Corporate_University_li3'); ?>
                            </li>

                            <li>
                                <span class="adv-round"></span>
                                <?php echo app('translator')->get('home.Corporate_University_li4'); ?>
                            </li>


                            <li>
                                <span class="adv-round"></span>
                                <?php echo app('translator')->get('home.Corporate_University_li5'); ?>
                            </li>


                            <li>
                                <span class="adv-round"></span>
                                <?php echo app('translator')->get('home.Corporate_University_li6'); ?>
                            </li>


                            <li>
                                <span class="adv-round"></span>
                                <?php echo app('translator')->get('home.Corporate_University_li7'); ?>
                            </li>


                            <li>
                                <span class="adv-round"></span>
                                <?php echo app('translator')->get('home.Corporate_University_li15'); ?>
                                <?php echo app('translator')->get('home.Corporate_University_li16'); ?>

                            </li>


                            <li>
                                <span class="adv-round"></span>
                                <?php echo app('translator')->get('home.Corporate_University_li8'); ?>
                            </li>



                        </ul>
                    </div>
                </div>


                <div class="col-lg-6 col-md-6 col-sm-12">
                    <div class="administrative-desc">
                        <ul>
                            <li>
                                <span class="adv-round"></span>
                                <?php echo app('translator')->get('home.Corporate_University_li9'); ?>
                            </li>

                            <li>
                                <span class="adv-round"></span>
                                <?php echo app('translator')->get('home.Corporate_University_li10'); ?>
                            </li>

                            <li>
                                <span class="adv-round"></span>
                                <?php echo app('translator')->get('home.Corporate_University_li11'); ?>
                            </li>

                            <li>
                                <span class="adv-round"></span>
                                <?php echo app('translator')->get('home.Corporate_University_li12'); ?>
                            </li>

                            <li>
                                <span class="adv-round"></span>
                                <?php echo app('translator')->get('home.Corporate_University_li13'); ?>
                            </li>

                            <li>
                                <span class="adv-round"></span>
                                <?php echo app('translator')->get('home.Corporate_University_li14'); ?>
                            </li>

                            <li>
                                <span class="adv-round"></span>
                                <?php echo app('translator')->get('home.Corporate_University_li17'); ?>
                            </li>

                            <li>
                                <span class="adv-round"></span>
                                <?php echo app('translator')->get('home.Corporate_University_li18'); ?>
                            </li>

                            <li>
                                <span class="adv-round"></span>
                                <?php echo app('translator')->get('home.Corporate_University_li19'); ?>
                            </li>

                            <li>
                                <span class="adv-round"></span>
                                <?php echo app('translator')->get('home.Corporate_University_li20'); ?>
                            </li>

                            <li>
                                <span class="adv-round"></span>
                                <?php echo app('translator')->get('home.Corporate_University_li21'); ?>
                            </li>

                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </section>


    <!-- ==========================================================================
        PROJECT RE-ORIENTATION PROJECT SECTION END
==========================================================================  -->


    <!-- ==========================================================================
PROJECT MARKETING AND LEADERSHIP SECTION START
==========================================================================  -->
    <section class="methodology-build-relation">
        .<div class="container">
            <div class="row">
                <div class="col-lg-6 col-md-6 col-sm-12">
                    <div class="methodology-build-content">
                        <h1><?php echo app('translator')->get('home.Marketing_and_Leadership'); ?></h1>
                        <p>
                            <?php echo app('translator')->get('home.Marketing_and_Leadership_li'); ?>

                        </p>
                    </div>

                    <div class="more-inf0-inner">
                        <button class="btn"><?php echo app('translator')->get('home.For_More_Information'); ?></button>
                    </div>
                </div>

                <div class="col-lg-6 col-md-6 col-sm-12">
                    <div class="methodology-build-image">
                        <img src="<?php echo e(asset('web')); ?>/project/marketing.png" alt="">
                    </div>
                </div>
            </div>
        </div>

    </section>


    <!-- ==========================================================================
PROJECT MARKETING AND LEADERSHIP SECTION END
==========================================================================  -->

<?php echo $__env->make('web.component.subscribe', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>; 




</main>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('web.layouts.app', ['title' => 'Products'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\local_server\htdocs\disclea\resources\views/web/projects.blade.php ENDPATH**/ ?>