<?php $__env->startSection('content'); ?>

          <!--    PAGE TITLE-->
    <section class="page-title py-5" style=" background-image: linear-gradient(rgba(0, 0, 0, 0.4),rgba(0, 0, 0, 0.37)), url(<?php echo e(asset('web')); ?>/images/photos/header-page.png);">
      
        <!--       background-image: linear-gradient(rgba(0, 0, 0, 0.4),rgba(0, 0, 0, 0.37)), url(../images/photos/header-page.png);-->
               
               
                <div class="container">
                    <a href="#">Home</a>
                    <span>></span>
                    <span>About Us</span>
                    <h5>About Us</h5>
                </div>
            </section>
            <!--    PAGE TITLE END-->
        
            <!--    ABOUT-->
            <section class="about-section py-5">
                <div class="container">
                    <div class="row">
                        <h4 class="mb-5">
                            Company Profile
                        </h4>
                        <p>
                            Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam eget efficitur lectus. Morbi faucibus condimentum dui non consequat. Phasellus venenatis eget tortor ut iaculis. Nulla facilisi. Vivamus gravida pharetra ante, ut pharetra augue iaculis sed. Curabitur vitae risus volutpat, ullamcorper dolor non, commodo turpis. Nullam ut est nisl. Fusce hendrerit malesuada elit, et luctus urna maximus non. Cras vitae tincidunt lacus, eu mattis mi. Nulla facilisi. Suspendisse convallis, felis quis vulputate egestas, dui felis convallis neque, quis viverra lacus eros vitae nunc. Pellentesque tincidunt facilisis iaculis. Praesent ipsum turpis, ullamcorper vitae lacus et, efficitur mattis mauris. Curabitur pretium nibh et aliquam aliquam. Sed dignissim ipsum non justo dignissim aliquet. Nulla ac malesuada lectus, condimentum cursus ante.
                        </p>
                        <p>
        
                            Proin nunc nisi, gravida sed malesuada nec, dictum vitae justo. Vestibulum lacinia tellus vitae imperdiet fermentum. Nullam ullamcorper nisl purus. Mauris tincidunt orci mattis semper sollicitudin. Proin viverra quis nibh et consectetur. Fusce hendrerit lectus ac porta eleifend. Pellentesque convallis purus ut tortor accumsan, porttitor posuere odio egestas. Integer quis orci erat. Maecenas placerat, magna vel blandit dictum, arcu lectus suscipit metus, sit amet posuere ex tortor quis ligula. Vivamus congue nisi at lacus luctus, eget imperdiet magna molestie. Nam a sem malesuada, cursus felis nec, congue leo. Pellentesque placerat in sapien sit amet faucibus. Nam vestibulum metus non pulvinar bibendum. Pellentesque malesuada porta fermentum.
                        </p>
                        <div class="about-photo mt-5">
                            <img src="images/photos/about.png" alt="">
                        </div>
                    </div>
        
        
                    <div class="about-gallery mt-5">
                        <h4 class="mb-5">Gallary</h4>
                        <div class="row mt-5">
                            <div class="col-12 col-sm-6 col-md-4 col-lg-3 pb-4">
                                <img src="<?php echo e(asset('web')); ?>/images/photos/about1.png" alt="Gallery Photo">
                            </div>
                             <div class="col-12 col-sm-6 col-md-4 col-lg-3 pb-4">
                                <img src="<?php echo e(asset('web')); ?>/images/photos/about2.png" alt="Gallery Photo">
                            </div>
                             <div class="col-12 col-sm-6 col-md-4 col-lg-3 pb-4">
                                <img src="<?php echo e(asset('web')); ?>/images/photos/about3.png" alt="Gallery Photo">
                            </div>
                             <div class="col-12 col-sm-6 col-md-4 col-lg-3 pb-4">
                                <img src="<?php echo e(asset('web')); ?>/images/photos/about4.png" alt="Gallery Photo">
                            </div>
                        </div>
                    </div>
        
                </div>
            </section>
            <!--    ABOUT END-->
        

<?php $__env->stopSection(); ?>


<?php echo $__env->make('web.layouts.app', ['title' => 'About'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\local_server\htdocs\dajajah\resources\views/web/about.blade.php ENDPATH**/ ?>