    <!--    NOTIFICATION SECTION-->
    <section class="notification-section py-5">
        <div class="container">
            <div class="notify-container py-5 px-3">
                <div class="row align-items-center">
                    <div class="col-12 col-md-6">
                        <div class="notification-left">
                            
                            <p>
                                <?php echo app('translator')->get('home.Get_notified'); ?>
                            </p>
                        </div>
                    </div>
                    <div class="col-12 col-md-6 mt-4 mt-md-0">
                        <div class="notification-right">
                            <div class="noti-form">
                                <form action="<?php echo e(route('subscribe')); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <div class="noti-relative">
                                        <input type="text" placeholder="<?php echo app('translator')->get('home.Email'); ?>" name="email">
                                        <button class="noti-button" type="submit"><?php echo app('translator')->get('home.Subscription'); ?></button>
                                    </div>
                                    <p class="text-danger"><?php echo e($errors->first('email')); ?></p>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--    NOTIFICATION SECTION END--><?php /**PATH D:\local_server\htdocs\sponser\resources\views/web/component/subscribe.blade.php ENDPATH**/ ?>