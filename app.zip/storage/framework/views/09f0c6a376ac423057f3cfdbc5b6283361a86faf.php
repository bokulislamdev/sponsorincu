<!DOCTYPE html>
<html lang="en">


<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo e($title ?? 'page title not set'); ?> - Halalincu </title>
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <!--    BOOSTRAP-->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    

    <!-- FONTAWSOME6 -->
    <link href="https://kit-pro.fontawesome.com/releases/v5.12.1/css/pro.min.css" rel="stylesheet">

    <!--    GOOGLE FONTS-->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link
        href="https://fonts.googleapis.com/css2?family=Josefin+Sans:wght@600&family=Lato:wght@400;700&family=Poppins:wght@700;900&display=swap"
        rel="stylesheet">

    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('web')); ?>/css/slick.css" />
    <link rel="stylesheet" type="text/css" href="<?php echo e('web'); ?>/css/slick-theme.css" />

    <!--    MAIN CSS-->
    <?php echo $__env->make('web.layouts.inc.css-default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <link rel="stylesheet" href="<?php echo e(asset('web')); ?>/css/style.css">
    <link rel="stylesheet" href="<?php echo e(asset('web')); ?>/css/responsive.css">
    


    <?php echo $__env->yieldPushContent('css'); ?>

</head>



<?php echo $__env->make('web.layouts.inc.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<?php echo $__env->yieldContent('content'); ?>



<?php echo $__env->make('web.layouts.inc.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<!--    JQUERY GOOGLE HOST-->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
<!--    BOOSTRAP-->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"
integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>

<!--    SLICK SLIDER-->
<script src="<?php echo e(asset('web')); ?>/js/slick.min.js"></script>

<!--    mix-it-up-->
<script src="<?php echo e(asset('web')); ?>/js/mixitup.min.js"></script>


<?php echo $__env->make('web.layouts.inc.js-default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>






<script>
    //        MOBILE MENU
    function mobileClick() {
        $("#mobile-menu").toggleClass('mobileAdd');
        $("#mobileOverlay").toggleClass('mobile-overlay');
    }
    //        MOBILE MENU END


    $(document).ready(function() {
        var mixer = mixitup(".mixit-js");
    });


    $('.autoplay').slick({
        slidesToShow: 4,
        slidesToScroll: 2,
        // rtl: false,
        autoplay: true,
        autoplaySpeed: 2000,
        dots: false,
        arrows: false,
        nextArrow: $('.nxt'),
        prevArrow: $('.prv'),
        responsive: [{
                breakpoint: 992,
                settings: {
                    slidesToShow: 3,
                    slidesToScroll: 2,
                    infinite: true,
                    dots: true
                }
            },
            {
                breakpoint: 768,
                settings: {
                    slidesToShow: 2,
                    slidesToScroll: 1
                }
            },
            {
                breakpoint: 576,
                settings: {
                    slidesToShow: 1,
                    slidesToScroll: 1
                }
            },
            {
                breakpoint: 350,
                settings: {
                    slidesToShow: 1,
                    slidesToScroll: 1
                }
            }

        ]

    });




    // for order ajax

    $(document).ready(function() {
        showcartcount();
        showcarttable();
        loadtotal();
        loadwishlisttable();
    })


    $(document).on('click', '.product_id', function(e) {
        e.preventDefault();

        var product_id = $(this).data('id');


        // for cart
        $.ajax({
            type: "post",
            url: "<?php echo e(route('product.add_to_cart')); ?>",
            data: {
                product_id: product_id
            },
            success: function(data) {
                showcartcount();
                if ($.isEmptyObject(data.error)) {
                    toastr.success(data.success, 'Product Cart Add Success', {
                        timeOut: 3000
                    });
                } else {
                    toastr.error(data.error, {
                        timeOut: 3000
                    });
                }
            },
            error: function(data) {
                console.log('Error:', data);
            }
        });
    });

    // count show
    function showcartcount() {
        $.ajax({
            url: "<?php echo e(route('product.cart.count.ajax')); ?>",
            success: function(data) {
                loadtotal();
                $('.cart_count').html(data);
            }
        })
    }

    function showcarttable() {
        $.ajax({
            url: "<?php echo e(route('product.cartable.ajax')); ?>",
            success: function(data) {

                $('#carttable').html(data);
                showcartcount();
            },
            error: function(data) {

                console.log('Error:', data);
            }
        })
    }

    function loadtotal() {
        $.ajax({
            url: "<?php echo e(route('product.loadtotal.ajax')); ?>",
            success: function(data) {
                $('#loadtotal').html(data);
            },
            error: function(data) {
                console.log('Error:', data);
            }
        })
    }


    // remove cart
    $(document).on('click', '.removecart', function() {

        var rowId = $(this).data("id")

        const url = "<?php echo e(route('product.remove_cart')); ?>"
        $.ajax({
            type: "post",
            url: url,
            data: {
                rowId
            },
            success: function(data) {
                if ($.isEmptyObject(data.error)) {
                    toastr.success(data.success, 'Product Remove Successfully', {
                        timeOut: 3000
                    });
                } else {
                    toastr.error(data.error, {
                        timeOut: 3000
                    });
                }
                console.log(data)
                showcarttable();
                ticketshowcarttable();

            },
            error: function(data) {
                console.log('Error:', data);
            }
        });
    })




    // increment cart

    // function updateCartQty(id) {

    //     var cart_value = $('.incrementCartVal-'+id).text()
    //     var rowId = id;

    //     const url = "<?php echo e(route('product.incrementCart')); ?>"
    //     $.ajax({
    //         type: "post",
    //         url: url,
    //         data: {
    //             rowId,cart_value
    //         },
    //         success: function(data){
    //             console.log(data)
    //             showcarttable();
    //             showcartsummery();

    //             ticketshowcartsummery();
    //             ticketshowcarttable();

    //         },
    //         error: function(data) {

    //             console.log('Error:', data);
    //         }
    //     });
    // }


    // increment
    $(document).on('click', '.incrementCart', function() {

        var rowId = $(this).data('id')


        var rowId = $(this).data('id')

        const url = "<?php echo e(route('product.incrementCart')); ?>"
        $.ajax({
            type: "post",
            url: url,
            data: {
                rowId
            },
            success: function(data) {
                console.log(data)
                showcarttable();
                ticketshowcarttable();

            },
            error: function(data) {
                console.log('Error:', data);
            }
        });
    })


    // decrement cart
    $(document).on('click', ".decrementCart", function() {
        var rowId = $(this).data('id')
        const url = "<?php echo e(route('product.decrementCart')); ?>"
        $.ajax({
            type: "post",
            url: url,
            data: {
                rowId
            },
            success: function(data) {
                console.log(data)
                showcarttable();
                ticketshowcarttable();
            },
            error: function(data) {
                console.log('Error:', data);
            }
        });
    })

    function clearCart() {

        var url = "<?php echo e(route('product.cart.clean')); ?>"
        $.ajax({
            url: url,
            success: function(data) {
                if ($.isEmptyObject(data.error)) {
                    toastr.success(data.success, 'Product Cart Clean Successfully', {
                        timeOut: 3000
                    });
                } else {
                    toastr.error(data.error, {
                        timeOut: 3000
                    });
                }
                console.log(data)
                showcarttable();
            },
            error: function(data) {
                console.log('Error:', data);
            }
        });
    }



    // wish list
    $(document).on('click', ".wish_cliak", function() {

        var product_id = $(this).data('id')

        var url = "<?php echo e(route('wishlist.store')); ?>"
        $.ajax({
            type: "post",
            url: url,
            data: {
                product_id
            },
            success: function(data) {
                if ($.isEmptyObject(data.error)) {
                    toastr.success(data.success, 'Wishlist Added Successfully', {
                        timeOut: 3000
                    });
                } else {
                    toastr.error(data.error, {
                        timeOut: 3000
                    });
                }
                console.log(data)
            },
            error: function(data) {
                console.log('Error:', data);
            }
        });
    })


    // remove wish list
    $(document).on('click', ".wish_remove_click", function() {

        var wishlist_id = $(this).data('id')

        var url = "<?php echo e(route('wishlist.destroy')); ?>"
        $.ajax({
            type: "post",
            url: url,
            data: {
                wishlist_id
            },
            success: function(data) {
                loadwishlisttable();
                if ($.isEmptyObject(data.error)) {
                    toastr.success(data.success, 'Wishlist Delete Successfully', {
                        timeOut: 2000
                    });
                } else {
                    toastr.error(data.error, {
                        timeOut: 2000
                    });
                }
                console.log(data)
            },
            error: function(data) {
                console.log('Error:', data);
            }
        });
    })


    // load wishlist table
    function loadwishlisttable() {
        $.ajax({
            url: "<?php echo e(route('load.wishlist.table')); ?>",
            success: function(data) {

                $('#loadwishlisttable').html(data);
            },
            error: function(data) {
                console.log('Error:', data);
            }
        })
    }
</script>


<?php echo $__env->yieldPushContent('js'); ?>

</body>

</html>
<?php /**PATH D:\halalincu\resources\views/web/layouts/app.blade.php ENDPATH**/ ?>