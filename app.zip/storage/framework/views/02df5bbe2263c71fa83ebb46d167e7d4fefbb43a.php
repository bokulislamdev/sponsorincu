<?php $__env->startSection('content'); ?>
<!--start content-->
<main class="page-content">
<!--breadcrumb-->
<div class="page-breadcrumb d-none d-sm-flex align-items-center py-2 px-3" style="background: rgb(46 57 78);">
    <div class="pe-3"><h5 class="text-white m-0">Blog</h5></div>
    <div class="ms-auto">
    <a href="<?php echo e(route('admin.blog.index')); ?>" class="btn btn-primary custom-head-link"> <i class="fadeIn animated bx bx-undo"></i> Back To Blogs</a>
    </div>
</div>
<!--end breadcrumb-->

<div class="card">
    <div class="card-body">
        <form action="<?php echo e(route('admin.blog.store')); ?>" method="post" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="row">
                <div class="col-12 col-md-6 py-2">
                    <label for="" class="form-label">Blog Title <span class="text-danger">*</span></label>
                    <input type="text" class="form-control" name="title" value="<?php echo e(old('title')); ?>">
                    <span class="text-danger"><?php echo e($errors->first('title')); ?></span>
                </div>
                <div class="col-12 col-md-6 py-2">
                    <label for="" class="form-label">Blog Title Arabic</label>
                    <input type="text" class="form-control" name="title_ar" value="<?php echo e(old('title_ar')); ?>">
                </div>
                <div class="col-12 col-md-6 py-2">
                    <label for="" class="form-label">Image <span class="text-danger">*</span></label>
                    <input type="file" class="form-control" name="image">
                    <span class="text-danger"><?php echo e($errors->first('image')); ?></span>
                </div>
                <div class="col-12 col-md-6 py-2">
                    <label for="" class="form-label">Blog Category <span class="text-danger">*</span></label>
                    <select name="blog_category_id" id="" class="form-control">
                        <?php $__currentLoopData = $blog_categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($item->id); ?>"><?php echo e($item->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <span class="text-danger"><?php echo e($errors->first('blog_category_id')); ?></span>
                </div>

                <div class="col-12 py-2">
                    <label for="" class="form-label">Blog Details <span class="text-danger">*</span></label>
                    <textarea name="description" class="form-control summernote"></textarea>
                    <span class="text-danger"><?php echo e($errors->first('description')); ?></span>
                </div>
                <div class="col-12 py-2">
                    <label for="" class="form-label">Blog Details Arabic</label>
                    <textarea name="description_ar"  class="form-control summernote"></textarea>
                </div>
                <div class="d-flex mt-2">
                    <div style="margin-right: 40px">
                        <input type="checkbox" id="sell_post" name="sell_post" value="1" <?php echo e(old('sell_post') == 1 ? checked : ''); ?>>
                        <label for="sell_post">Sell Post</label>
                    </div>
                    <div>
                        <input type="checkbox" id="offer_post" name="offer_post" value="1" <?php echo e(old('offer_post') == 1 ? checked : ''); ?>>
                        <label for="offer_post">Offer Post</label>
                    </div>
                </div>

                <div class="col-12 text-center mt-5">
                    <a href="<?php echo e(route('admin.blog.index')); ?>" class="btn btn-warning" style="margin-right: 20px;">Cancel</a>
                    <button type="submit" class="btn btn-primary">Create</button>
                </div>
            </div>
        </form>
    </div>
    </div>


</main>
<!--end page main-->
<?php $__env->stopSection(); ?>


<?php echo $__env->make('account.layouts.app',['title' => 'Create Blog'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\halalincu\resources\views/account/admin/blog/create.blade.php ENDPATH**/ ?>