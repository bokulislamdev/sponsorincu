


<?php $__env->startSection('content'); ?>
               <!--start content-->
               <main class="page-content">
                <!--breadcrumb-->
                <div class="page-breadcrumb d-none d-sm-flex align-items-center py-2 px-3" style="background: rgb(46 57 78);">
                  <div class="pe-3"><h5 class="text-white m-0">Admin Users</h5></div>
                  <div class="ms-auto">
                        
                  </div>
                </div>
                <!--end breadcrumb-->
    
                <div class="card">
                    <div class="card-body">
                      <div class="d-flex align-items-center">
                        
                          <form class="ms-auto position-relative">
                            <div class="position-absolute top-50 translate-middle-y search-icon px-3"><i class="bi bi-search"></i></div>
                            <input class="form-control ps-5" type="text" placeholder="search">
                          </form>
                      </div>
                      <div class="table-responsive mt-3">
                        <table class="table align-middle">
                          <thead class="table-secondary">
                            <tr>
                             <th>#</th>
                             <th>Username</th>
                             <th>Name</th>
                             <th>Email</th>
                             <th>Phone</th>
                             <th>Country</th>
                             <th>Actions</th>
                            </tr>
                          </thead>
                          <tbody>
                              <?php $__empty_1 = true; $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                             <td><?php echo e($loop->iteration); ?></td>
                              <td><?php echo e($item->username); ?></td>
                              <td><?php echo e($item->name); ?></td>
                              <td><?php echo e($item->email); ?></td>
                              <td><?php echo e($item->phone); ?></td>
                              <td><?php echo e($item->country); ?></td>
                              <td>
                                <div class="table-actions d-flex align-items-center gap-3 fs-6">
                                  <a href="<?php echo e(route('admin.user.show',$item->id)); ?>" class="text-primary" data-bs-toggle="tooltip" data-bs-placement="bottom" title="" data-bs-original-title="Views" aria-label="Views"><i class="bi bi-eye-fill"></i></a>
                                  <a href="<?php echo e(route('admin.user.edit',$item->id)); ?>" class="text-warning" data-bs-toggle="tooltip" data-bs-placement="bottom" title="" data-bs-original-title="Edit" aria-label="Edit"><i class="bi bi-pencil-fill"></i></a>
                                  <a href="<?php echo e(route('admin.user.change.password',$item->id)); ?>" class="text-success" data-bs-toggle="tooltip" data-bs-placement="bottom" title="" data-bs-original-title="Change Password" aria-label="Change Password"><i class="lni lni-key"></i></a>

                                  <form action="<?php echo e(route('admin.user.destroy',$item->id)); ?>" method="POST" id="delete-form">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('delete'); ?>
                                    <button type="button" class="delete-admin" onclick="deleteItem()">
                                      <span  class="text-danger" data-bs-toggle="tooltip" data-bs-placement="bottom" title="" data-bs-original-title="Delete" aria-label="Delete"><i class="bi bi-trash-fill"></i></span>
                                    </button>
                                  </form>
                                      
                                </div>
                              </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                              <h3 class="text-danger">User Not Found</h3>
                            <?php endif; ?>

                          </tbody>
                        </table>
                      </div>
                    </div>
                  </div>
    
              </main>
           <!--end page main-->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('account.layouts.app',['title' => 'Admin Users'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\local_server\htdocs\dajajah\resources\views/account/admin/user/index.blade.php ENDPATH**/ ?>