<!--start sidebar -->
<aside class="sidebar-wrapper" data-simplebar="true">
    <div class="sidebar-header">
      <div>
        <img src="<?php echo e(asset($websetting->logo)); ?>" class="logo-icon" alt="logo icon">
      </div>
      <div>
        <h4 class="logo-text"><?php echo e($websetting->website_name); ?></h4>
      </div>
      <div class="toggle-icon ms-auto"> <i class="bi bi-list"></i>
      </div>
    </div>
    <!--navigation-->
    <ul class="metismenu" id="menu">

      <li>
        <a href="<?php echo e(route('admin.dashboard')); ?>">
          <div class="parent-icon"><i class="bi bi-house-fill"></i>
          </div>
          <div class="menu-title">Dashboard</div>
        </a>
      </li>

      <li>
        <a href="javascript:;" class="has-arrow">
          <div class="parent-icon"><i class="lni lni-user"></i>
          </div>
          <div class="menu-title">Users</div>
        </a>
        <ul>
          <li> <a href="<?php echo e(route('admin.user.index')); ?>"><i class="bi bi-circle"></i>Admin User</a>
          </li>
          <li> <a href="<?php echo e(route('admin.vendor.all')); ?>"><i class="bi bi-circle"></i>Vendors</a>
          </li>
          <li> <a href="<?php echo e(route('admin.general.user.all')); ?>"><i class="bi bi-circle"></i>General Users</a>
          </li>


        </ul>
      </li>
      <li>
        <a href="javascript:;" class="has-arrow">
          <div class="parent-icon"><i class="lni lni-user"></i>
          </div>
          <div class="menu-title">Partners</div>
        </a>
        <ul>
          <li> <a href="<?php echo e(route('admin.partner.index')); ?>"><i class="bi bi-circle"></i>Partner List</a>
          </li>
          <li> <a href="<?php echo e(route('admin.partner.create')); ?>"><i class="bi bi-circle"></i>Create Partner</a>
          </li>
        </ul>
      </li>
      <li>
        <a href="javascript:;" class="has-arrow">
          <div class="parent-icon"><i class="lni lni-user"></i>
          </div>
          <div class="menu-title">Services Sector</div>
        </a>
        <ul>
          <li> <a href="<?php echo e(route('admin.service.index')); ?>"><i class="bi bi-circle"></i>Service List</a>
          </li>
          <li> <a href="<?php echo e(route('admin.service.create')); ?>"><i class="bi bi-circle"></i>Create Service</a>
          </li>
        </ul>
      </li>

      
      

      



      
      <li>
        <a href="javascript:;" class="has-arrow">
          <div class="parent-icon"><i class="lni lni-cog"></i>
          </div>
          <div class="menu-title">Web Seetings</div>
        </a>
        <ul>
          <li> <a href="<?php echo e(route('admin.websetting.index')); ?>"><i class="bi bi-circle"></i>Seeting</a>
          </li>
          
          
          </li>
          <li> <a href="<?php echo e(route('admin.slider.index')); ?>"><i class="bi bi-circle"></i>Sliders</a>
          </li>
          
          </li>
          <li> <a href="<?php echo e(route('admin.contract.index')); ?>"><i class="bi bi-circle"></i>Contract</a>
          </li>
          <li> <a href="<?php echo e(route('admin.subscribe.list')); ?>"><i class="bi bi-circle"></i>Subscribe</a>
          </li>
        </ul>
      </li>


    </ul>
    <!--end navigation-->
 </aside>
 <!--end sidebar -->

 <!--Start Back To Top Button-->
 <a href="javaScript:;" class="back-to-top"><i class='bx bxs-up-arrow-alt'></i></a>
 <!--End Back To Top Button-->
<?php /**PATH D:\local_server\htdocs\blaghat\resources\views/account/layouts/inc/admin-sidebar.blade.php ENDPATH**/ ?>