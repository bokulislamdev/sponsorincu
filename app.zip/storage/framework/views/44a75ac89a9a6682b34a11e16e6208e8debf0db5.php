


<?php $__env->startSection('content'); ?>

    <!--    PAGE TITLE-->
    <section class="page-title py-5">
        <div class="container">
            <h2>Order Completed</h2>
            <a href="#">Home</a>.
            <a href="javascript()">Pages</a>.
            <span>Order Completed</span>
        </div>
    </section>
    <!--    PAGE  TITLE END-->


    <!--    ORDER BOX-->
    <section class="order-box">
        <div class="container">
            <div class="order-box-main">
                <img src="<?php echo e(asset('web')); ?>/images/icons/tik.png" alt="">
                <h3>Your Order Is Completed!</h3>
                <p>
                    Thank you for your order! Your order is being processed and will be completed within 3-6
                    hours. You will receive an email confirmation when your order is completed.
                </p>
                <a href="<?php echo e(route('product')); ?>">Continue Shopping</a>
            </div>
        </div>
    </section>
    <!--    ORDER BOX END-->

<?php $__env->stopSection(); ?>


<?php echo $__env->make('web.layouts.app', ['title' => 'About'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\halalincu\resources\views/web/order-complete.blade.php ENDPATH**/ ?>