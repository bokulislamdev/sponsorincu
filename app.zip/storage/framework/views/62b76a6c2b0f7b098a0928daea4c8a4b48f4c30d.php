


<?php $__env->startSection('content'); ?>

           <!--    HOME SECTION-->
    <section class="home-section clearfix py-5">
        <div class="container py-5">
            <div class="row align-items-center">
                <div class="col-12 col-md-4">
                    <div class="home-left">
                        <div class="home-image pb-4">
                            <img src="<?php echo e(asset('web')); ?>/images/photos/home.png" alt="Image" class="home-img">
                        </div>
                        <div class="web-apps">
                            <a href="#">
                                <img src="<?php echo e(asset('web')); ?>/images/icons/app2.png" alt="">
                            </a>
                            <a href="#">
                                <img src="<?php echo e(asset('web')); ?>/images/icons/google2.png" alt="">
                            </a>
                        </div>

                    </div>
                </div>

                <div class="col-12 col-md-4 mt-5 mt-md-0">
                    <div class="home-left">
                        <a href="#">Lets Know Our Company</a>

                        <div class="home-image py-4">
                            <img src="<?php echo e(asset('web')); ?>/images/photos/phone.png" alt="" class="home-mobile">
                        </div>
                        <div>
                            <span>info@dajajahincu.com</span>
                        </div>
                    </div>
                </div>

                <div class="col-12 col-md-4 mt-5 mt-md-0">
                    <div class="trams-home-image">
                        <img src="images/photos/phone3.png" alt="">
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--    HOME SECTION END-->

    <!--    TRAMS CONDATION-->
    <section class="trams-condation py-5">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="section-title">
                        <h3><span>Terms and
                            </span> Conditions</h3>
                        <p><img src="images/icons/daimon.png" alt=""></p>
                        <h6>Please read the following terms and conditions related to your use of our applications carefully</h6>
                    </div>
                </div>
            </div>
            <div class="row mt-5">
                <div class="trams-condation-box py-2">
                    <div class="d-flex align-items-center">
                        <img src="images/icons/daimon.png" alt="">
                        <h4>Agreement</h4>
                    </div>
                    <p>
                        This Term of Use agreement ("the "Agreement") specifies the Terms and Conditions for access to and use of www.dajajah.com/ (the "Site") and describe the terms and conditions applicable to your access of and use of the Site. This Site is owned by Global Ag Media LLC (“GAM”) and this Agreement may be modified at any time by GAM upon posting of the modified Agreement. Any such modifications shall be effective immediately. You can view the most recent version of these terms at any time at www.dajajah.com/. Each use by you shall constitute and be deemed your unconditional acceptance of this Agreement.
                    </p>
                </div>
                <div class="trams-condation-box py-2">
                    <div class="d-flex align-items-center">
                        <img src="images/icons/daimon.png" alt="">
                        <h4>Ownership</h4>
                    </div>
                    <p>
                        All content included on this site is and shall continue to be the property of GAM or its content suppliers where indicated and is protected under applicable copyright, patent, trademark, and other proprietary rights. Any copying, redistribution, use or publication by you of any such content or any part of the Site is prohibited, except as expressly permitted in this Agreement. Under no circumstances will you acquire any ownership rights or other interest in any content by or through your use of this Site.
                    </p>
                </div>
                <div class="trams-condation-box py-2">
                    <div class="d-flex align-items-center">
                        <img src="images/icons/daimon.png" alt="">
                        <h4>Trademarks
                        </h4>
                    </div>
                    <p>
                        ThePoultrySite & others are either trademarks or registered trademarks of GAM. Other product and company names mentioned on this Site may be trademarks of their respective owners.
                    </p>
                </div>
                <div class="trams-condation-box py-2">
                    <div class="d-flex align-items-center">
                        <img src="images/icons/daimon.png" alt="">
                        <h4>Site Use

                        </h4>
                    </div>
                    <p>
                        GAM grants you a limited, revocable, nonexclusive license to use this Site solely for your own personal use. Content on this Site may not be reproduced, distributed, assigned, sublicensed, sold, included in derivative works, or other use without prior written permission of GAM. You agree not to copy materials on the site, reverse engineer or break into the site, or use materials, products or services in violation of any law. The use of this Site is at the discretion of GAM and GAM may terminate your use of this website at any time.
                    </p>
                </div>
                <div class="trams-condation-box py-2">
                    <div class="d-flex align-items-center">
                        <img src="images/icons/daimon.png" alt="">
                        <h4>Compliance with Laws
                        </h4>
                    </div>
                    <p>
                        You agree to comply with all applicable laws regarding your use of the website. You further agreed that information provided by you is truthful and accurate to the best of your knowledge.
                    </p>
                </div>
                <div class="trams-condation-box py-2">
                    <div class="d-flex align-items-center">
                        <img src="images/icons/daimon.png" alt="">
                        <h4>Contact Information
                        </h4>
                    </div>
                    <p>
                        Website support. info@dajajahincu.com
                    </p>
                </div>
                <div class="trams-condation-box py-2">
                    <div class="d-flex align-items-center">
                        <img src="images/icons/daimon.png" alt="">
                        <h4>Privacy policy
                        </h4>
                    </div>
                    <p class="read-privacy">
                        Read our privacy policy
                    </p>
                </div>
            </div>
        </div>
    </section>
    <!--    TRAMS CONDATION END-->

<?php $__env->stopSection(); ?>


<?php echo $__env->make('web.layouts.app', ['title' => 'Trems & Condations'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\local_server\htdocs\dajajah\resources\views/web/trems-condation.blade.php ENDPATH**/ ?>