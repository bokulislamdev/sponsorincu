<body>

    <!--    HEADER TOP-->
    <section class="header-top py-2 py-sm-3">
        <div class="container">
            <div class="row">
                <div class="col-12 col-lg-6">
                    <div class="header-top-left">
                        <span>
                            <i class="far fa-envelope"></i>
                            <span>Info@halalfood.com</span>
                        </span>
                        <span>
                            <i class="fas fa-phone-volume"></i>
                            <span>+9960551175959</span>
                        </span>
                    </div>
                </div>
                <div class="col-12 col-lg-6">
                    <div class="header-top-right">
                        <a href="#" class="language-btn">
                            English
                        </a>

                        <li class="sub-btn">
                            <a href="">
                                Accounts
                                <i class="fas fa-chevron-down"></i>
                            </a>
                            <div class="sub-menu">
                                <?php if(Auth::check()): ?>
                                    <a href="javascript:void(0)">
                                        <form action="<?php echo e(route('logout')); ?>" method="post">
                                            <?php echo csrf_field(); ?>
                                            <button type="submit">Logout</button>
                                        </form>
                                    </a>

                                    <?php if(Auth::user()->role == 1): ?>
                                        <a href="<?php echo e(route('admin.dashboard')); ?>">Dashboard</a>
                                    <?php elseif(Auth::user()->role == 2): ?>
                                        <a href="<?php echo e(route('vendor.dashboard')); ?>">Dashboard</a>
                                    <?php elseif(Auth::user()->role == 3): ?>
                                        <a href="<?php echo e(route('user.dashboard')); ?>">Dashboard</a>
                                    <?php endif; ?>
                                <?php else: ?>
                                    <a href="<?php echo e(route('login')); ?>">Login</a>
                                    <a href="<?php echo e(route('register')); ?>">User Registration</a>
                                    <a href="<?php echo e(route('vendor.register')); ?>">Vendor Registration</a>
                                <?php endif; ?>
                            </div>
                        </li>

                        </li>

                        <a href="<?php echo e(route('wishlist')); ?>">
                            Wishlist
                            <img src="<?php echo e(asset('web')); ?>/images/icons/love.png" alt="">
                        </a>
                        <a href="<?php echo e(route('product.cart.list')); ?>">
                            <span class="cart_count"></span>
                            <img src="<?php echo e(asset('web')); ?>/images/icons/cart.png" alt="">
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--    HEADER TOP END-->



    <!--    HEADER SECTION-->
    <header class="py-0 py-md-1 py-lg-3">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-12 col-lg-3 d-lg-none">
                    <div class="logo menubar-mobile d-flex justify-content-between align-items-center"
                        onClick="mobileClick()">
                        <div class="logo-image">
                            <a href="<?php echo e(route('homepage')); ?>">
                                <img src="<?php echo e(asset('web')); ?>/images/logo/logo.png" alt="">
                            </a>
                        </div>
                        <i class="fa fa-bars d-lg-none"></i>
                    </div>
                </div>
                <div class="col-12 d-none d-lg-block">
                    <div class="row align-items-center">
                        <div class="col-3">
                            <div class="logo-image">
                                <a href="<?php echo e(route('homepage')); ?>">
                                    <img src="<?php echo e(asset('web')); ?>/images/logo/logo.png" alt="">
                                </a>
                            </div>
                        </div>
                        <div class="col-9 col-xl-6">
                            <div class="menubar">
                                <ul>
                                    <li><a href="<?php echo e(route('homepage')); ?>" class="menu-active">Home</a></li>
                                    <li class="sub-btn">
                                        <a href="<?php echo e(route('product')); ?>">Halal Products
                                            <i class="fas fa-chevron-down"></i>
                                        </a>
                                        <div class="sub-menu">
                                            <a href="<?php echo e(route('offer')); ?>">Offer Product</a>
                                            <a href="<?php echo e(route('newarrival-product')); ?>">New Arrival Product</a>
                                            <a href="#">Best Selling Product</a>
                                            <a href="<?php echo e(route('trending-product')); ?>">Trending Product</a>
                                            <a href="<?php echo e(route('freatured-product')); ?>">Freatured Product</a>

                                        </div>
                                    </li>

                                    <li><a href="<?php echo e(route('blog')); ?>">Blogs </a></li>
                                    <li><a href="<?php echo e(route('about')); ?>">About</a></li>
                                    <li><a href="<?php echo e(route('faq')); ?>">Faq</a></li>
                                    <li><a href="<?php echo e(route('contact')); ?>">Contact </a></li>
                                </ul>
                            </div>
                        </div>
                        <div class="col-3 d-none d-xl-block">
                            <form action="<?php echo e(route('product')); ?>" method="get">
                                <div class="header-search">
                                    <input type="text" name="product">
                                    <button type="submit">
                                        <img src="<?php echo e(asset('web')); ?>/images/icons/search.png" alt="">
                                    </button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </header>
    <!--    HEADER SECTION END-->

    <!--    MOBILE MENU-->
    <div id="mobile-menu" class="mobile-menu">
        <!-- accordion-->
        <div class="accordion accordion-flush" id="accordionFlushExample">

            <div class="mobile-logo mb-3">
                <a href="#">
                    <img src="<?php echo e(asset('web')); ?>/images/logo/logo.png" alt="mobile-logo">
                </a>
                <i id="mobile-cross" class="fa fa-times" onClick="mobileClick()"></i>
            </div>



            <div class="accordion-item">
                <h2 class="accordion-header" id="flush-headingTwo">
                    <button class="accordion-button custom collapsed" type="button" data-bs-toggle="collapse"
                        data-bs-target="#two" aria-expanded="false" aria-controls="flush-collapseTwo">
                        All Category
                    </button>
                </h2>
                <div id="two" class="accordion-collapse collapse" aria-labelledby="two"
                    data-bs-parent="#accordionFlushExample">
                    <div class="accordion-body custom">
                        <ul>
                            <li><a href="#"><i class="fa fa-chevron-right"></i>Lip Gloss</a></li>

                            <li><a href="#"><i class="fa fa-chevron-right"></i>Body Lotion</a></li>
                            <li><a href="#"><i class="fa fa-chevron-right"></i>Cream</a></li>
                            <li><a href="#"><i class="fa fa-chevron-right"></i>Garnier</a></li>
                        </ul>
                    </div>
                </div>
            </div>


            <div class="accordion-item custom ">
                <h2 class="accordion-header" id="flush-headingThree">
                    <a href="#">
                        <button class="accordion-button custom collapsed none" type="button">
                            Wigs Collection
                        </button>
                    </a>
                </h2>
            </div>
            <div class="accordion-item custom">
                <h2 class="accordion-header" id="flush-headingThree">
                    <a href="#">
                        <button class="accordion-button custom collapsed none" type="button">
                            Today’s Deal
                        </button>
                    </a>
                </h2>
            </div>
            <div class="accordion-item custom">
                <h2 class="accordion-header" id="flush-headingThree">
                    <a href="#">
                        <button class="accordion-button custom collapsed none" type="button">
                            Offer
                        </button>
                    </a>
                </h2>
            </div>
            <div class="accordion-item custom">
                <h2 class="accordion-header" id="flush-headingThree">
                    <a href="#">
                        <button class="accordion-button custom collapsed none" type="button">
                            Blog
                        </button>
                    </a>
                </h2>
            </div>
            <div class="accordion-item custom">
                <h2 class="accordion-header" id="flush-headingThree">
                    <a href="#">
                        <button class="accordion-button custom collapsed none" type="button">
                            About
                        </button>
                    </a>
                </h2>
            </div>


        </div>

    </div>
    <div id="mobileOverlay" class="mobile-overlay" onClick="mobileClick()"></div>
    <!--    MOBILE MENU END-->
<?php /**PATH D:\local_server\htdocs\halalincu2\halalincu\resources\views/web/layouts/inc/header.blade.php ENDPATH**/ ?>