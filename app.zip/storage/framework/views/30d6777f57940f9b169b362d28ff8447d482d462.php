<?php $__env->startSection('content'); ?>

     <!--    PAGE TITLE-->
     <section class="page-title py-5" style=" background-image: linear-gradient(rgba(0, 0, 0, 0.4),rgba(0, 0, 0, 0.37)), url(<?php echo e(asset('web')); ?>/images/photos/header-page.png); height: 200px;">
      <div class="container">
          <h2 class="text-white">Shopping Curt</h2>
          <a href="<?php echo e(route('homepage')); ?>">home</a>
          <span>></span>
          <a href="<?php echo e(route('product')); ?>">products</a>
          <span>></span>
          <span>Shopping Curt</span>
          <?php if($errors->any()): ?>
<?php endif; ?>
      </div>
  </section>
  <!--    PAGE  TITLE END-->

  <!--    PRODUCT CART-->
  <section class="product-cart-section py-5">
      <div class="container">
          <div class="row">
              <div class="col-12 col-lg-8">
                  <div class="product-cart-left">
                      <div class="shipping-product-table table-responsive">
                          <table class="table table-re">
                              <thead>
                                  <tr>
                                      <th scope="col">Product</th>
                                      <th scope="col">Price</th>
                                      <th scope="col">Quantity</th>
                                      <th scope="col">Total</th>
                                  </tr>
                              </thead>
                              <tbody id="carttable">

                              </tbody>
                          </table>
                          <div class="shipping-footer d-flex justify-content-between justify-content-center">
                              <a href="<?php echo e(route('product')); ?>">Update Cart</a>
                              <a href="javascript:void(0)" onclick="clearCart()">Clear Cart</a>

                          </div>
                      </div>
                  </div>
              </div>
              <div class="coll-12 col-lg-4 mt-5 mt-lg-0">
                  <div class="product-cart-right">
                      <h4>Cart Totals</h4>
                      <div class="product-cart-right-box">
                          <div id="loadtotal">

                          </div>
                          <div class="d-flex align-items-center shipping-check py-3">
                              <input type="checkbox">
                              <span>Shipping & taxes calculated at checkout</span>
                          </div>
                          <div class="shipping-button mt-2">
                              <a href="<?php echo e(route('product.shipping')); ?>" type="submit">Proceed To Checkout</a>
                          </div>
                      </div>
                  </div>
              </div>
          </div>
      </div>
  </section>
  <!--    PRODUCT CART END-->

<?php $__env->stopSection(); ?>




<?php echo $__env->make('web.layouts.app', ['title' => 'Shopping Cart LIst'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\local_server\htdocs\dajajah\resources\views/web/cart-list.blade.php ENDPATH**/ ?>