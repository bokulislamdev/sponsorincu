



<?php $__env->startSection('content'); ?>
    <!--start content-->
    <main class="page-content">
        <!--breadcrumb-->
        <div class="page-breadcrumb d-none d-sm-flex align-items-center py-2 px-3" style="background: rgb(46 57 78);">
            <div class="pe-3">
                <h5 class="text-white m-0">Product View</h5>
            </div>
            <div class="ms-auto">
                <a href="<?php echo e(route('admin.product.index')); ?>" class="btn btn-primary custom-head-link"> <i
                        class="fadeIn animated bx bx-undo"></i> Back to Products</a>
            </div>
        </div>
        <!--end breadcrumb-->


        <div class="card">
            <div class="card-body">
                <div class="table-responsive mt-3">
                    <table class="table table-border custom-table-css table-border table-hover">
                        <tbody>
                            <tr>
                                <th scope="row">Type</th>
                                <td><?php echo e($product->type); ?></td>
                            </tr>
                            <tr>
                                <th scope="row">Name</th>
                                <td><?php echo e($product->name); ?></td>
                            </tr>
                            <tr>
                                <th scope="row">Arabic Name</th>
                                <td><?php echo e($product->name_ar); ?></td>
                            </tr>
                            
                            <tr>
                                <th scope="row"> Vendor Name</th>
                                <td><?php echo e($product->vendor ? $product->vendor->name : ''); ?></td>
                            </tr>

    
                            

                            <tr>
                                <th scope="row">Color</th>
                                <td><?php echo e($product->color); ?></td>
                            </tr>

                            <tr>
                                <th scope="row">Price</th>
                                <td><?php echo e($product->price); ?></td>
                            </tr>
                            <tr>
                                <th scope="row">Discount Price</th>
                                <td><?php echo e($product->discount_price); ?></td>
                            </tr>

                            <tr>
                                <th scope="row">Active Price</th>
                                <td>
                                    <?php if($product->active_price == 1): ?>
                                        <span class="btn btn-primary status-btn">Regular Price</span>
                                    <?php elseif($product->active_price == 2): ?>
                                        <span class="btn btn-warning status-btn">Discount Price</span>
                                    <?php endif; ?>
                                </td>
                            </tr>
                            <tr>
                                <th scope="row">Category</th>
                                <td>
                                    <?php echo e($product->productcategory ? $product->productcategory->name : ''); ?>

                                </td>
                            </tr>

                            <?php if($product->type == 'feed'): ?>
                            <tr>
                                <th scope="row">Package Size</th>
                                <td>
                                    <?php echo e($product->package_size); ?>

                                </td>
                            </tr>
                            <tr>
                                <th scope="row">Package Type</th>
                                <td>
                                    <?php echo e($product->package_type); ?>

                                </td>
                            </tr>
                            <tr>
                                <th scope="row">Cas No </th>
                                <td>
                                    <?php echo e($product->cas); ?>

                                </td>
                            </tr>
                            <tr>
                                <th scope="row">Cas No </th>
                                <td>
                                    <?php echo e($product->cas); ?>

                                </td>
                            </tr>
                            <tr>
                                <th scope="row">Country Of Origin </th>
                                <td>
                                    <?php echo e($product->country_of_origin); ?>

                                </td>
                            </tr>
                            <?php endif; ?>

                            <?php if($product->type !== 'service'): ?>
                            <tr>
                                <th scope="row">Brend</th>
                                <td>
                                    <?php echo e($product->package_type); ?>

                                </td>
                            </tr>
                            <?php endif; ?>
                            


                            <tr>
                                <th scope="row">Short Description</th>
                                <td><?php echo $product->short_descriprion; ?></td>
                            </tr>

                            <tr>
                                <th scope="row"> Arabic Short Description</th>
                                <td><?php echo $product->short_descriprion_ar; ?></td>
                            </tr>

                            <tr>
                                <th scope="row">Long Description</th>
                                <td><?php echo $product->long_description; ?></td>
                            </tr>

                            <tr>
                                <th scope="row">Arabic Long Description</th>
                                <td><?php echo $product->long_description_ar; ?></td>
                            </tr>

                           
                            <tr>
                                <th scope="row">Status</th>
                                <td>
                                    <?php if($product->status == 1): ?>
                                        <span class="btn btn-success status-btn">Active</span>
                                    <?php elseif($product->status == 2): ?>
                                        <span class="btn btn-danger status-btn">Deactive</span>
                                    <?php endif; ?>
                                </td>
                            </tr>

                        </tbody>
                    </table>
                </div>
            </div>
        </div>


        <div class=" card">
            <div class="card-body">
                <div class="table-responsive mt-3">
                    <table class="table table-border custom-table-css table-border table-hover">
                        <tbody>
                            <tr>
                                <th scope="row">Product Default Image</th>
                                <th scope="row">Product Multiple Image</th>
                                </td>
                            </tr>
                            <tr>

                                <td><img src="<?php echo e(asset($product->image)); ?>" style="width: 120px; alt=""></td>

                                <td>
                                    <?php $__currentLoopData = $product->mutiimage; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <img src="<?php echo e(asset($item->multi_image)); ?>" alt="image" style="width:120px;"
                                            class="mx-2">
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </td>
                                                        </tr>
                                                    </tbody>
                                                </table>
                                            </div>
                                        </div>

                    </div>







            </main>
        <!--end page main-->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('account.layouts.app',['title' => 'Product Show'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\local_server\htdocs\dajajah\resources\views/account/admin/product/show.blade.php ENDPATH**/ ?>