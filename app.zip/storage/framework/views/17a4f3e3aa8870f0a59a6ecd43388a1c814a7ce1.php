 <!--    FOOTER-->
 <footer class="pt-5 pb-0 pb-md-5">
    <div class="container">
        <div class="footer-main pt-4">
            <div class="row">
                <div class="col-12 col-sm-6 col-lg-3 mb-5 mb-lg-0">
                    <div class="footer-head">
                        <div class="footer-logo mb-4">
                            <img src="images/logo/logo.png" alt="">
                        </div>
                        <div class="pb-4">
                            <form action="<?php echo e(route('subscribe')); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <div class="footer-form">
                                    <input type="email"  name="email" placeholder="Enter Email Address">
                                    <button  type="submit" style="background-color:#8C46B4">Sign Up</button>
                                </div>
                            </form>
                        </div>
                        <b>Phone: +996 0551175959</b>
                        <b>Email: info@Beautyin.com</b>

                    </div>
                </div>
                <div class="col-12 col-sm-6 col-lg-3 mb-5 mb-lg-0">
                    <div class="footer-head">
                        <h6>Catagories</h6>
                        <ul>
                            <li><a href="#">Halal Food</a></li>
                            <li><a href="#">Halal Beverage</a></li>
                            <li><a href="#">Halal Dairy product</a></li>
                            <li><a href="#">Halal Confectionery</a></li>
                            <li><a href="#">Halal Health & Beauty</a></li>
                            <li><a href="#">Halal Agriculture</a></li>
                            <li><a href="#">Halal Chemical</a></li>
                        </ul>
                    </div>
                </div>

                <div class="col-12 col-sm-6 col-lg-3 mb-5 mb-lg-0">
                    <div class="footer-head">
                        <h6>Customer Care</h6>
                        <ul>
                            <li><a href="#">My Account</a></li>
                            <li><a href="#">Discount</a></li>
                            <li><a href="#">Returns</a></li>
                            <li><a href="#">Orders History</a></li>
                            <li><a href="#">Order Tracking</a></li>

                        </ul>
                    </div>
                </div>

                <div class="col-12 col-sm-6 col-lg-3 mb-5 mb-lg-0">
                    <div class="footer-head">
                        <h6>Pages</h6>
                        <ul>
                            <li><a href="#">Blog</a></li>
                            <li><a href="#">Browse the Shop</a></li>
                            <li><a href="#">Category</a></li>
                            <li><a href="#">Pre-Built Pages</a></li>
                            <li><a href="#">Visual Composer Elements</a></li>
                            <li><a href="#">WooCommerce Pages</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</footer>
<!--    FOOTER END-->

<!--    COPYRIGHT-->
<section class="copyright-section">
    <div class="container">
        <div class="copyright-content row justify-content-center py-3">
            <div class="col-12 col-md-6">
                <p>@copyright-2022. All right reserved halal food incubator</p>
            </div>
            <div class="col-12 col-md-6">

                <div class="payment-card">

                    <a href="#"><i class="fab fa-facebook-f"></i></a>
                    <a href="#"><i class="fab fa-instagram"></i></a>
                    <a href="#"><i class="fab fa-twitter"></i></a>
                </div>


            </div>
        </div>
    </div>
</section>
<!--    COPYRIGHT END-->
<?php /**PATH D:\local_server\htdocs\halalincu2\halalincu\resources\views/web/layouts/inc/footer.blade.php ENDPATH**/ ?>