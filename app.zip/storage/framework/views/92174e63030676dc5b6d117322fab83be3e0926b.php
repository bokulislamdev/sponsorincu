



<?php $__env->startSection('content'); ?>


<!--    LOGIN-->
<div class="section-login-section py-5 mt-5">
  <div class="container mt-5">
      <div class="login-box">
          <h4><?php echo app('translator')->get('home.User_Registration'); ?></h4>
          <p><?php echo app('translator')->get('home.Please_User_account'); ?></p>
          <form action="<?php echo e(route('register')); ?>" method="post">
              <?php echo csrf_field(); ?>
              <div>
                <input type="text" placeholder="<?php echo app('translator')->get('home.User_Name'); ?>" name="username" value="<?php echo e(old('username')); ?>">
                <span class="text-danger"><?php echo e($errors->first('username')); ?></span>
              </div>
              <div>
                <input type="text" placeholder="<?php echo app('translator')->get('home.Full_Name'); ?>" name="name" value="<?php echo e(old('name')); ?>">
                <span class="text-danger"><?php echo e($errors->first('name')); ?></span>
              </div>
               <div>
                <input type="email" placeholder="<?php echo app('translator')->get('home.email_address'); ?>" name="email" value="<?php echo e(old('email')); ?>">
                <span class="text-danger"><?php echo e($errors->first('email')); ?></span>
              </div>
              <div>
                <input type="text" placeholder="<?php echo app('translator')->get('home.Phone'); ?>" name="phone" value="<?php echo e(old('phone')); ?>">
                <span class="text-danger"><?php echo e($errors->first('phone')); ?></span>
              </div>
              <div>
                <input type="password" placeholder="<?php echo app('translator')->get('home.password'); ?>" name="password">
              <span class="text-danger"><?php echo e($errors->first('password')); ?></span>
              </div>
              <div>
                <input type="password" placeholder="<?php echo app('translator')->get('home.confirm_password'); ?>" name="password_confirmation">
              <span class="text-danger"><?php echo e($errors->first('password_confirmation')); ?></span>
              </div>
              
              <div class="forget">
                  <a href="#"><?php echo app('translator')->get('home.Forgot_your_password'); ?></a>
              </div>
              <button type="submit"><?php echo app('translator')->get('home.Signup'); ?></button>
              <div>
                  <p><?php echo app('translator')->get('home.have_an_Account'); ?> <a href="<?php echo e(route('login')); ?>"><?php echo app('translator')->get('home.Login'); ?></a></p>
              </div>
          </form>
      </div>
  </div>
</div>
<!--    LOGIN END-->

<?php $__env->stopSection(); ?>


                  
       <!--end page main-->

         
        <!--end page main-->
    


<?php echo $__env->make('web.layouts.app', ['title' => 'User Register'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\local_server\htdocs\disclea\resources\views/auth/register.blade.php ENDPATH**/ ?>