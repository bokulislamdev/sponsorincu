<?php $__env->startSection('content'); ?>
        <!--    LOGIN-->
        <div class="login-section py-5">
            <div class="container">
                <div class="login-box">
                    <h4>Login</h4>
                    <p>Please login using account detail bellow.</p>
                    <form action="<?php echo e(route('login')); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <input type="text" placeholder="Email Address" name="email" value="<?php echo e(old('email')); ?>">
                        <span class="text-danger"><?php echo e($errors->first('email')); ?></span>
                        <input type="password" placeholder="Password" name="password">
                        <span class="text-danger"><?php echo e($errors->first('password')); ?></span>
                        <div class="forget">
                            <a href="#">Forgot your password?</a>
                        </div>
                        <button type="submit">Sign In</button>
                        <div>
                            <p>Don’t have an Account? <a href="<?php echo e(route('register')); ?>">Create account</a></p>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        <!--    LOGIN END-->

    <?php echo $__env->make('web.component.parties', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;        
<?php $__env->stopSection(); ?>



    

<?php echo $__env->make('web.layouts.app', ['title' => 'Login'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\local_server\htdocs\dajajah\resources\views/auth/login.blade.php ENDPATH**/ ?>