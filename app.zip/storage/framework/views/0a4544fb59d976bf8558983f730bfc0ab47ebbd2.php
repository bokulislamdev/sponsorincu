


<?php $__env->startSection('content'); ?>

        <!--    PAGE HEAD-->
        <section class="page-head-section text-center py-5">
            <div class="container mt-5 pt-5">
                <h2>About Us</h2>
                <p>
                    <a href="#">Home</a>
                    <span>/</span>
                    <span>Awareness</span>
                </p>
            </div>
        </section>
        <!--    PAGE HEAD END-->
    
        <!--    AWARENSS SECTION-->
        <section class="awarenss-section py-5">
            <div class="container">
                <h4 class="border-bottom">
                    Types of Business Fraud
                </h4>
                <p>
                    Fraud comes in many forms but can be broken down into three categories: asset misappropriation, corruption, and financial statement fraud. Asset misappropriation, although least costly, made up 90% of all fraud cases studied. These are schemes in which an employee steals or exploits its organization’s resources. Examples of asset misappropriation are stealing cash before or after it has been recorded, making false expense reimbursement claims, and/or taking non-cash assets of the organization.
                </p>
                <p>
                    Financial statement fraud comprised less than five percent of cases but caused the most median loss. These are schemes that involve omitting or intentionally misstating information in the company’s financial reports. This can be in the form of fictitious revenues, hidden liabilities or inflated assets.
                </p>
                <h4 class="border-bottom">
                    Awareness
                </h4>
                <div class="awareness-video pt-3" data-autoplay="true" data-vbtype="video">
                    <img src="<?php echo e(asset('web')); ?>/images/photos/video.png" alt="">
                    <a href="https://youtu.be/tJRFuRQxVa0" class="my-video-links">
                        <img class="youtube-icon" src="images/icons/youtube.png" alt="">
                    </a>
    
                    <!--                <a class="my-video-links" data-autoplay="true" data-vbtype="video" href="https://www.youtube.com/watch?v=knkNy_LHtlo">Youtube</a>-->
    
    
    
                </div>
                <p>
                    Corruption fell in the middle and made up less than one-third of cases. Corruption schemes happen when employees use their influence in business transactions for their benefit while violating their duty to the employer. Examples of corruption are bribery, extortion, and conflict of interest.
                </p>
                <h4>
                    Fraud Prevention
                </h4>
                <p>
                    It is vital to an organization, large or small, to have a fraud prevention plan in place. The fraud cases studied in the ACFE 2014 Report revealed that the fraudulent activities studied lasted an average of 18 months before being detected. Imagine the type of loss your company could suffer with an employee committing fraud for a year and a half. Luckily, there are ways you can minimize fraud occurrences by implementing different procedures and controls.
                </p>
                <h4>
                    Fraud Detection
                </h4>
                <p>
                    In addition to prevention strategies, you should also have detection methods in place and make them visible to the employees. According to Managing the Business Risk of Fraud: A Practical Guide, published by Association of Certified Fraud Examiners (ACFE), the visibility of these controls acts as one of the best deterrents to fraudulent behavior. It is important to continuously monitor and update your fraud detection strategies to ensure they are effective. Detection plans usually occur during the regularly scheduled business day. These plans take external information into consideration to link with internal data. The results of your fraud detection plans should enhance your prevention controls. It is important to document your fraud detection strategies including the individuals or teams responsible for each task. Once the final fraud detection plan has been finalized, all employees should be made aware of the plan and how it will be implemented. Communicating this to employees is a prevention method in itself. Knowing the company is watching and will take disciplinary action can hinder employees’ plans to commit fraud.
                </p>
            </div>
        </section>
        <!--    AWARENSS SECTION END-->
    
        <!--    REPORT SECTION-->
        <div class="section-report-section py-5">
            <div class="container">
                <div class="row">
                    <div class="section-title text-center">
                        <h4>
                            Our Goals
                        </h4>
                    </div>
                </div>
                <div class="row mt-5">
                    <div class="col-12 col-sm-6 col-md-4 col-lg-3 pb-4">
                        <div class="report-box h-100">
                            <p>
                                We aim to come up with recommendations and to unify the work of notifications and inspections in government agencies and bodies
                            </p>
                        </div>
                    </div>
    
                    <div class="col-12 col-sm-6 col-md-4 col-lg-3 pb-4">
                        <div class="report-box h-100">
                            <p>
                                To establish the Supreme Inspection Authority as an alternative to the business sector and investors.
                            </p>
                        </div>
                    </div>
    
                    <div class="col-12 col-sm-6 col-md-4 col-lg-3 pb-4">
                        <div class="report-box h-100">
                            <p>
                                The inspection and control efforts carried out by government agencies and bodies should be unified under one body and entity to facilitate doing business
                            </p>
                        </div>
                    </div>
                    <div class="col-12 col-sm-6 col-md-4 col-lg-3 pb-4">
                        <div class="report-box h-100">
                            <p>
                                The ministries’ role should be limited to enacting proposals and formulating policies, and the authority’s role in organizing and supervising
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!--    REPORT SECTION END-->

    <?php echo $__env->make('web.component.brand', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>; 
    <?php echo $__env->make('web.component.subscribe', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>; 
<?php $__env->stopSection(); ?>

<?php echo $__env->make('web.layouts.app', ['title' => 'Services'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\local_server\htdocs\blaghat\resources\views/web/awarenss.blade.php ENDPATH**/ ?>