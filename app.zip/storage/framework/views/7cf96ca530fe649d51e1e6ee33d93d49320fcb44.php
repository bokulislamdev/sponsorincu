<?php
$locale = app()->getLocale();
?>





<?php $__env->startSection('content'); ?>

       <!--    PAGE HEAD-->
       <section class="page-head-section text-center py-5">
        <div class="container mt-5 pt-5">
            <h2>Our Partners</h2>
            <p>
                <a href="<?php echo e(route('homepage')); ?>">Home</a>
                <span>/</span>
                <span> Our Partners</span>
            </p>
        </div>
    </section>
    <!--    PAGE HEAD END-->

    <!--    PARTNER SECTION-->
    <section class="partner-section py-5">
        <div class="container">
            <div class="row">
                <?php $__currentLoopData = $partners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-12 col-sm-6 col-lg-4 pb-4">
                    <a href="<?php echo e($item->web_link); ?>" target="_blank" class="partner-box h-100 d-flex align-content-between flex-wrap">
                       
                        <div class="w-100">
                            <img src="<?php echo e(asset($item->image)); ?>" alt="Photo">
                        </div>
                        <div class="w-100">
                            <h6>
                                <?php if($locale == 'en'): ?>
                                    <?php echo e($item->name); ?>

                                <?php elseif($locale == 'ar'): ?>
                                    <?php echo e($item->name_ar); ?>

                                <?php endif; ?>
                            </h6>
                            <p>
                                <?php if($locale == 'en'): ?>
                                    <?php echo e($item->title); ?>

                                <?php elseif($locale == 'ar'): ?>
                                    <?php echo e($item->title_ar); ?>

                                <?php endif; ?>
                            </p>
                        </div>
                        
                    </a>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                
            </div>
        </div>
    </section>
    <!--    PARTNER SECTION END-->
        
    <?php echo $__env->make('web.component.brand', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>; 
    <?php echo $__env->make('web.component.subscribe', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>; 



<?php $__env->stopSection(); ?>


<?php echo $__env->make('web.layouts.app', ['title' => 'Our Partners'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\local_server\htdocs\blaghat\resources\views/web/partner.blade.php ENDPATH**/ ?>