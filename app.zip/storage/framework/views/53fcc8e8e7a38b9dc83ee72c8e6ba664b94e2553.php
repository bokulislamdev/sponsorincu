<!DOCTYPE html>
<html lang="en" class="semi-dark">
    <head>
        <title><?php echo e($title ?? 'page title not set'); ?> - <?php echo e($websetting->homepage_title); ?> </title>
        <!-- Required meta tags -->
        <meta charset="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <link rel="icon" href="assets/images/favicon-32x32.png" type="image/png" />
        <!--plugins-->
        <link href="<?php echo e(asset('account')); ?>/assets/plugins/simplebar/css/simplebar.css" rel="stylesheet" />
        <link href="<?php echo e(asset('account')); ?>/assets/plugins/perfect-scrollbar/css/perfect-scrollbar.css" rel="stylesheet" />
        <link href="<?php echo e(asset('account')); ?>/assets/plugins/metismenu/css/metisMenu.min.css" rel="stylesheet" />
        <!-- Bootstrap CSS -->
        <link href="<?php echo e(asset('account')); ?>/assets/css/bootstrap.min.css" rel="stylesheet" />
        <link href="<?php echo e(asset('account')); ?>/assets/css/bootstrap-extended.css" rel="stylesheet" />
        <link href="<?php echo e(asset('account')); ?>/assets/css/style.css" rel="stylesheet" />
        <link href="<?php echo e(asset('account')); ?>/assets/css/icons.css" rel="stylesheet" />
        <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500&display=swap" rel="stylesheet" />
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.5.0/font/bootstrap-icons.css" />
        <!-- loader-->
        <link href="<?php echo e(asset('account')); ?>/assets/css/pace.min.css" rel="stylesheet"/>
        <!--Theme Styles-->
        <link href="<?php echo e(asset('account')); ?>/assets/css/dark-theme.css" rel="stylesheet"/>
        <link href="<?php echo e(asset('account')); ?>/assets/css/light-theme.css" rel="stylesheet"/>
        <link href="<?php echo e(asset('account')); ?>/assets/css/semi-dark.css" rel="stylesheet" />
        <link href="<?php echo e(asset('account')); ?>/assets/css/header-colors.css" rel="stylesheet"/>
        
        
        <link rel="stylesheet" href="https://cdn.bootcss.com/toastr.js/latest/css/toastr.min.css" />
        <link href="https://cdn.jsdelivr.net/npm/summernote@0.8.18/dist/summernote.min.css" rel="stylesheet">
        <link rel="stylesheet" type="text/css" href="https://cdn.jsdelivr.net/npm/daterangepicker/daterangepicker.css" />

        <?php echo $__env->yieldPushContent('css'); ?>


    </head>
    <body>
        <!--start wrapper-->
        <div class="wrapper">
            <?php echo $__env->make('account.layouts.inc.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;

            <?php if(Auth::user()->role == 1): ?>
                <?php echo $__env->make('account.layouts.inc.admin-sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;
            <?php elseif(Auth::user()->role == 2): ?>
                <?php echo $__env->make('account.layouts.inc.organizer-sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;
            <?php elseif(Auth::user()->role == 3): ?>
                <?php echo $__env->make('account.layouts.inc.sponsor-sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;
            <?php elseif(Auth::user()->role == 4): ?>
                <?php echo $__env->make('account.layouts.inc.marketer-sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;
            <?php endif; ?>




			<?php echo $__env->yieldContent('content'); ?>




        </div>
        <!--end wrapper-->

        <!-- Bootstrap bundle JS -->
        <script src="<?php echo e(asset('account')); ?>/assets/js/bootstrap.bundle.min.js"></script>
        <!--plugins-->
        <script src="<?php echo e(asset('account')); ?>/assets/js/jquery.min.js"></script>
        <script src="<?php echo e(asset('account')); ?>/assets/plugins/simplebar/js/simplebar.min.js"></script>
        <script src="<?php echo e(asset('account')); ?>/assets/plugins/metismenu/js/metisMenu.min.js"></script>
        <script src="<?php echo e(asset('account')); ?>/assets/plugins/perfect-scrollbar/js/perfect-scrollbar.js"></script>
        <script src="<?php echo e(asset('account')); ?>/assets/js/pace.min.js"></script>
        <script src="<?php echo e(asset('account')); ?>/assets/plugins/chartjs/js/Chart.min.js"></script>
        <script src="<?php echo e(asset('account')); ?>/assets/plugins/chartjs/js/Chart.extension.js"></script>
        <script src="<?php echo e(asset('account')); ?>/assets/plugins/apexcharts-bundle/js/apexcharts.min.js"></script>
        <!--app-->
        <script src="<?php echo e(asset('account')); ?>/assets/js/app.js"></script>
        <script src="<?php echo e(asset('account')); ?>/assets/js/index2.js"></script>
        <!-- toster & sweetalert -->
        <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/js/toastr.min.js"></script>
        
        <script src="https://cdn.jsdelivr.net/npm/summernote@0.8.18/dist/summernote.min.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11.3.10/dist/sweetalert2.all.min.js"></script>
        <script type="text/javascript" src="https://cdn.jsdelivr.net/momentjs/latest/moment.min.js"></script>
<script type="text/javascript" src="https://cdn.jsdelivr.net/npm/daterangepicker/daterangepicker.min.js"></script>
        <script>
            new PerfectScrollbar(".best-product");
        </script>

        
        <script>
            <?php if(Session::has('message')): ?>

            var type = "<?php echo e(Session::get('alert-type', 'info')); ?>"

            switch (type) {
                case 'info':
                toastr.info("<?php echo e(Session::get('message')); ?>");
                break;
                case 'success':
                toastr.success("<?php echo e(Session::get('message')); ?>");
                break;
                case 'warning':
                toastr.warning("<?php echo e(Session::get('message')); ?>");
                break;
                case 'error':
                toastr.error("<?php echo e(Session::get('message')); ?>");
                break;
            }
            <?php endif; ?>

            $(document).ready(function() {
                $('.summernote').summernote();
            });




        // confirmation delete
        // function deleteItem() {
        //     Swal.fire({
        //         title: 'Are you sure?',
        //         text: "You won't to Delete This!",
        //         icon: 'warning',
        //         showCancelButton: true,
        //         confirmButtonColor: '#3085d6',
        //         cancelButtonColor: '#d33',
        //         confirmButtonText: 'Yes, delete it!'
        //         })
        //         .then((result) => {
        //             if (result.isConfirmed) {
        //                 $('#delete-form').submit()
        //                 Swal.fire(
        //                     'Deleted!',
        //                     'Your data has been deleted.',
        //                     'success'
        //                 )
        //             }
        //     })
        // }

        function deleteItem() {
            Swal.fire({
                    title: 'Are you sure?',
                    text: "You won't to Delete This!",
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#3085d6',
                    cancelButtonColor: '#d33',
                    confirmButtonText: 'Yes, delete it!'
                })
                .then((result) => {
                    if (result.isConfirmed) {
                        $('#delete-form').submit()
                        Swal.fire(
                            'Deleted!',
                            'Your data has been deleted.',
                            'success'
                        )
                    }
            })
        }

        </script>

        <?php echo $__env->yieldPushContent('js'); ?>









        <?php echo Notify::message(); ?>






    </body>
</html>
<?php /**PATH D:\local_server\htdocs\sponser\resources\views/account/layouts/app.blade.php ENDPATH**/ ?>