<?php $__env->startSection('content'); ?>
     <!--    PAGE TITLE-->
     <section class="page-title py-5" style=" background-image: linear-gradient(rgba(0, 0, 0, 0.4),rgba(0, 0, 0, 0.37)), url(<?php echo e(asset('web')); ?>/images/photos/header-page.png); height: 200px;">
        <div class="container">
            <h2 class="text-white">Shopping Curt</h2>
            <a href="<?php echo e(route('homepage')); ?>">home</a>
            <span>></span>
            <a href="<?php echo e(route('product')); ?>">products</a>
            <span>></span>
             <a href="<?php echo e(route('product')); ?>">Products Cart</a>
            <span>></span>
            <span>Products Shopping</span>
            <?php if($errors->any()): ?>
  <?php endif; ?>
        </div>
    </section>
    <!--    PAGE  TITLE END-->

    <!--    SHIPPING PAYMENT-->
    <section class="shipping-payment py-5">
        <div class="container">
            <form action="<?php echo e(route('product.shipping.store')); ?>" method="post">
                <?php echo csrf_field(); ?>
                <div class="row">
                    <div class="col-12 col-lg-7">
                        <div class="shipping-payment-left">
                            <div class="shipping-payment-left-head">
                                <h6>Contact Information</h6>
                               
                            </div>

                            <div class="shipping-payment-from">
                                <div class="">
                                    <input type="text" placeholder="Email or mobile phone number" name="contract_number"
                                        value="<?php if($countb): ?> <?php echo e($billing->contract_number); ?> <?php endif; ?>">
                                    <span class="text-danger"><?php echo e($errors->first('contract_number')); ?></span>
                                </div>
                                <div class="py-2 d-flex align-items-center">
                                    <input type="checkbox">
                                    <span>Keep me up to date on news and excluive offers</span>
                                </div>
                            </div>

                            <div class="shipping-payment-left-head mt-5">
                                <h6>Shipping address</h6>
                            </div>

                            <div class="shipping-payment-from">
                                <div class="row">
                                    <div class="col-6 py-3">
                                        <input type="text" placeholder="Full Name" name="name" value="<?php if($countb): ?> <?php echo e($billing->name); ?> <?php endif; ?>">
                                        <span class="text-danger"><?php echo e($errors->first('name')); ?></span>
                                    </div>
                                    <div class="col-6 py-3">
                                        <input type="text" placeholder="City" name="city" value="<?php if($countb): ?> <?php echo e($billing->city); ?> <?php endif; ?>">
                                        <span class="text-danger"><?php echo e($errors->first('city')); ?></span>
                                    </div>
                                    <div class="col-12 py-3">
                                        <input type="text" placeholder="Address" name="street_address"
                                            value="<?php if($countb): ?> <?php echo e($billing->street_address); ?> <?php endif; ?>">
                                        <span class="text-danger"><?php echo e($errors->first('street_address')); ?></span>
                                    </div>
                                    <div class="col-12 py-3">
                                        <input type="text" placeholder="Appaetnentment,suit,e.t.c (optinal)"
                                            name="apartment_address" value="<?php if($countb): ?> <?php echo e($billing->apartment_address); ?> <?php endif; ?>">
                                        <span class="text-danger"><?php echo e($errors->first('apartment_address')); ?></span>
                                    </div>

                                    <div class="col-6 py-3">
                                        <input type="text" placeholder="Country" name="country"
                                            value="<?php if($countb): ?> <?php echo e($billing->country); ?> <?php endif; ?>">
                                        <span class="text-danger"><?php echo e($errors->first('country')); ?></span>
                                    </div>
                                    <div class="col-6 py-3">
                                        <input type="text" placeholder="Postal Code" name="zip_code"
                                            value="<?php if($countb): ?> <?php echo e($billing->zip_code); ?> <?php endif; ?>">
                                        <span class="text-danger"><?php echo e($errors->first('zip_code')); ?></span>
                                    </div>
                                    <div class="col-6 mt-5">
                                        <a href="<?php echo e(route('product.cart.list')); ?>">Continue Shipping</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-12 col-lg-5 mt-5 mt-lg-0">
                        <div class="shipping-payment-right">
                            <?php $__currentLoopData = $carts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="shipping-product-box d-flex justify-content-between align-items-center">
                                    <div>
                                        <div class="d-flex bd-highlight align-items-center">
                                            <div class="shipping-product-image p-2 flex-shrink-1 bd-highlight">
                                                <img src="<?php echo e(asset($product->options->image)); ?>" alt="Product Image">
                                            </div>
                                            <div class="shipping-product-text p-2 w-100 bd-highlight">
                                                <h6><?php echo e($product->name); ?></h6>
                                                <p>Color: <?php echo e($product->options->color); ?></p>
                                                <p>price: SAR <?php echo e($product->price); ?></p>
                                                <p>Quentity: <?php echo e($product->qty); ?></p>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="shipping-product-price">SAR <?php echo e($product->priceTotal); ?></div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                        <div class="product-cart-right-box mt-5">
                            <div class="total-shipping">
                                <span>Subtotals:</span>
                                <span>SAR <?php echo e(Cart::subtotal()); ?></span>
                            </div>
                            <div class="total-shipping">
                                <span>Tax:</span>
                                <span>SAR <?php echo e(Cart::tax()); ?></span>
                            </div>
                            <div class="total-shipping">
                                <span>Totals:</span>
                                <span>SAR <?php echo e(Cart::total()); ?></span>
                            </div>
                            <div class="d-flex align-items-center shipping-check py-3">
                                <input type="checkbox">
                                <span>Shipping &amp; taxes calculated at checkout</span>
                            </div>
                            <div class="shipping-button mt-2">
                                <button type="submit">Proceed To Checkout</button>
                            </div>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </section>
    <!--    SHIPPING PAYMENT END-->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('web.layouts.app', ['title' => 'About'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\local_server\htdocs\dajajah\resources\views/web/shipping.blade.php ENDPATH**/ ?>