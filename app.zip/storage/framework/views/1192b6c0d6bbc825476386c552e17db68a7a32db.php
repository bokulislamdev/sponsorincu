<?php $__env->startSection('content'); ?>

    <!--    PAGE HEAD-->
    <section class="page-head-section text-center py-5">
        <div class="container my-5 py-5">
            <h3>Welcome to you</h3>
            <h4><?php echo app('translator')->get('home.Login'); ?></h4>
        </div>
    </section>
    <!--    PAGE HEAD END-->
    
    <!--    LOGIN SECTION-->
    <section class="login-section pb-5">
        <div class="container">
            <div class="login-box">
                <form action="<?php echo e(route('login')); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <div class="py-4">
                        <input type="text" placeholder="<?php echo app('translator')->get('home.email_address'); ?>" name="email" value="<?php echo e(old('email')); ?>">
                        <span class="text-danger"><?php echo e($errors->first('email')); ?></span>
                    </div>
                    <div class="py-4">
                        <input type="password" placeholder="<?php echo app('translator')->get('home.password'); ?>" name="password">
                        <span class="text-danger"><?php echo e($errors->first('password')); ?></span>
                         <p class="forget"><a href="#"><?php echo app('translator')->get('home.Forgot_your_password'); ?></a></p>
                    </div>
                   
                    <button type="submit"><?php echo app('translator')->get('home.Login'); ?></button>
                    <p class="have-account"><?php echo app('translator')->get('home.donot_an_account'); ?> <a href="<?php echo e(route('register')); ?>"><?php echo app('translator')->get('home.Signup'); ?></a></p>
                </form>
            </div>
        </div>
    </section>
    <!--    LOGIN SECTION END-->
      
     
<?php $__env->stopSection(); ?>





    

<?php echo $__env->make('web.layouts.app', ['title' => 'Login'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\local_server\htdocs\blaghat\resources\views/auth/login.blade.php ENDPATH**/ ?>