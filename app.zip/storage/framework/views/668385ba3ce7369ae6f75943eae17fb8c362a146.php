<?php
$locale = app()->getLocale();
?>



<?php $__env->startSection('content'); ?>
    <!--    HOME SECTION-->
    <section class="home-section" style="background-image: linear-gradient(#6429e365,#6429e365),url(<?php echo e(asset('web')); ?>/images/photos/top-banner.png);background-position: center;
    background-repeat: no-repeat;
    background-size: cover;">
        <div class="container">
            <div class="home-container-box">
                <div class="row">
                    <div class="col-12 col-xl-8 py-0">
                        <div class="home-content py-5">
                            <p>
                                <?php echo app('translator')->get('home.Sponsors_Incubator'); ?>
                            </p>
                            <h1>
                                <?php echo app('translator')->get('home.Sponsors_Incubator_A'); ?>
                            </h1>
                            <div class="">
                                <a href="<?php echo e(route('register')); ?>"><?php echo app('translator')->get('home.I_am_an_Event_Sponsor'); ?></a>
                                <a href="<?php echo e(route('register')); ?>"><?php echo app('translator')->get('home.I_am_an_Event_Organizer'); ?></a>
                                <a href="<?php echo e(route('register')); ?>"><?php echo app('translator')->get('home.I_am_an_Event_marketer'); ?></a>
                            </div>
                        </div>
                    </div>
                </div>
                
            </div>
        </div>
    </section>
    <!--   HOME SECTION  -->

        <!--    EVENT SECTION-->
        <section class="event-section py-5">
            <div class="container">
                <ul class="nav nav-tabs" id="myTab" role="tablist">
                    <li class="nav-item" role="presentation">
                        <button class="nav-link active" id="all-tab" data-bs-toggle="tab" data-bs-target="#all" type="button" role="tab" aria-controls="all" aria-selected="true">All types</button>
                    </li>
                    <?php $__currentLoopData = $event_types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event_type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="nav-item" role="presentation">
                            <button class="nav-link" id="types<?php echo e($event_type->id); ?>-tab" data-bs-toggle="tab" data-bs-target="#types<?php echo e($event_type->id); ?>" type="button" role="tab" aria-controls="types<?php echo e($event_type->id); ?>" aria-selected="false">
                                <?php if($locale == 'en'): ?>
                                <?php echo e($event_type->name); ?>

                                <?php elseif( $locale == "ar"): ?>
                                <?php echo e($event_type->name_ar); ?>

                                <?php endif; ?>
                                
                            </button>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
                <div class="row pt-2">
                    <div class="contact-title d-flex justify-content-end align-items-center">
                        <a href="<?php echo e(route('event.category')); ?>">View All</a>
                    </div>
                </div>
                <div class="tab-content mt-4" id="myTabContent">
                    <div class="tab-pane fade show active" id="all" role="tabpanel" aria-labelledby="all-tab">
                        <div class="row">
                            <?php $__currentLoopData = $event_topics_default; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $topics_default): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-12 col-sm-6 col-md-3 mb-4 mix available">
                                <div class="event-box" style="background-image: url(<?php echo e(asset('web')); ?>/images/event/1.png); ">
                                    <h6>
                                        <?php if($locale == 'en'): ?>
                                        <?php echo e($topics_default->name); ?>

                                        <?php elseif( $locale == "ar"): ?>
                                        <?php echo e($topics_default->name_ar); ?>

                                        <?php endif; ?>
                                        
                                    </h6>
                                    <a href="<?php echo e(route('single.topic',$topics_default->slug)); ?>" class="stretched-link"></a>
                                </div>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                    <?php $__currentLoopData = $event_types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event_type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                            $event_topics = App\Models\EventTopic::where('event_type_id',$event_type->id)->limit(4)->get();
                        ?>
                        <div class="tab-pane fade" id="types<?php echo e($event_type->id); ?>" role="tabpanel" aria-labelledby="types<?php echo e($event_type->id); ?>-tab">
                            <div class="row">
                                <?php $__currentLoopData = $event_topics; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event_topic): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="col-12 col-sm-6 col-md-3 mb-4 mix available">
                                    <div class="event-box" style="background-image: url(<?php echo e(asset('web')); ?>/images/event/1.png); ">
                                        <h6>
                                            <?php if($locale == 'en'): ?>
                                            <?php echo e($event_topic->name); ?>

                                        <?php elseif( $locale == "ar"): ?>
                                        <?php echo e($event_topic->name_ar); ?>

                                        <?php endif; ?>
                                        </h6>
                                        <a href="<?php echo e(route('single.topic',$event_topic->slug)); ?>" class="stretched-link"></a>
                                    </div>
                                </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </section>
        <!--    EVENT SECTION END-->

    <!--    ABOUT SECTION-->
    <section class="about-section py-5">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-12 col-md-6">
                    <div class="about-image">
                        <img src="<?php echo e(asset('web')); ?>/images/photos/about.png" alt="Image">
                    </div>
                </div>
                <div class="col-12 col-md-6 mt-4 mt-md-0">
                    <div class="about-text">
                        <h4><?php echo app('translator')->get('home.who_are_we'); ?></h4>
                        <p>
                            <?php echo app('translator')->get('home.about_p1'); ?>
                        </p>
                        <p>
                            <?php echo app('translator')->get('home.about_p2'); ?>
                        </p>
                        <p>
                            <?php echo app('translator')->get('home.about_p3'); ?>
                        </p>
                        <p>
                            <?php echo app('translator')->get('home.about_p4'); ?>
                        </p>
                        <div>
                            <a href="<?php echo e(route('about')); ?>" class="about-btn"><?php echo app('translator')->get('home.Read_More'); ?></a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--    ABOUT SECTION END-->

    <!--    SERVICE SECTION-->
    <section class="service-section py-5">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="section-title text-center">
                        <h4><?php echo app('translator')->get('home.Our_Services'); ?></h4>
                    </div>
                </div>
            </div>
            <div class="row mt-5">
                <div class="col-12 col-sm-6 col-md-4 col-lg-3 pb-4">
                    <div class="service-box">
                        <a href="<?php echo e(route('service')); ?>">
                            <img src="<?php echo e(asset('web')); ?>/images/service/1.png" alt="">
                        </a>
                        <div class="service-text">
                            <h4><?php echo app('translator')->get('home.service_li6'); ?></h4>
                            <p>
                                <?php echo app('translator')->get('home.Event_marketing_is'); ?>
                            </p>
                        </div>
                    </div>
                </div>
                <div class="col-12 col-sm-6 col-md-4 col-lg-3 pb-4">
                    <div class="service-box">
                        <a href="<?php echo e(route('service')); ?>">
                            <img src="<?php echo e(asset('web')); ?>/images/service/2.png" alt="">
                        </a>
                        <div class="service-text">
                            <h4><?php echo app('translator')->get('home.Ads'); ?></h4>
                            <p>
                                <?php echo app('translator')->get('home.Ads_li1'); ?>
                            </p>
                        </div>
                    </div>
                </div>
                <div class="col-12 col-sm-6 col-md-4 col-lg-3 pb-4">
                    <div class="service-box">
                        <a href="<?php echo e(route('service')); ?>">
                            <img src="<?php echo e(asset('web')); ?>/images/service/3.png" alt="">
                        </a>
                        <div class="service-text">
                            <h4><?php echo app('translator')->get('home.Sponsoring_non_profit'); ?></h4>
                            <p>
                                <?php echo app('translator')->get('home.Sponsoring_non_profit_li1'); ?>
                            </p>
                        </div>
                    </div>
                </div>
                <div class="col-12 col-sm-6 col-md-4 col-lg-3 pb-4">
                    <div class="service-box">
                        <a href="<?php echo e(route('service')); ?>">
                            <img src="<?php echo e(asset('web')); ?>/images/service/4.png" alt="">
                        </a>
                        <div class="service-text">
                            <h4><?php echo app('translator')->get('home.sponsoring_influencers'); ?></h4>
                            
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--    SERVICE SECTION END-->

    <!--    COUNT SECTION-->
    
    <!--    COUNT SECTION END-->


    <!--    CLIENT SECTION-->
    
    <!--    CLIENT SECTION END-->

    <!--    BRAND SECTION-->
    <div class="section-brand-section py-5">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="section-title text-center">
                        <h4><?php echo app('translator')->get('home.Our_sponsors'); ?></h4>
                    </div>
                </div>
            </div>
            <div class="picture_slider mt-5">
                <div class="brand-box">
                    <img src="<?php echo e(asset('web')); ?>/images/brands/1.png" alt="Image">
                </div>
                <div class="brand-box">
                    <img src="<?php echo e(asset('web')); ?>/images/brands/2.png" alt="Image">
                </div>
                <div class="brand-box">
                    <img src="<?php echo e(asset('web')); ?>/images/brands/3.png" alt="Image">
                </div>
                <div class="brand-box">
                    <img src="<?php echo e(asset('web')); ?>/images/brands/4.png" alt="Image">
                </div>
                <div class="brand-box">
                    <img src="<?php echo e(asset('web')); ?>/images/brands/5.png" alt="Image">
                </div>
                <div class="brand-box">
                    <img src="<?php echo e(asset('web')); ?>/images/brands/6.png" alt="Image">
                </div>
                <div class="brand-box">
                    <img src="<?php echo e(asset('web')); ?>/images/brands/1.png" alt="Image">
                </div>
                <div class="brand-box">
                    <img src="<?php echo e(asset('web')); ?>/images/brands/2.png" alt="Image">
                </div>
                <div class="brand-box">
                    <img src="<?php echo e(asset('web')); ?>/images/brands/3.png" alt="Image">
                </div>
                <div class="brand-box">
                    <img src="<?php echo e(asset('web')); ?>/images/brands/4.png" alt="Image">
                </div>
                <div class="brand-box">
                    <img src="<?php echo e(asset('web')); ?>/images/brands/5.png" alt="Image">
                </div>
                <div class="brand-box">
                    <img src="<?php echo e(asset('web')); ?>/images/brands/6.png" alt="Image">
                </div>
            </div>
        </div>
    </div>
    <!--    BRAND SECTION END-->



  <?php echo $__env->make('web.component.subscribe', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>; 

<?php $__env->stopSection(); ?>



<?php $__env->startPush('js'); ?>
    <script>
	$('.counter').each(function () {
	    var $this = $(this),
	        countTo = $this.attr('data-count');

	    $({
	        countNum: $this.text()
	    }).animate({
	            countNum: countTo
	        },
	        {
	            duration: 6000,
	            easing: 'linear',
	            step: function () {
	                $this.text(Math.floor(this.countNum));
	            },
	            complete: function () {
	                $this.text(this.countNum);
	            }
	        });
	});




    // slick slider
    $('.event_type').slick({
            slidesToShow: 4,
            slidesToScroll: 2,
            autoplay: true,
            dots: false,
            <?php if($locale == 'ar'): ?>
            rtl: true,
            <?php endif; ?>
            infinite: false,
            autoplaySpeed: 2000,
            nextArrow: $('.event_next'),
            prevArrow: $('.event_prev'),
            arrows: true,
            responsive: [{
                    breakpoint: 992,
                    settings: {
                        slidesToShow: 3,
                        slidesToScroll: 2,
                        infinite: true,
                        dots: true
                    }
                },
                {
                    breakpoint: 768,
                    settings: {
                        slidesToShow: 2,
                        slidesToScroll: 2,
                        infinite: true,
                        dots: true
                    }
                },
                {
                    breakpoint: 576,
                    settings: {
                        slidesToShow: 1,
                        slidesToScroll: 1
                    }
                },
                {
                    breakpoint: 480,
                    settings: {
                        slidesToShow: 1,
                        slidesToScroll: 1
                    }
                }
            ]
        });
    </script>
<?php $__env->stopPush(); ?>


<?php echo $__env->make('web.layouts.app', ['title' => 'Home'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\local_server\htdocs\sponser\resources\views/web/homepage.blade.php ENDPATH**/ ?>