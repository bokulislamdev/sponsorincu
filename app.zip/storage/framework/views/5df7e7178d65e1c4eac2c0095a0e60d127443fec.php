


<?php $__env->startSection('content'); ?>

        <!--    PAGE HEAD-->
        <section class="page-head-section text-center py-5">
            <div class="container mt-5 pt-5">
                <h2>Training</h2>
                <p>
                    <a href="<?php echo e(route('homepage')); ?>">Home</a>
                    <span>/</span>
                    <span> Training</span>
                </p>
            </div>
        </section>
        <!--    PAGE HEAD END-->
    
        <!--    ABOUT SECTION-->
        <section class="about-section py-5">
            <div class="container">
                <div class="row align-items-center">
                    <div class="col-12 col-md-6">
                        <div class="about-image">
                            <img src="<?php echo e(asset('web')); ?>/images/photos/traning.png" alt="Image">
                        </div>
                    </div>
                    <div class="col-12 col-md-6">
                        <div class="about-text">
                            <h4><?php echo app('translator')->get('home.Join_the_team'); ?></h4>
                            <p>
                                <?php echo app('translator')->get('home.Join_the_team_p'); ?>
                                <br><br>
                                <?php echo app('translator')->get('home.You_can_now_register_on_Job'); ?>
                            </p>
                            <div>
                                <a href="https://jobincu.com/en/login" class="about-btn">Read More</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!--    ABOUT SECTION END-->
        
        <!--    TRANING JOIN SECTION-->
        <section class="traning-join-section py-5">
            <div class="container">
               <div class="row align-items-center">
                    <div class="col-12 col-md-6">
                    <div class="traning-join-left">
                        <h2>We offer <br> <span>career <br> opportunities</span> </h2>
                        <p>You can now register on Job Incubator through the link</p>
                    </div>
                </div>
                <div class="col-12 col-md-6">
                    <div class="traning-join-right w-100 text-md-center mt-4 mt-md-0">
                        <a href="#">Join us</a>
                    </div>
                </div>
               </div>
            </div>
        </section>
        <!--    TRANING JOIN SECTION EDN-->

        
    <?php echo $__env->make('web.component.brand', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>; 
    <?php echo $__env->make('web.component.subscribe', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>; 



<?php $__env->stopSection(); ?>


<?php echo $__env->make('web.layouts.app', ['title' => 'Traning'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\local_server\htdocs\blaghat\resources\views/web/traning.blade.php ENDPATH**/ ?>