<?php $__env->startSection('content'); ?>
    <!--    PAGE TITLE-->
    <section class="page-title py-5">
        <div class="container">
            <h2>ShoP New Arrival Products </h2>
            <a href="#">home</a>.
            <a href="javascript()">Pages</a>.
            <span>Shop New Arrival Products</span>
        </div>
    </section>
    <!--    PAGE  TITLE END-->


    <!--    PAGE HEAD-->
    <section class="page-head py-2">
        <div class="container">
            <div class="row">
                <div class="col-12 col-md-6 col-xl-4">
                    <div class="page-head-left">
                        <h6>All Categories Products</h6>
                        <span>Available <?php echo e($newarrival_product->count()); ?> products</span>
                    </div>
                </div>
                <div class="col-12 col-md-6 col-xl-8">
                    <div
                        class="page-head-right d-flex justify-content-start justify-content-md-end align-items-center mt-4 mt-md-0">
                        <div class="d-flex">
                            <span>Sort By</span>
                            <form action="#">
                                <select name="" id="">
                                    <option value="#">Best Match 2</option>
                                </select>
                            </form>
                        </div>
                        <div class="sort-by">
                            <span>Sort By</span>
                            <a href="#">
                                <img src="<?php echo e(asset('web')); ?>/images/icons/grid.png" alt="">
                            </a>
                            <a href="#">
                                <img src="<?php echo e(asset('web')); ?>/images/icons/list.png" alt="">
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--    PAGE HEAD END-->

    <!--    FETURE SECTION-->
    <section class="feture-section py-5">
        <div class="container">

            <div class="row">
                <?php $__currentLoopData = $newarrival_product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-12 col-sm-6 col-md-4 col-lg-3 mb-4">
                        <div class="product-box d-flex align-content-between flex-wrap">
                            <div class="product-image">
                                <img src="<?php echo e(asset($product->image)); ?>" alt="image">
                                <div class="cart-overlay2">
                                    <a href="javascript:void(0)" class="product_id" data-id="<?php echo e($product->id); ?>">
                                        <i class="far fa-shopping-cart"></i>
                                    </a>
                                    <a href="javascript:void(0)">
                                        <i class="far fa-heart"></i>
                                    </a>
                                    <a href="javascript:void(0)">
                                        <i class="fas fa-search-plus"></i>
                                    </a>
                                </div>
                            </div>
                            <div class="w-100 pb-3">
                                <div class="product-text2 mt-3">
                                    <h4><?php echo e($product->name); ?></h4>
                                    <div class="product-color">
                                        <span style="background: red;"></span>
                                        <span style="background: #EF8000;"></span>
                                        <span style="background: #cccccc;"></span>
                                    </div>
                                    <div class="price">
                                        <span>
                                            <?php if($product->active_price == 1): ?>
                                                <?php echo e($product->price); ?>

                                            <?php elseif($product->active_price ==2): ?>
                                                <?php echo e($product->discount_price); ?>

                                            <?php endif; ?>
                                        </span>
                                        <?php if($product->active_price == 2): ?>
                                            <span class="offer"><del><?php echo e($product->price); ?></del></span>
                                        <?php endif; ?>

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </section>
    <!--    FETURE SECTION END-->

    <?php echo $__env->make('web.component.parties', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;
<?php $__env->stopSection(); ?>

<?php echo $__env->make('web.layouts.app', ['title' => 'Offer Products'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\halalincu\resources\views/web/newarrival-product.blade.php ENDPATH**/ ?>