<?php $__env->startSection('content'); ?>

      <!--    HOME SECTION-->
      <section class="home-section clearfix py-5">
        <div class="container py-5">
            <div class="row">
                <div class="col-12 col-md-6">
                    <div class="home-left">
                        <div class="home-image pb-4">
                            <img src="<?php echo e('web'); ?>/images/photos/home.png" alt="Image" class="home-img">
                        </div>
                        <a href="<?php echo e(route('about')); ?>">Lets Know Our Company</a>

                        <div class="home-image py-4">
                            <img src="<?php echo e('web'); ?>/images/photos/phone.png" alt="" class="home-mobile">
                        </div>
                        <div>
                            <span>info@dajajahincu.com</span>
                        </div>
                    </div>
                </div>
                <div class="col-12 col-md-6 mt-5 mt-md-0">
                    <div class="home-right">

                        <ul class="nav nav-pills mb-3" id="pills-tab" role="tablist">
                            <li class="nav-item custom" role="presentation">
                                <button class="nav-link active" id="pills-home-tab" data-bs-toggle="pill" data-bs-target="#pills-home" type="button" role="tab" aria-controls="pills-home" aria-selected="true"></button>
                            </li>
                            <li class="nav-item custom" role="presentation">
                                <button class="nav-link" id="pills-profile-tab" data-bs-toggle="pill" data-bs-target="#pills-profile" type="button" role="tab" aria-controls="pills-profile" aria-selected="false"></button>
                            </li>
                            <li class="nav-item custom" role="presentation">
                                <button class="nav-link" id="pills-contact-tab" data-bs-toggle="pill" data-bs-target="#pills-contact" type="button" role="tab" aria-controls="pills-contact" aria-selected="false"></button>
                            </li>
                        </ul>
                        <div class="tab-content" id="pills-tabContent">
                            <div class="tab-pane fade show active" id="pills-home" role="tabpanel" aria-labelledby="pills-home-tab">
                                <form action="<?php echo e(route('login')); ?>" method="post">
                                    <?php echo csrf_field(); ?>
                                <div class="row px-5">
                                    <div class="col-12">
                                        <h2>Sign In</h2>
                                        <p class="login-p">Please login using account detail bellow.</p>
                                    </div>
                                    <div class="col-12 py-3">
                                        <input type="text" placeholder="Email Address" name="email" value="<?php echo e(old('email')); ?>">
                                        <span class="text-danger"><?php echo e($errors->first('email')); ?></span>
                                    </div>
                                    <div class="col-12 py-3">
                                        <input type="password" placeholder="Password" name="password">
                                        <span class="text-danger"><?php echo e($errors->first('password')); ?></span>
                                    </div>
                                    <div class="login-right pb-3 home-forget">
                                        <a href="#">Forgot your password?</a>
                                    </div>
                                    
                                  
                                    <div class="text-center home-signin">
                                        <button type="submit">Sign In</button>
                                    </div>
                                  
                                    
                                </div>
                            </form>
                            </div>


                            <div class="tab-pane fade" id="pills-profile" role="tabpanel" aria-labelledby="pills-profile-tab">.
                                <form action="<?php echo e(route('register')); ?>" method="post">
                                    <?php echo csrf_field(); ?>
                                <div class="row">
                                    <div class="col-12">
                                        <h2>Register your User now</h2>
                                    </div>
                                    <div class="col-6 py-3">
                                        <input type="text" placeholder="User Name" name="username" value="<?php echo e(old('username')); ?>">
                <span class="text-danger"><?php echo e($errors->first('username')); ?></span>
                                    </div>
                                    <div class="col-6 py-3">
                                        <input type="text" placeholder="Full Name" name="name" value="<?php echo e(old('name')); ?>">
                                        <span class="text-danger"><?php echo e($errors->first('name')); ?></span>
                                    </div>
                                    <div class="col-6 py-3">
                                        <input type="email" placeholder="Email Address" name="email" value="<?php echo e(old('email')); ?>">
                <span class="text-danger"><?php echo e($errors->first('email')); ?></span>
                                    </div>
                                    <div class="col-6 py-3">
                                        <input type="text" placeholder="Phone Number" name="phone" value="<?php echo e(old('phone')); ?>">
                <span class="text-danger"><?php echo e($errors->first('phone')); ?></span>
                                    </div>
                                    <div class="col-6 py-3">
                                        <input type="password" placeholder="Password" name="password">
                                        <span class="text-danger"><?php echo e($errors->first('password')); ?></span>
                                    </div>
                                    <div class="col-6 py-3">
                                        <input type="password" placeholder="Confirm Password" name="password_confirmation">
              <span class="text-danger"><?php echo e($errors->first('password_confirmation')); ?></span>
                                    </div>
                                    <div class="text-center home-signin">
                                        <button type="submit">Sign Up</button>
                                    </div>
                                 
                                </div>
                            </form>
                            </div>
                            <div class="tab-pane fade" id="pills-contact" role="tabpanel" aria-labelledby="pills-contact-tab">
                                <form action="<?php echo e(route('vendor.register')); ?>" method="post">
                                    <?php echo csrf_field(); ?>
                                
                                <div class="row">
                                    <div class="col-12">
                                        <h2>Register your company now</h2>
                                    </div>
                                    <div class="col-12 py-3">
                                        <input type="text" placeholder="User Name" name="username" value="<?php echo e(old('username')); ?>">
                                        <span class="text-danger"><?php echo e($errors->first('username')); ?></span>
                                    </div>
                                  
                                    <div class="col-12 py-3">
                                        <input type="text" placeholder="Company Name" name="company_name" value="<?php echo e(old('company_name')); ?>">
                                        <span class="text-danger"><?php echo e($errors->first('company_name')); ?></span>
                                    </div>
                                    <div class="col-6 py-3">
                                        <select id="" name="country_id">
                                            <option value="">select</option>
                                           <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($item->id); ?>" <?php echo e(old('country_id') == $item->id ? 'selected' : ''); ?>><?php echo e($item->name); ?></option>
                                           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                        <span class="text-danger"><?php echo e($errors->first('country_id')); ?></span>
                                    </div>
                                    <div class="col-6 py-3">
                                       
                                        <select name="city_id">
                                            <option value="">select</option>
                                            <?php $__currentLoopData = $cities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option  value="<?php echo e($item->id); ?>" <?php echo e(old('city_id') == $item->id ? 'selected' : ''); ?>><?php echo e($item->name); ?></option>
                                           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                         </select>
                                         <span class="text-danger"><?php echo e($errors->first('city_id')); ?></span>
                                        
                                    </div>
                                    <div class="col-6 py-3">
                                        <input type="text" placeholder="email" name="email" value="<?php echo e(old('email')); ?>">
                                        <span class="text-danger"><?php echo e($errors->first('email')); ?></span>
                                    </div>
                                    <div class="col-6 py-3">
                                        <input type="text" name="post" placeholder="post" value="<?php echo e(old('post')); ?>">
                                        <span class="text-danger"><?php echo e($errors->first('post')); ?></span>
                                    </div>
                                    <div class="col-6 py-3">
                                        <input type="password" placeholder="Password" name="password">
                                        <span class="text-danger"><?php echo e($errors->first('password')); ?></span>
                                    </div>
                                    <div class="col-6 py-3">
                                        <input type="password" placeholder="Confirm Password" name="password_confirmation">
              <span class="text-danger"><?php echo e($errors->first('password_confirmation')); ?></span>
                                    </div>
                                    <div class="text-right">
                                        <button type="submit">Confirm</button>
                                    </div>
                                </div>
                            </form>
                            </div>
                        </div>










                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--    HOME SECTION END-->

    <!--    BEST EVER SECTION-->
    <section class="best-ever py-5">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="section-title">
                        <h3><span>The best ever</span> DAJAJAH</h3>
                        <p><img src="<?php echo e('web'); ?>/images/icons/daimon.png" alt=""></p>
                        <h6>Register now for free</h6>
                    </div>
                </div>
            </div>
            <div class="row mt-3">
                <div class="col-12 col-md-6 pr-3 d-none d-md-block">
                    <div class="bese-ever-box base-ever-left">
                        <div class="d-flex justify-content-end align-items-center py-4">
                            <p>Fattening farms</p>
                            <span>
                                <img src="<?php echo e('web'); ?>/images/icons/hen.png" alt="">
                                <b class="bottom-dot"></b>
                            </span>
                        </div>
                        <div class="d-flex justify-content-end align-items-center py-4">
                            <p>Table egg production</p>
                            <span>
                                <img src="<?php echo e('web'); ?>/images/icons/egg.png" alt="">
                                <b class="top-dot"></b>
                                <b class="bottom-dot"></b>
                                <b class="border-line"></b>

                            </span>
                        </div>
                        <div class="d-flex justify-content-end align-items-center py-4">
                            <p>Every week supporting the poultry industry, creating value chains and employing 13 local staff</p>
                            <span>
                                <img src="<?php echo e('web'); ?>/images/icons/food-free.png" alt="">
                                <b class="top-dot"></b>
                                <b class="bottom-dot"></b>
                            </span>

                        </div>
                        <div class="d-flex justify-content-end align-items-center py-4">
                            <p>It is possible that the Department of Agriculture will not be able to follow the plan from following the special sections, except that it will be closed or open on the clock or as a special consultant.</p>
                            <span class="last">
                                <img src="<?php echo e('web'); ?>/images/icons/Pin.png" alt="">
                                <b class="top-dot"></b>

                            </span>

                        </div>
                    </div>
                </div>

                <div class="col-12 col-md-6 pl-3 d-block d-md-none">
                    <div class="bese-ever-box base-ever-right">
                        <div class="d-flex align-items-center py-4">
                            <span>
                                <img src="<?php echo e('web'); ?>/images/icons/egg.png" alt="">
                                <b class="top-dot"></b>
                                <b class="bottom-dot"></b>
                                <b class="border-line"></b>

                            </span>
                            <p>Table egg production</p>
                        </div>
                        <div class="d-flex align-items-center py-4">


                            <span>
                                <img src="<?php echo e('web'); ?>/images/icons/egg.png" alt="">
                                <b class="top-dot"></b>
                                <b class="bottom-dot"></b>
                                <b class="border-line"></b>

                            </span>
                            <p>Table egg production</p>
                        </div>
                        <div class="d-flex align-items-center py-4">


                            <span>
                                <img src="<?php echo e('web'); ?>/images/icons/food-free.png" alt="">
                                <b class="top-dot"></b>
                                <b class="bottom-dot"></b>
                            </span>
                            <p>Every week supporting the poultry industry, creating value chains and employing 13 local staff</p>

                        </div>
                        <div class="d-flex align-items-center py-4">


                            <span class="last">
                                <img src="<?php echo e('web'); ?>/images/icons/Pin.png" alt="">
                                <b class="top-dot"></b>

                            </span>
                            <p>It is possible that the Department of Agriculture will not be able to follow the plan from following the special sections, except that it will be closed or open on the clock or as a special consultant.</p>

                        </div>
                    </div>
                </div>

                <div class="col-12 col-md-6 pl-3">
                    <div class="bese-ever-box base-ever-right">
                        <div class="d-flex align-items-center py-4">

                            <span>
                                <img src="<?php echo e('web'); ?>/images/icons/Database%20Options.png" alt="">
                                <b class="bottom-dot"></b>
                            </span>
                            <p>Possibility of research on pharmaceutical and pharmaceutical products and mergers (trade name - composition - classification) </p>
                        </div>
                        <div class="d-flex align-items-center py-4">

                            <span>
                                <img src="<?php echo e('web'); ?>/images/icons/Gears.png" alt="">
                                <b class="top-dot"></b>
                                <b class="bottom-dot"></b>
                                <b class="border-line"></b>

                            </span>
                            <p>Registration in Dajajah is possible for individuals to communicate with companies and organizations in the organization and operations operations from products and services and forms in the form of a series of attractions</p>
                        </div>
                        <div class="d-flex align-items-center py-4">

                            <span>
                                <img src="<?php echo e('web'); ?>/images/icons/Error.png" alt="">
                                <b class="top-dot"></b>
                                <b class="bottom-dot"></b>
                            </span>
                            <p>Welcome to the slogans and warnings about training and the services that serve the medical medicine.</p>

                        </div>
                        <div class="d-flex align-items-center py-4">

                            <span class="last">
                                <img src="<?php echo e('web'); ?>/images/icons/Business.png" alt="">
                                <b class="top-dot"></b>

                            </span>
                            <p>Welcoming slogans and warnings and offers from companies and institutions</p>

                        </div>
                    </div>
                </div>

            </div>
        </div>


    </section>
    <!--    BEST EVER SECTION END-->

    <!--    PICTURE SECTION-->
    <section class="picture-section py-5">
        <div class="container">
            <div class="row">
                <div class="col-12 m">
                    <div class="section-title">
                        <h3><span>Pictures of </span>DAJAJAH</h3>
                        <p><img src="<?php echo e('web'); ?>/images/icons/daimon.png" alt=""></p>
                    </div>
                </div>
            </div>
            <div class="slider-array clearfix">
                <i class="fa-solid fa-angle-left prev"></i>
                <i class="fa-solid fa-angle-right next"></i>
                <div class="row mt-4">
                    <div class="picture_slider">
                        <div class="col-3 mx-2">
                            <div class="picture-box">
                                <img src="<?php echo e('web'); ?>/images/photos/phone2.png" alt="">
                            </div>
                        </div>
                        <div class="col-3 mx-2">
                            <div class="picture-box">
                                <img src="<?php echo e('web'); ?>/images/photos/phone2.png" alt="">
                            </div>
                        </div>
                        <div class="col-3 mx-2">
                            <div class="picture-box">
                                <img src="<?php echo e('web'); ?>/images/photos/phone2.png" alt="">
                            </div>
                        </div>
                        <div class="col-3 mx-2">
                            <div class="picture-box">
                                <img src="<?php echo e('web'); ?>/images/photos/phone2.png" alt="">
                            </div>
                        </div>
                        <div class="col-3 mx-2">
                            <div class="picture-box">
                                <img src="<?php echo e('web'); ?>/images/photos/phone2.png" alt="">
                            </div>
                        </div>
                        <div class="col-3 mx-2">
                            <div class="picture-box">
                                <img src="<?php echo e('web'); ?>/images/photos/phone2.png" alt="">
                            </div>
                        </div>
                        <div class="col-3 mx-2">
                            <div class="picture-box">
                                <img src="<?php echo e('web'); ?>/images/photos/phone2.png" alt="">
                            </div>
                        </div>
                        <div class="col-3 mx-2">
                            <div class="picture-box">
                                <img src="<?php echo e('web'); ?>/images/photos/phone2.png" alt="">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--    PICTURE SECTION END-->

    <!--    CONTACT SECTION-->
    <section class="cotact-section pt-5">
        <div class="container">
            <div class="row">
                <div class="row">
                    <div class="col-12 m">
                        <div class="section-title contact">
                            <h3><span></span>Call US</h3>
                            <p><img src="<?php echo e('web'); ?>/images/icons/daimon.png" alt=""></p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row align-items-center mt-5">
                <div class="col-12 col-md-4">
                    <div class="contact-box">
                        <h3>Contact Information</h3>
                        <div class="py-4">
                            <div class="contact-line py-2">
                                <img src="<?php echo e('web'); ?>/images/icons/Home.png" alt="">
                                <p>Riyadh - Saudi Arabia</p>
                            </div>
                            <div class="contact-line py-2">
                                <img src="<?php echo e('web'); ?>/images/icons/mail.png" alt="">
                                <p>info@poultry365.net</p>
                            </div>
                            <div class="contact-line py-2">
                                <img src="<?php echo e('web'); ?>/images/icons/world.png" alt="">
                                <p>www.dajajahincu.com</p>
                            </div>
                        </div>
                        <h3>Communication Pages</h3>
                        <div class="contact-social">
                            <a href="#">
                                <i class="fa-brands fa-facebook-square"></i>
                            </a>
                            <a href="#">
                                <i class="fa-brands fa-instagram-square"></i>
                            </a>
                            <a href="#">
                                <i class="fa-brands fa-twitter-square"></i>
                            </a>
                        </div>
                    </div>
                </div>
                <div class="col-12 col-md-4 pt-5 pt-md-0">
                    <div class="google-maps">
                        <iframe src="https://www.google.com/maps/embed?pb=!1m14!1m12!1m3!1d927764.3563817468!2d46.262013486343605!3d24.724150212660703!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!5e0!3m2!1sen!2sbd!4v1646050928874!5m2!1sen!2sbd" width="100%" height="400" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
                    </div>
                </div>
                <div class="col-12 col-md-4 pt-5 pt-md-0">
                    <div class="contact-form">
                        <h3>write to us</h3>
                        <form action="<?php echo e(route('contact.store')); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <input type="text" placeholder="Your Name(required)" name="name" value="<?php echo e(old('name')); ?>" required>
                            <span class="text-danger"><?php echo e($errors->first('name')); ?></span>
                            <input type="text" placeholder="Your Gmail(required)" name="email" value="<?php echo e(old('email')); ?>" required>
                            <span class="text-danger"><?php echo e($errors->first('email')); ?></span>
                            <textarea name="message" id="" cols="30" rows="10" placeholder="Your Message"><?php echo e(old('message')); ?></textarea>
                            <span class="text-danger"><?php echo e($errors->first('message')); ?></span>
                            <div>
                                <button type="submit">SUBMIT</button>
                            </div>
                        </form>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--    CONTACT SECTION END-->

<?php $__env->stopSection(); ?>


<?php echo $__env->make('web.layouts.app', ['title' => 'Home'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\local_server\htdocs\dajajah\resources\views/web/homepage.blade.php ENDPATH**/ ?>