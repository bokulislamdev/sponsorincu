



<?php $__env->startSection('content'); ?>

 <!--    PAGE TITLE-->
 <section class="page-title py-5">
  <div class="container">
      <h2>My Account</h2>
      <a href="#">Home</a>.
      <a href="javascript()">Pages</a>.
      <span>My Account</span>
  </div>
</section>
<!--    PAGE  TITLE END-->

<!--    LOGIN-->
<div class="section-login-section py-5">
  <div class="container">
      <div class="login-box">
          <h4>User Registration</h4>
          <p>Please User account detail bellow.</p>
          <form action="<?php echo e(route('register')); ?>" method="post">
              <?php echo csrf_field(); ?>
              <div>
                <input type="text" placeholder="User Name" name="username" value="<?php echo e(old('username')); ?>">
                <span class="text-danger"><?php echo e($errors->first('username')); ?></span>
              </div>
              <div>
                <input type="text" placeholder="Full Name" name="name" value="<?php echo e(old('name')); ?>">
                <span class="text-danger"><?php echo e($errors->first('name')); ?></span>
              </div>
               <div>
                <input type="email" placeholder="Email Address" name="email" value="<?php echo e(old('email')); ?>">
                <span class="text-danger"><?php echo e($errors->first('email')); ?></span>
              </div>
              <div>
                <input type="text" placeholder="Phone Number" name="phone" value="<?php echo e(old('phone')); ?>">
                <span class="text-danger"><?php echo e($errors->first('phone')); ?></span>
              </div>
              <div>
                <input type="password" placeholder="Password" name="password">
              <span class="text-danger"><?php echo e($errors->first('password')); ?></span>
              </div>
              <div>
                <input type="password" placeholder="Confirm Password" name="password_confirmation">
              <span class="text-danger"><?php echo e($errors->first('password_confirmation')); ?></span>
              </div>
              
              <div class="forget">
                  <a href="#">Forgot your password?</a>
              </div>
              <button type="submit">Signup</button>
              <div>
                  <p>have an Account? <a href="<?php echo e(route('login')); ?>">Login</a></p>
              </div>
          </form>
      </div>
  </div>
</div>
<!--    LOGIN END-->

<?php $__env->stopSection(); ?>


                  
       <!--end page main-->

         
        <!--end page main-->
    


<?php echo $__env->make('web.layouts.app', ['title' => 'User Register'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\halalincu\resources\views/auth/register.blade.php ENDPATH**/ ?>