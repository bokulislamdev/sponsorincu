



<?php $__env->startSection('content'); ?>


 <!--    PAGE HEAD SECTION-->
 <section class="page-head-section py-5">
  <div class="container">
      <div class="row">
          <div class="col-12">
              <h2><?php echo app('translator')->get('home.Create_account'); ?></h2>
              <p>
                  <span><?php echo app('translator')->get('home.Register_with_us'); ?></span>
              </p>
          </div>
      </div>
  </div>
</section>
<!--    PAGE HEAD SECTION END-->

<section class="signin-section py-5">
  <div class="container">
      <div class="signin-box">
          <ul class="nav nav-pills mb-3" id="pills-tab" role="tablist">
              <li class="nav-item" role="presentation">
                  <button class="nav-link active" id="pills-home-tab" data-bs-toggle="pill" data-bs-target="#pills-home" type="button" role="tab" aria-controls="pills-home" aria-selected="true"><?php echo app('translator')->get('home.As_sponsor'); ?></button>
              </li>
              <li class="nav-item" role="presentation">
                  <button class="nav-link" id="pills-profile-tab" data-bs-toggle="pill" data-bs-target="#pills-profile" type="button" role="tab" aria-controls="pills-profile" aria-selected="false"><?php echo app('translator')->get('home.As_organizer'); ?></button>
              </li>

          </ul>
          <div class="tab-content" id="pills-tabContent">
              <div class="tab-pane fade show active" id="pills-home" role="tabpanel" aria-labelledby="pills-home-tab">
                <form action="<?php echo e(route('register')); ?>" method="post">
                  <?php echo csrf_field(); ?>
                  <div class="input-box py-3">
                    <input type="text" placeholder="<?php echo app('translator')->get('home.User_Name'); ?>" name="username" value="<?php echo e(old('username')); ?>">
                      <i data-feather="user" class="input-icon"></i>
                  </div>
                  <span class="text-danger"><?php echo e($errors->first('username')); ?></span>
                  <div class="input-box py-3">
                    <input type="email" placeholder="<?php echo app('translator')->get('home.email_address'); ?>" name="email" value="<?php echo e(old('email')); ?>">
                      <i data-feather="mail" class="input-icon"></i>
                  </div>
                  <span class="text-danger"><?php echo e($errors->first('email')); ?></span>
                  <div class="input-box py-3">
                    <input type="password" placeholder="<?php echo app('translator')->get('home.password'); ?>" name="password">
                    
                      <i data-feather="lock" class="input-icon"></i>
                  </div>
                  <span class="text-danger"><?php echo e($errors->first('password')); ?></span>
                  <div class="input-box py-3">
                    <input type="password" placeholder="<?php echo app('translator')->get('home.confirm_password'); ?>" name="password_confirmation">
                      <i data-feather="lock" class="input-icon"></i>
                  </div>
                  <span class="text-danger"><?php echo e($errors->first('password_confirmation')); ?></span>
                  <div class="forget-password">
                      <a href="#"><?php echo app('translator')->get('home.Forgot_your_password'); ?></a>
                  </div>
                  <div class="signin-btn py-3">
                      <button type="submit"><?php echo app('translator')->get('home.Signup'); ?></button>
                  </div>
                  <div class="have-an-accound">
                      <p><?php echo app('translator')->get('home.have_an_Account'); ?>
                          <a href="<?php echo e(route('login')); ?>"> Sign in</a>
                      </p>
                  </div>
                  </form>
              </div>
              <div class="tab-pane fade" id="pills-profile" role="tabpanel" aria-labelledby="pills-profile-tab">
                <form action="<?php echo e(route('register')); ?>" method="post">
                  <?php echo csrf_field(); ?>
                      <div class="input-box py-3">
                        <input type="text" placeholder="<?php echo app('translator')->get('home.User_Name'); ?>" name="username" value="<?php echo e(old('username')); ?>">
                          <i data-feather="user" class="input-icon"></i>
                      </div>
                      <span class="text-danger"><?php echo e($errors->first('username')); ?></span>
                      <div class="input-box py-3">
                        <input type="email" placeholder="<?php echo app('translator')->get('home.email_address'); ?>" name="email" value="<?php echo e(old('email')); ?>">
                          <i data-feather="mail" class="input-icon"></i>
                      </div>
                      <span class="text-danger"><?php echo e($errors->first('email')); ?></span>
                      <div class="input-box py-3">
                        <input type="password" placeholder="<?php echo app('translator')->get('home.password'); ?>" name="password">
                        
                          <i data-feather="lock" class="input-icon"></i>
                      </div>
                      <span class="text-danger"><?php echo e($errors->first('password')); ?></span>
                      <div class="input-box py-3">
                        <input type="password" placeholder="<?php echo app('translator')->get('home.confirm_password'); ?>" name="password_confirmation">
                          <i data-feather="lock" class="input-icon"></i>
                      </div>
                      <span class="text-danger"><?php echo e($errors->first('password_confirmation')); ?></span>
                      <div class="forget-password">
                          <a href="#"><?php echo app('translator')->get('home.Forgot_your_password'); ?></a>
                      </div>
                      <div class="signin-btn py-3">
                          <button type="submit"><?php echo app('translator')->get('home.Signup'); ?></button>
                      </div>
                      <div class="have-an-accound">
                          <p><?php echo app('translator')->get('home.have_an_Account'); ?>
                              <a href="<?php echo e(route('login')); ?>"> Sign in</a>
                          </p>
                      </div>
                  </form>
              </div>

          </div>

      </div>
  </div>
</section>



  
  <!--    LOGIN SECTION-->
  
  <!--    LOGIN SECTION END-->



<!--    LOGIN-->

<!--    LOGIN END-->

<?php $__env->stopSection(); ?>


                  
       <!--end page main-->

         
        <!--end page main-->
    


<?php echo $__env->make('web.layouts.app', ['title' => 'User Register'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\local_server\htdocs\sponser\resources\views/auth/register.blade.php ENDPATH**/ ?>