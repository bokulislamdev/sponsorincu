<div class="total-shipping">
    <span>Subtotals:</span>
    <span>SAR <?php echo e(Cart::subtotal()); ?></span>
</div>
<div class="total-shipping">
    <span>Tex:</span>
    <span>SAR <?php echo e(Cart::tax()); ?></span>
</div>
<div class="total-shipping">
    <span>Totals:</span>
    <span>SAR <?php echo e(Cart::total()); ?></span>
</div>

<?php /**PATH D:\local_server\htdocs\halalincu2\halalincu\resources\views/web/component/loadtotal.blade.php ENDPATH**/ ?>