<!--    PARTIES-->
<section class="parties-section py-5">
    <div class="container-fluid">
        <div class="marties-box custom-row d-flex align-items-center justify-content-center mt-5">
            <a href="#">
                <img src="<?php echo e(asset('web')); ?>/images/parties/1.png" alt="">
            </a>
            <a href="#">
                <img src="<?php echo e(asset('web')); ?>/images/parties/2.png" alt="">
            </a>
            <a href="#">
                <img src="<?php echo e(asset('web')); ?>/images/parties/3.png" alt="">
            </a>
            <a href="#">
                <img src="<?php echo e(asset('web')); ?>/images/parties/4.png" alt="">
            </a>
            <a href="#">
                <img src="<?php echo e(asset('web')); ?>/images/parties/5.png" alt="">
            </a>
            <a href="#">
                <img src="<?php echo e(asset('web')); ?>/images/parties/6.png" alt="">
            </a>
            <a href="#">
                <img src="<?php echo e(asset('web')); ?>/images/parties/7.png" alt="">
            </a>
            <a href="#">
                <img src="<?php echo e(asset('web')); ?>/images/parties/8.png" alt="">
            </a>
            <a href="#">
                <img src="<?php echo e(asset('web')); ?>/images/parties/9.png" alt="">
            </a>
        </div>
    </div>
</section>
<!--    PARTIES END-->
<?php /**PATH D:\halalincu\resources\views/web/component/parties.blade.php ENDPATH**/ ?>