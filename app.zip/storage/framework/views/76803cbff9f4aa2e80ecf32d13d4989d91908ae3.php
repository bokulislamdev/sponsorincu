<?php $__env->startSection('content'); ?>

      <!--    PAGE TITLE-->
      <section class="page-title py-5">
        <div class="container">
            <h2>FAQ</h2>
            <a href="<?php echo e(route('homepage')); ?>">Home</a>.
            <a href="#">Pages</a>.
            <span>FAQ</span>

        </div>
    </section>
    <!--    PAGE  TITLE END-->



    <!--    CONTACT MAIN-->
    <div class="contact-main py-5">
        <div class="container">
           <div class="row get-touch">
               <h2>Get In Touch</h2>
           </div>
            <div class="row">
                <div class="col-12 col-lg-6">
                    <div class="contact-form faq-content">
                        <div class="faq-box py-2">
                            <h6>Lorem ipsum dolor sit amet, consectetur adipiscing elit?</h6>
                            <p>
                                Lorem ipsum dolor sit amet, consectetur adipiscing elit. Tincidunt sed tristique mollis vitae, consequat gravida sagittis.
                            </p>
                        </div>
                        <div class="faq-box py-2">
                            <h6>Lorem ipsum dolor sit amet, consectetur adipiscing elit?</h6>
                            <p>
                                Lorem ipsum dolor sit amet, consectetur adipiscing elit. Tincidunt sed tristique mollis vitae, consequat gravida sagittis.
                            </p>
                        </div>
                        <div class="faq-box py-2">
                            <h6>Lorem ipsum dolor sit amet, consectetur adipiscing elit?</h6>
                            <p>
                                Lorem ipsum dolor sit amet, consectetur adipiscing elit. Tincidunt sed tristique mollis vitae, consequat gravida sagittis.
                            </p>
                        </div>
                        <div class="faq-box py-2">
                            <h6>Lorem ipsum dolor sit amet, consectetur adipiscing elit?</h6>
                            <p>
                                Lorem ipsum dolor sit amet, consectetur adipiscing elit. Tincidunt sed tristique mollis vitae, consequat gravida sagittis.
                            </p>
                        </div>
                    </div>
                </div>
                <div class="col-12 col-lg-6">
                    <div class="contact-form faq-content">
                        <h3>Ask a Question</h3>

                        <form action="<?php echo e(route('contact.store')); ?>" class="mt-5" method="POST">
                            <?php echo csrf_field(); ?>
                            <div class="row">
                                <div class="col-12 py-2">
                                    <input type="text" placeholder="Your Name*" name="name" value="<?php echo e(old('name')); ?>">
                                    <p class="text-danger"><?php echo e($errors->first('name')); ?></p>
                                    <input type="hidden" name="status" value="1">
                                </div>

                                <div class="col-12 py-2">
                                    <input type="text" placeholder="Subject*" name="subject" value="<?php echo e(old('subject')); ?>">
                                    <p class="text-danger"> <?php echo e($errors->first('subject')); ?></p>
                                </div>

                                <div class="col-12 py-2">
                                    <textarea name="message" id="" cols="30" rows="10" placeholder="Type Your Messege*"><?php echo e(old('message')); ?></textarea>
                                    <p class="text-danger"><?php echo e($errors->first('message')); ?></p>
                                </div>
                                <div class="mt-4">
                                   <button type="submit">Send Mail</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--    CONTACT MAIN END-->

<?php $__env->stopSection(); ?>


<?php echo $__env->make('web.layouts.app', ['title' => 'Faq'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\halalincu\resources\views/web/faq.blade.php ENDPATH**/ ?>