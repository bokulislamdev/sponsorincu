


<?php $__env->startSection('content'); ?>
  
    <!--    PAGE TITLE-->
    <section class="page-title py-5" style=" background-image: linear-gradient(rgba(0, 0, 0, 0.4),rgba(0, 0, 0, 0.37)), url(<?php echo e(asset('web')); ?>/images/photos/header-page.png);">
        <div class="container">
            <a href="<?php echo e(route('homepage')); ?>">Home</a>
            <span>></span>
            <a href="<?php echo e(route('product')); ?>">Products</a>
            <h5>Feeds</h5>
        </div>
    </section>
    <!--    PAGE TITLE END-->



    <!--    PRODUCT PAGE-->
    <section class="product-section pt-5">
        <div class="container">
            <div class="row mt-5">
                <?php $__currentLoopData = $feeds; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-12 col-sm-6 col-md-4 col-lg-3 pb-4">
                    <div class="hot-product-box">
                        <div class="hot-product-img">
                            <a href="<?php echo e(route('product.details',$item->slug)); ?>">
                                <img src="<?php echo e(asset($item->image)); ?>" alt="Product Photo">
                            </a>
                            <div class="hot-product-img-overlay">
                                <p><?php echo e($item->name); ?></p>
                            </div>
                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </section>
    <!--    PRODUCT PAGE END-->



    <?php echo $__env->make('web.component.service', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('web.layouts.app', ['title' => 'Feeds'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\local_server\htdocs\dajajah\resources\views/web/feeds.blade.php ENDPATH**/ ?>