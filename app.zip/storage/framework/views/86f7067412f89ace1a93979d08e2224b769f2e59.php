<?php $__env->startPush('css'); ?>
<style>
    .mySlides {
        display: none;
        display: block;
        border: 1px solid #cccccc;
        padding: 20px;
        margin-bottom: 10px;
    }

    .mySlides img {
        width: 100%;
    }

    .slider-under-line {
        border: 1px solid #cccccc;
        padding: 5px;
        display: -webkit-box;
        display: -ms-flexbox;
        display: flex;
        -webkit-box-align: center;
        -ms-flex-align: center;
        align-items: center;
        overflow: hidden;
        overflow: auto;
    }

    /* scrollbar*/
    /* width */
    .slider-under-line::-webkit-scrollbar {
        width: 100%;
        height: 4px;
        color: #ffffff;
    }

    .slider-under-line::-webkit-scrollbar-track {
        -webkit-box-shadow: inset 0 0 5px #cccccc;
        box-shadow: inset 0 0 5px #cccccc;
        border-radius: 10px;
    }

    .slider-under-line::-webkit-scrollbar-thumb {
        background: #cccccc;
        border-radius: 10px;
    }

    .slider-under-line::-webkit-scrollbar-thumb:hover {
        background: #cccccc;
    }

    .show-main-slider {
        position: relative;
    }

    /* scrollbar*/
    .product-single-image img {
        width: 80px;
    }


    .cursor {
        cursor: pointer;
    }

    .cursor {
        border: 1px solid #ffffff;
        padding: 2px;
    }

    .cursor.active {
        border: 1px solid #cccccc;
    }

    /* Next & previous buttons */
    .slider-prev,
    .slider-next {
        cursor: pointer;
        position: absolute;
        top: 50%;
        -webkit-transform: translateY(-50%);
        -ms-transform: translateY(-50%);
        transform: translateY(-50%);
        width: auto;
        padding: 6px;
        font-size: 18px;
        border-radius: 0 3px 3px 0;
        -moz-user-select: none;
        -ms-user-select: none;
        user-select: none;
        -webkit-user-select: none;
        background: #cccccc;
        text-decoration: none;
        color: #ffffff;
    }

    a:hover {
        color: #ffffff;
    }

    .slider-next {
        right: 0;
        border-radius: 3px 0 0 3px;
    }

    .row:after {
        content: "";
        display: table;
        clear: both;
    }

    .demo {
        opacity: 0.7;
    }

    .active,
    .demo:hover {
        opacity: 1;
    }

</style>

<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
  <!--    PAGE TITLE-->
  <section class="page-title py-5" style=" background-image: linear-gradient(rgba(0, 0, 0, 0.4),rgba(0, 0, 0, 0.37)), url(<?php echo e(asset('web')); ?>/images/photos/header-page.png);">
    <div class="container">
        <a href="<?php echo e(route('homepage')); ?>">Home</a>
        <span>></span>
        <a href="<?php echo e(route('product')); ?>">Products</a>
        <span>></span>
        <span><?php echo e($product->name); ?></span>
        <h5>Details/Overview</h5>
    </div>
</section>
<!--    PAGE TITLE END-->

<!--    PRODUCT DETAILS-->
<div class="product-details py-5">
    <div class="container">
        <div class="row">
            <div class="col-12 col-md-6">
                <div class="show-main-slider">
                    <div class="mySlides">
                        <img src="<?php echo e(asset($product->image)); ?>">
                    </div>
                    <?php $__currentLoopData = $multi_images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="mySlides">
                        <img src="<?php echo e(asset($item->multi_image)); ?>">
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    
                    <a class="slider-prev" onclick="plusSlides(-1)">❮</a>
                    <a class="slider-next" onclick="plusSlides(1)">❯</a>
                </div>

                <div class="slider-under-line clearfix">
                    <div class="product-single-image">
                        <img class="demo cursor" src="<?php echo e(asset($product->image)); ?>" onclick="currentSlide(1)">
                    </div>
                    <?php $__currentLoopData = $multi_images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="product-single-image">
                        <img class="demo cursor" src="<?php echo e(asset($item->multi_image)); ?>" onclick="currentSlide(<?php echo e($loop->iteration + 1); ?>)">
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                   
                </div>
            </div>


            <div class="col-12 col-md-6 mt-5 mt-md-0">
                <div class="product-details  d-flex align-content-between flex-wrap h-100">
                    <div class="w-100">
                        <h4><?php echo e($product->name); ?></h4>
                    <div class="py-2">
                        <?php echo $product->short_descriprion; ?>

                    </div>


                    <?php if($product->type !== 'service'): ?>
                    <div class="d-flex product-p">
                        <p>Price : SAR  </p>
                        <?php if($product->active_price == 1 ): ?>
                            <p><?php echo e($product->price); ?></p>
                        <?php elseif($product->active_price == 2): ?>
                            <p><?php echo e($product->discount_price); ?>  </p>
                            <p><del class="text-danger" style="margin-left: 10px;">SAR <?php echo e($product->price); ?></del></p>
                        <?php endif; ?>

                        <p></p>
                    </div>
                    <?php endif; ?>

                    <?php if($product->type == 'feed'): ?>
                    <div class="d-flex product-p">
                        <p>Color :</p>
                        <p> <?php echo e($product->color); ?></p>
                    </div>
                    <?php endif; ?>


                    <?php if($product->type !== 'service'): ?>
                    <div class="d-flex product-p">
                        <p>Category :</p>
                        <p> <?php echo e($product->productcategory ? $product->productcategory->name : ''); ?></p>
                    </div>
                    <div class="d-flex product-p">
                        <p>Brand :</p>
                        <p> <?php echo e($product->brand); ?></p>
                    </div>
                    <?php endif; ?>
                    
                    <?php if($product->type == 'feed'): ?>
                    <div class="d-flex product-p">
                        <p>Package Size :</p>
                        <p> <?php echo e($product->package_size); ?></p>
                    </div>
                    <div class="d-flex product-p">
                        <p>Package Type :</p>
                        <p> <?php echo e($product->package_type); ?></p>
                    </div>
                    
                    <div class="d-flex product-p">
                        <p>Cas No :</p>
                        <p> <?php echo e($product->cas); ?></p>
                    </div>
                    <?php endif; ?>
                    </div>


                    <div class="w-100">
                        <div class="row py-4">
                            <div class="col-6 ">
                                <div class="product-contact d-flex align-items-center">
                                    <img src="images/icons/Gmail%20logo.png" alt="">
                                    <p>info@dejajahincu.com</p>
                                </div>
                            </div>
                            <div class="col-6">
                                <div class="product-contact d-flex align-items-center">
                                    <img src="images/icons/Ringing%20Phone.png" alt="">
                                    <p>WhatsApp: +8801534705690</p>
                                </div>
                            </div>
                        </div>
    
    
    
                        <?php if($product->type == 'service'): ?>
                        <div class="row">
                            <div class="col-12">
                                <div class="row">
                                    <div class="col-6 product-chat">
                                        <a href="<?php echo e(route('contact')); ?>">
                                            <img src="<?php echo e(asset('web')); ?>/images/icons/Chat.png" alt="">
                                            Get Price
                                        </a>
                                    </div>
                                    <div class="col-6 product-chat">
                                        <a href="javascript:void(0)">
                                            <img src="<?php echo e(asset('web')); ?>/images/icons/Inscription.png" alt="">
                                            Free Live Chat
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <?php else: ?>
                        <div class="row">
                            <div class="col-12">
                                <div class="row">
                                    <div class="col-6 product-chat">
                                        <a href="javascript:void(0)" class="product_id py-2" data-id="<?php echo e($product->id); ?>">
                                            <i data-feather="shopping-cart"></i>
                                            Cert
                                        </a>
                                    </div>
                                    <div class="col-6 product-chat">
                                        <a href="javascript:void(0)" class="wish_cliak py-2" data-id="<?php echo e($product->id); ?>">
                                            <i data-feather="heart"></i>
                                            Wishlist
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <?php endif; ?>
                    </div>
                   
                </div>
            </div>
        </div>
        
        
        <div class="row mt-5">
            <div class="product-description">
                <h6><img src="<?php echo e(asset('web')); ?>/images/icons/des.png" alt="">Technical Data</h6>

                <div class="py-3 product-description-p">
                   <?php echo $product->long_description; ?>

                </div>
            </div>
        </div>
    </div>
</div>
<!--    PRODUCT DETAILS END-->




<?php $__env->stopSection(); ?>


<?php $__env->startPush('js'); ?>
<script>
    var slideIndex = 1;
    showSlides(slideIndex);

    function plusSlides(n) {
        showSlides(slideIndex += n);
    }

    function currentSlide(n) {
        showSlides(slideIndex = n);
    }

    function showSlides(n) {
        var i;
        var slides = document.getElementsByClassName("mySlides");
        var dots = document.getElementsByClassName("demo");
        var captionText = document.getElementById("caption");
        if (n > slides.length) {
            slideIndex = 1
        }
        if (n < 1) {
            slideIndex = slides.length
        }
        for (i = 0; i < slides.length; i++) {
            slides[i].style.display = "none";
        }
        for (i = 0; i < dots.length; i++) {
            dots[i].className = dots[i].className.replace(" active", "");
        }
        slides[slideIndex - 1].style.display = "block";
        dots[slideIndex - 1].className += " active";
        captionText.innerHTML = dots[slideIndex - 1].alt;
    }

</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('web.layouts.app', ['title' => 'Products Details'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\local_server\htdocs\dajajah\resources\views/web/product-details.blade.php ENDPATH**/ ?>