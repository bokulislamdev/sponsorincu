        <!-- =====================================================================
          BRAND SECTION START
  =============================================================================-->

  <section class="brand-section">
    <div class="container">
      <div class="row">
        <div class="col-lg-2 col-md-4 col-sm-6">
          <div class="brand-img">
            <a href="https://www.riadahin.com/en">
              <img src="<?php echo e(asset('web')); ?>/brands/brand1.png" alt="...">
            </a>
          </div>
        </div>

        <div class="col-lg-2 col-md-4 col-sm-6">
          <div class="brand-img">
            <a href="https://jobincu.com/en ">
              <img src="<?php echo e(asset('web')); ?>/brands/brand2.png" alt="...">
            </a>
          </div>
        </div>

        <div class="col-lg-2 col-md-4 col-sm-6">
          <div class="brand-img">
            <a href="http://workerksa.com">
              <img src="<?php echo e(asset('web')); ?>/brands/brand3.png" alt="...">
            </a>
          </div>
        </div>

        <div class="col-lg-2 col-md-4 col-sm-6">
          <div class="brand-img">
            <a href="http://trincu.com">
              <img src="<?php echo e(asset('web')); ?>/brands/brand4.png" alt="...">
            </a>
          </div>
        </div>

        <div class="col-lg-2 col-md-4 col-sm-6">
          <div class="brand-img">
            <a href="https://eventincu.com">
              <img src="<?php echo e(asset('web')); ?>/brands/brand5.png" alt="...">
            </a>
           
          </div>
        </div>

        <div class="col-lg-2 col-md-4 col-sm-6">
          <div class="brand-img">
            <a href="http://saudihemam.com/ ">
              <img src="<?php echo e(asset('web')); ?>/brands/brand6.png" alt="...">
            </a>
            
          </div>
        </div>
      </div>
    </div>
  </section>


  <!-- =====================================================================
          BRAND SECTION END
=============================================================================--><?php /**PATH D:\local_server\htdocs\blaghat\resources\views/web/component/client.blade.php ENDPATH**/ ?>