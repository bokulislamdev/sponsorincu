<?php $__env->startSection('content'); ?>
<!--start content-->
<main class="page-content">
<!--breadcrumb-->
<div class="page-breadcrumb d-none d-sm-flex align-items-center py-2 px-3" style="background: rgb(46 57 78);">
    <div class="pe-3"><h5 class="text-white m-0">Product Create</h5></div>
    <div class="ms-auto">
    <a href="<?php echo e(route('vendor.product.index')); ?>" class="btn btn-primary custom-head-link"> <i class="fadeIn animated bx bx-undo"></i> Back To Product  List</a>
    </div>
</div>
<!--end breadcrumb-->

<div class="card">
    <div class="card-body">



        <form action="<?php echo e(route('vendor.product.store')); ?>" method="post" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="row">
                <div class="col-12 col-md-6 py-2">
                    <label for="" class="form-label"> Name <span class="text-danger">*</span></label>
                    <input type="text" class="form-control" name="name" value="<?php echo e(old('name')); ?>">
                    <span class="text-danger"><?php echo e($errors->first('name')); ?></span>
                </div>

                <div class="col-12 col-md-6 py-2">
                    <label for="" class="form-label">Arabic Name</label>
                    <input type="text" class="form-control" name="name_ar" value="<?php echo e(old('name_ar')); ?>">
                    <span class="text-danger"><?php echo e($errors->first('name_ar')); ?></span>

                </div>

                


                <div class="col-12 col-md-6 py-2">
                    <label> Product Category</label>
                    <select name="category_id" class="form-control">
                        <option value="">select</option>
                        <?php $__currentLoopData = $product_categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($item->id); ?>" <?php echo e(old('category_id') == $item->id ? 'selected' : ''); ?>><?php echo e($item->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <small class="form-text text-danger"><?php echo e($errors->first('category_id')); ?></small>
                </div>


                <div class="col-12 col-md-6 py-2">
                    <label for="" class="form-label">Tag <span class="text-danger">*</span></label>
                    <input type="text" class="form-control" name="tag" value="<?php echo e(old('tag')); ?>">
                    <span class="text-danger"><?php echo e($errors->first('tag')); ?></span>
                </div>

                <div class="col-12 col-md-6 py-2">
                    <label> Color ID</label>
                    <select name="color_id" class="form-control">
                        <option value="">select</option>
                        <?php $__currentLoopData = $product_colors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($item->id); ?>"><?php echo e($item->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <small class="form-text text-danger"><?php echo e($errors->first('color_id')); ?></small>
                </div>


                <div class="col-12 col-md-6 py-2">
                    <label for="" class="form-label">Product Price <span class="text-danger">*</span></label>
                    <input type="text" class="form-control" name="price" value="<?php echo e(old('price')); ?>">
                    <span class="text-danger"><?php echo e($errors->first('price')); ?></span>
                </div>


                <div class="col-12 col-md-6 py-2">
                    <label for="" class="form-label">Discount Price <span class="text-danger">*</span></label>
                    <input type="text" class="form-control" name="discount_price" value="<?php echo e(old('discount_price')); ?>">
                    <span class="text-danger"><?php echo e($errors->first('discount_price')); ?></span>
                </div>

                <div class="col-12 col-md-6 py-2">
                    <label for="" class="form-label">Active Price <span class="text-danger">*</span></label>
                    <select name="active_price" class="form-control">
                            <option value="1" <?php echo e(old('active_price') == 1 ? 'selected' : ''); ?>>Regular Price</option>
                            <option value="2" <?php echo e(old('active_price') == 2 ? 'selected' : ''); ?>>Discount Price</option>
                    </select>
                    <span class="text-danger"><?php echo e($errors->first('active_price')); ?></span>

                </div>

                <div class="col-12 col-md-6 py-2">
                    <label for="" class="form-label">Image <span class="text-danger">*</span></label>
                    <input type="file" class="form-control" name="image">
                    <span class="text-danger"><?php echo e($errors->first('image')); ?></span>

                </div>

                <div class="col-12 col-md-6 py-2">
                    <label for="" class="form-label">Multiple Image</label>
                    <input type="file" class="form-control" name="multi_image[]" multiple>

                </div>

                <div class="col-12 col-md-6 py-2">
                    <label for="" class="form-label">Video <span class="text-danger">*</span></label>
                    <input type="text" class="form-control" name="video" value="<?php echo e(old('video')); ?>">
                    <span class="text-danger"><?php echo e($errors->first('video')); ?></span>

                </div>

                <div class="col-12  py-2">
                    <label for="" class="form-label">Additional Information <span class="text-danger">*</span></label>
                   <textarea name="additional_info" id="" cols="30" rows="10" class="form-control summernote"><?php echo e(old('additional_info')); ?></textarea>
                    <span class="text-danger"><?php echo e($errors->first('additional_info')); ?></span>
                </div>

                <div class="col-12  py-2">
                    <label for="" class="form-label">Arabic Additional Information <span class="text-danger">*</span></label>
                   <textarea name="additional_info_ar" id="" cols="30" rows="10" class="form-control summernote"><?php echo e(old('additional_info_ar')); ?></textarea>
                    <span class="text-danger"><?php echo e($errors->first('additional_info_ar')); ?></span>

                </div>


                <div class="col-12 py-2">
                    <label for="" class="form-label">Short Description <span class="text-danger">*</span></label>
                    <textarea name="short_descriprion" cols="30" rows="10" class="form-control summernote"> <?php echo e(old('short_descriprion')); ?></textarea>
                    <span class="text-danger"><?php echo e($errors->first('short_descriprion')); ?></span>

                </div>


                <div class="col-12 py-2">
                    <label for="" class="form-label">Arabic Short Description <span class="text-danger">*</span></label>
                    <textarea name="short_descriprion_ar" cols="30" rows="10" class="form-control summernote"> <?php echo e(old('short_descriprion_ar')); ?></textarea>
                    <span class="text-danger"><?php echo e($errors->first('short_descriprion_ar')); ?></span>

                </div>





                <div class="col-12 py-2">
                    <label for="" class="form-label">Long Description <span class="text-danger">*</span></label>
                    <textarea name="long_description" cols="30" rows="10" class="form-control summernote"> <?php echo e(old('long_description')); ?></textarea>

                    <span class="text-danger"><?php echo e($errors->first('long_description')); ?></span>

                </div>

                <div class="col-12 py-2">
                    <label for="" class="form-label">Arabic Long Description <span class="text-danger">*</span></label>
                    <textarea name="long_description_ar" cols="30" rows="10" class="form-control summernote"> <?php echo e(old('long_description_ar')); ?></textarea>

                    <span class="text-danger"><?php echo e($errors->first('long_description_ar')); ?></span>

                </div>

                
                <div class="col-12">
                    <div class="d-flex d-flex justify-content-start">
                        <div style="margin-right: 30px;">
                            <input type="checkbox" name="feture" value="1" <?php echo e(old('feture') == 1 ? 'checked' : ''); ?>>
                            <label for="">Feture Product</label>

                        </div>
                        <div style="margin-right: 30px;">
                            <input type="checkbox" name="trending" value="1" <?php echo e(old('trending') == 1 ? 'checked' : ''); ?>>
                            <label for="">Trending Product</label>

                        </div>
                        <div>
                            <input type="checkbox" name="special_offer" value="1" <?php echo e(old('special_offer') == 1 ? 'checked' : ''); ?>>
                            <label for="">Special Offer</label>

                        </div>
                    </div>
                </div>





                <div class="col-12 text-center mt-5">
                    <a href="<?php echo e(route('admin.product.index')); ?>" class="btn btn-warning" style="margin-right: 20px;">Cancel</a>
                    <button type="submit" class="btn btn-primary">Create</button>

                </div>

            </div>
        </form>
    </div>
    </div>


</main>
<!--end page main-->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('account.layouts.app',['title' => 'Create Product'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\halalincu\resources\views/account/vendor/product/create.blade.php ENDPATH**/ ?>