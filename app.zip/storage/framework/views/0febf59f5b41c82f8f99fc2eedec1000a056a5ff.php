    <!--    FOOTER-->
    <footer class="py-5">
      <div class="container">
          <div class="footer-main">
              <div class="row">
                  <div class="col-12 col-sm-6 col-lg-3 mb-5 mb-lg-0">
                      <div class="footer-head">
                          <div class="logo mb-3">
                              <a href="<?php echo e(route('homepage')); ?>">
                                  <img src="<?php echo e(asset('web')); ?>/images/logo/logo.png" alt="">
                              </a>
                          </div>
                          <p>
                              Blaghat is a confidential and reliable platform to monitor and detect reports under one platform
                          </p>
                          <div class="social-icons mt-3">
                              <a href="javascript:void(0)">
                                  <i class="fab fa-facebook-f"></i>
                              </a>
                              <a href="javascript:void(0)">
                                  <i class="fab fa-twitter"></i>
                              </a>
                              <a href="javascript:void(0)">
                                  <i class="fab fa-linkedin-in"></i>
                              </a>
                              <a href="javascript:void(0)">
                                  <i class="fab fa-instagram"></i>
                              </a>
                              <a href="javascript:void(0)">
                                  <i class="fab fa-pinterest-p"></i>
                              </a>
                          </div>
                      </div>
                  </div>
                  <div class="col-12 col-sm-6 col-lg-3 mb-5 mb-lg-0">
                      <div class="footer-head">
                          <h6 class="bottom-border"><?php echo app('translator')->get('home.About_Us'); ?></h6>
                          <ul>
                              <li><a href="<?php echo e(route('homepage')); ?>"><?php echo app('translator')->get('home.Homepage'); ?></a></li>
                              <li><a href="javascript:void(0)"><?php echo app('translator')->get('home.Accounts'); ?></a></li>
                              <li><a href="javascript:void(0)">Blog</a></li>
                              <li><a href="javascript:void(0)">Career</a></li>
                              <li><a href="<?php echo e(route('contact')); ?>"><?php echo app('translator')->get('home.contact_us'); ?></a></li>
                          </ul>
                      </div>
                  </div>
                  <div class="col-12 col-sm-6 col-lg-3 mb-5 mb-lg-0">
                      <div class="footer-head">
                          <h6 class="bottom-border">Important Link</h6>
                          <ul>
                              <li><a href="<?php echo e(route('awareness')); ?>"><?php echo app('translator')->get('home.Awareness'); ?></a></li>
                              <li><a href="<?php echo e(route('services')); ?>"><?php echo app('translator')->get('home.Our_Services'); ?></a></li>
                              <li><a href="<?php echo e(route('partner')); ?>"><?php echo app('translator')->get('home.Our_partners'); ?></a></li>
                              <li><a href="<?php echo e(route('traning')); ?>"><?php echo app('translator')->get('home.Training'); ?></a></li>

                          </ul>
                      </div>
                  </div>
                  <div class="col-12 col-sm-6 col-lg-3 mb-5 mb-lg-0">
                      <div class="footer-head">
                          <h6><?php echo app('translator')->get('home.contact_us'); ?></h6>



                          <ul>
                              <li class="mt-1">
                                  <i class="footer-feather" data-feather="phone-call"></i>
                                  <span>+966 55 117 5959 </span>
                              </li>
                              <li class="mt-3">
                                  <i class="footer-feather" data-feather="mail"></i>
                                  <span>info@workerksa.com</span>
                              </li>

                          </ul>

                          <form action="<?php echo e(route('contact.store')); ?>" class="subscribe-form mt-4" method="post">
                            <?php echo csrf_field(); ?>
                              <input type="text" placeholder="Email" name="email">
                              <button type="submit" class="submit-overlay">
                                  <i class="email-feather" data-feather="navigation"></i>
                              </button>
                          </form>
                          
                      </div>
                  </div>
              </div>
          </div>
      </div>
  </footer>
  <!--    FOOTER END-->

  <!--    COPYRIGHT-->
  <section class="copyright-section">
      <div class="container">
          <div class="copyright-content">
              <div class="row">
                  <div class="col-12 col-lg-6">
                      <div class="copyright-left">
                          <p>Copyright © 2022 Dajajah Incubator. All Rights Reserved.</p>
                      </div>
                  </div>
                  <div class="col-12 col-lg-6">
                      <div class="copyright-right">
                          <a href="#">
                              Terms & Condition
                          </a>
                          <a href="#">
                              Privacy Policy
                          </a>
                          <a href="#">
                              Help
                          </a>
                      </div>
                  </div>
              </div>

          </div>
      </div>
  </section>
  <!--    COPYRIGHT END--><?php /**PATH D:\local_server\htdocs\blaghat\resources\views/web/layouts/inc/footer.blade.php ENDPATH**/ ?>