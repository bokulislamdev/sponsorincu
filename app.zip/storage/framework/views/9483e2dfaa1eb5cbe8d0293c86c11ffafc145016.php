<?php $__env->startSection('content'); ?>

<main class="page-content">

<div class="row row-cols-1 row-cols-sm-2 row-cols-md-3 row-cols-xl-4 row-cols-xxl-4">
    <div class="col">
      <div class="card radius-10 bg-primary">
        <div class="card-body">
          <div class="d-flex align-items-center">
            <div class="">
              <p class="mb-1 text-white">Total Users</p>
              <h4 class="mb-0 text-white"><?php echo e($user_count); ?></h4>
            </div>
            <div class="ms-auto widget-icon bg-white-1 text-white">
              <a href="#" class="text-white"><i class="bi bi-bag-check-fill"></i></a>
            </div>
          </div>
        </div>
      </div>
     </div>
     <div class="col">
      <div class="card radius-10 bg-danger">
        <div class="card-body">
          <div class="d-flex align-items-center">
            <div class="">
              <p class="mb-1 text-white">Total Partner</p>
              <h4 class="mb-0 text-white"><?php echo e($partner); ?></h4>
            </div>
            <div class="ms-auto widget-icon bg-white-1 text-white">
              <a href="<?php echo e(route('admin.partner.index')); ?>" class="text-white"><i class="bi bi-bag-check-fill"></i></a>
            </div>
          </div>
        </div>
      </div>
     </div>
     <div class="col">
      <div class="card radius-10 bg-warning">
        <div class="card-body">
          <div class="d-flex align-items-center">
            <div class="">
              <p class="mb-1 text-white">Total Service</p>
              <h4 class="mb-0 text-white"><?php echo e($service); ?></h4>
            </div>
            <div class="ms-auto widget-icon bg-white-1 text-white">
              <a href="<?php echo e(route('admin.service.index')); ?>" class="text-white"><i class="bi bi-bag-check-fill"></i></a>
            </div>
          </div>
        </div>
      </div>
     </div>
     









     </div>
     </div>
</main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('account.layouts.app',['title' => 'Admin Dashboard'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\local_server\htdocs\blaghat\resources\views/account/admin/dashboard.blade.php ENDPATH**/ ?>