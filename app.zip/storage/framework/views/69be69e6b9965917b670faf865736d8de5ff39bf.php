<?php
$locale = app()->getLocale();
?>




<?php $__env->startSection('content'); ?>
    <!--    PAGE HEAD-->
    <section class="page-head-section text-center py-5">
        <div class="container mt-5 pt-5">
            <h2><?php echo app('translator')->get('home.Our_Services'); ?></h2>
            <p>
                <a href="<?php echo e(route('homepage')); ?>">Home</a>
                <span>/</span>
                <span><?php echo app('translator')->get('home.Our_Services'); ?></span>
            </p>
        </div>
    </section>
    <!--    PAGE HEAD END-->



    <!--    REPORT SECTION-->
    <div class="service-section-page  py-5">
        <div class="container">
            <div class="services-head py-4 border-bottom">
                <h5><?php echo app('translator')->get('home.Partnership_with_the_government_sector'); ?> </h5>
            </div>
            <div class="row mt-5">
                <?php $__currentLoopData = $govment; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-12 col-sm-6 col-md-4 col-lg-3 pb-4">
                    <a href="<?php echo e($item->web_link); ?>" target="_blank" class="report-box h-100 w-100">
                        <img src="<?php echo e(asset($item->image)); ?>" alt="">
                        <h6>
                           
                            <?php if($locale == 'en'): ?>
                                <?php echo e($item->name); ?>

                            <?php elseif( $locale == "ar"): ?>
                                <?php echo e($item->name_ar); ?>

                            <?php endif; ?>
                           
                        </h6>
                    </a>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
            </div>
        </div>
    </div>
    <!--    REPORT SECTION END-->
    
    <!--    REPORT SECTION-->
    <div class="service-section-page  py-5">
        <div class="container">
            <div class="services-head py-4 border-bottom">
                <h5><?php echo app('translator')->get('home.Partnership_with_the_private_sector'); ?> </h5>
            </div>
            <div class="row mt-5">
                <?php $__currentLoopData = $private; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-12 col-sm-6 col-md-4 col-lg-3 pb-4">
                    <a href="<?php echo e($item->web_link); ?>" target="_blank" class="report-box h-100 w-100">
                        <img src="<?php echo e(asset($item->image)); ?>" alt="">
                        <h6>
                           
                            <?php if($locale == 'en'): ?>
                                <?php echo e($item->name); ?>

                            <?php elseif( $locale == "ar"): ?>
                                <?php echo e($item->name_ar); ?>

                            <?php endif; ?>
                           
                        </h6>
                    </a>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
    <!--    REPORT SECTION END-->
    
    <!--    REPORT SECTION-->
    <div class="service-section-page  py-5">
        <div class="container">
            <div class="services-head py-4">
                <h5><?php echo app('translator')->get('home.Community_partnership'); ?>  </h5>
            </div>
            <div class="row mt-5">
                <?php $__currentLoopData = $community; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-12 col-sm-6 col-md-4 col-lg-3 pb-4">
                    <a href="<?php echo e($item->web_link); ?>" target="_blank" class="report-box h-100 w-100">
                        <img src="<?php echo e(asset($item->image)); ?>" alt="">
                        <h6>
                           
                            <?php if($locale == 'en'): ?>
                                <?php echo e($item->name); ?>

                            <?php elseif( $locale == "ar"): ?>
                                <?php echo e($item->name_ar); ?>

                            <?php endif; ?>
                           
                        </h6>
                    </a>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
    <!--    REPORT SECTION END-->


    <?php echo $__env->make('web.component.brand', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>; 
    <?php echo $__env->make('web.component.subscribe', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>; 
<?php $__env->stopSection(); ?>

<?php echo $__env->make('web.layouts.app', ['title' => 'Services'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\local_server\htdocs\blaghat\resources\views/web/services.blade.php ENDPATH**/ ?>