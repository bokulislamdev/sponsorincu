<?php
$locale = app()->getLocale();
?>



<?php $__env->startSection('content'); ?>

    <!--    PAGE HEAD SECTION-->
    <section class="page-head-section py-5">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <h2><?php echo app('translator')->get('home.Discover_Events'); ?></h2>
                    <p>
                        <a href="<?php echo e(route('homepage')); ?>">Home</a>
                        <span>/</span>
                        <a href="<?php echo e(route('event.category')); ?>"><?php echo app('translator')->get('home.Event_Type'); ?></a>
                        <span>/</span>
                        <span><?php echo e($event_types->name); ?></span>
                    </p>
                </div>
            </div>
        </div>
    </section>
    <!--    PAGE HEAD SECTION END-->
    
    <section class="benefit-section py-2">
        <div class="container">
            <div class="row m-auto">
                <?php $__currentLoopData = $event_topics; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event_topic): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-12 col-sm-6 col-md-4 col-lg-3 pb-4">
                    <div class="benefit-box" style="background-image: linear-gradient(#6429e3c4,#6429e3c4),url(http://127.0.0.1:8000/web/images/small-service/Attracting-donations-for-the-benefit-of-the-parties.png);background-position: center;
            background-repeat: no-repeat;
            background-size: cover;">
                        <div class="benefit-content">
                            <h6>
                                <?php if($locale == 'en'): ?>
                                <?php echo e($event_topic->name); ?>

                                <?php elseif( $locale == "ar"): ?>
                                <?php echo e($event_topic->name_ar); ?>

                                <?php endif; ?>
                            </h6>
                            <a href="<?php echo e(route('single.topic',$event_topic->slug)); ?>" class="stretched-link"></a>
                        </div>
                    </div>
                </div> 
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

        </div>
    </section>



<?php $__env->stopSection(); ?>


<?php echo $__env->make('web.layouts.app', ['title' => 'Events'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\local_server\htdocs\sponser\resources\views/web/single-type.blade.php ENDPATH**/ ?>