



<?php $__env->startSection('content'); ?>
    <!--start content-->
    <main class="page-content">
    <!--breadcrumb-->
    <div class="page-breadcrumb d-none d-sm-flex align-items-center py-2 px-3" style="background: rgb(46 57 78);">
        <div class="pe-3"><h5 class="text-white m-0">Product List</h5></div>
        <div class="ms-auto">
            <a href="<?php echo e(route('admin.product.create')); ?>" class="btn btn-primary custom-head-link"> <i class="lni lni-circle-plus custom-head-link"></i> Create Product</a>
        </div>
    </div>
    <!--end breadcrumb-->

    <div class="card">
        <div class="card-body">
            <div class="table-responsive mt-3">
            <table class="table align-middle">
                <thead class="table-secondary">
                <tr>
                    <th>#</th>
                    <th>Name</th>


                    <th>Category</th>
                    <th>Price</th>
                    <th>Discount</th>
                    <th>Active Price</th>
                    <th>Status</th>
                    <th>Action</th>
                </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($loop->iteration); ?></td>
                    <td><?php echo e($item->name); ?></td>
                    <td><?php echo e($item->productcategory ? $item->productcategory->name:''); ?></td>
                    <td><?php echo e($item->price); ?></td>
                    <td><?php echo e($item->discount_price); ?></td>
                    <td>

                        <?php if($item->active_price == 1): ?>
                            <span class="btn btn-primary status-btn">Regular Price</span>
                        <?php elseif($item->active_price == 2): ?>
                        <span class="btn btn-warning status-btn">Discount Price</span>
                        <?php endif; ?>
                    </td>

                    <td>
                        <?php if($item->status == 1): ?>
                            <span class="btn btn-success status-btn">Active</span>
                        <?php elseif($item->status == 2): ?>
                        <span class="btn btn-danger status-btn">Pending</span>
                        <?php elseif($item->status == 0): ?>
                        <span class="btn btn-danger status-btn">Cancel</span>
                        <?php endif; ?>
                    </td>

                    <td>
                        <div class="dropdown">
                            <button class="btn" type="button" id="dropdownMenu2" data-bs-toggle="dropdown" aria-expanded="false">
                                <i class="fadeIn animated bx bx-dots-vertical-rounded"></i>
                            </button>
                            <ul class="dropdown-menu" aria-labelledby="dropdownMenu2">
                                <div class="custom-toggle">
                                    <a href="<?php echo e(route('admin.product.show',$item->id)); ?>" class="text-primary" data-bs-toggle="tooltip" data-bs-placement="bottom" title="" data-bs-original-title="Views" aria-label="Views"><i class="bi bi-eye-fill"></i></a>
                                    <a href="<?php echo e(route('admin.product.edit',$item->id)); ?>" class="text-warning" data-bs-toggle="tooltip" data-bs-placement="bottom" title="" data-bs-original-title="Edit" aria-label="Edit"><i class="bi bi-pencil-fill"></i></a>
                                    <form id="delete-form" action="<?php echo e(route('admin.product.destroy',$item->id)); ?>" method="POST">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('delete'); ?>
                                        <button type="button" class="delete-admin" onClick="deleteItem()">
                                            <span  class="text-danger" data-bs-toggle="tooltip" data-bs-placement="bottom" title="" data-bs-original-title="Delete" aria-label="Delete"><i class="bi bi-trash-fill"></i></span>
                                        </button>
                                    </form>
                                </div>
                            </ul>
                          </div>
                        
                    
                    </td>
                </tr>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </tbody>
            </table>
            </div>
        </div>
        </div>


    </main>
<!--end page main-->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('account.layouts.app',['title' => 'Product  List'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\halalincu\resources\views/account/admin/product/index.blade.php ENDPATH**/ ?>