


<?php $__env->startSection('content'); ?>



        <!-- ==========================================================================
OUR METHODOLOGY-SLIDER SECTION START
==========================================================================  -->

<main class="full-body">

    <section class="methodology-slider-section section">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12">
                    <div class="methodology-heading">
                        <h1><?php echo app('translator')->get('home.Our_methodology'); ?></h1>
                        <hr>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- ==========================================================================
OUR METHODOLOGY-SLIDER SECTION END
==========================================================================  -->



    <!-- ==========================================================================
    We build relationships with partners SECTION START
==========================================================================  -->
    <section class="methodology-build-relation">
        .<div class="container">
            <div class="row">
                <div class="col-lg-6 col-md-6 col-sm-12">
                    <div class="methodology-build-content">
                        <h1><?php echo app('translator')->get('home.We_build_relationships_with_partners'); ?>
                        </h1>
                        <p>
                            <?php echo app('translator')->get('home.We_build_relationships_with_partners_p'); ?>
                        </p>
                    </div>
                </div>

                <div class="col-lg-6 col-md-6 col-sm-12">
                    <div class="methodology-build-image">
                        <img src="<?php echo e(asset('web')); ?>/Methodology/We-build-relationships-with-partners.png" alt="">
                    </div>
                </div>
            </div>
        </div>

    </section>


    <!-- ==========================================================================
            SOLUTION-CENTER SECTION END
==========================================================================  -->



    <!-- ==========================================================================
    INVEST KNOWLEDGED SECTION START
==========================================================================  -->
    <section class="invest-knowledged-relation">
        .<div class="container">
            <div class="row">

                <div class="col-lg-6 col-md-6 col-sm-12">
                    <div class="methodology-build-image">
                        <img src="<?php echo e(asset('web')); ?>/Methodology/We-build-relationships-with-partners.png" alt="">
                    </div>
                </div>

                <div class="col-lg-6 col-md-6 col-sm-12">
                    <div class="invest-content">
                        <h1> <?php echo app('translator')->get('home.We_invest_in_knowledge'); ?></h1>
                        <p>
                             <?php echo app('translator')->get('home.We_invest_in_knowledge_p'); ?>
                        </p>
                    </div>

                    <div class="more-inf0-inner">
                        <button class="btn"> <?php echo app('translator')->get('home.For_More_Information'); ?></button>
                    </div>
                </div>

            </div>
        </div>

    </section>


    <!-- ==========================================================================
            INVEST FOR KNOWLEDGE SECTION END
==========================================================================  -->



    <!-- ==========================================================================
                METHODOLOGY INVEST FOR TRAINING SECTION START
    ==========================================================================  -->
    <section class="methodology-build-relation">
        .<div class="container">
            <div class="row">
                <div class="col-lg-6 col-md-6 col-sm-12">
                    <div class="methodology-build-content">
                        <h1> <?php echo app('translator')->get('home.We_invest_in_training'); ?></h1>
                        <p> <?php echo app('translator')->get('home.We_invest_in_training_p'); ?>
                        </p>
                    </div>

                    <div class="more-inf0-inner">
                        <button class="btn"> <?php echo app('translator')->get('home.For_More_Information'); ?></button>
                    </div>
                </div>

                <div class="col-lg-6 col-md-6 col-sm-12">
                    <div class="methodology-build-image">
                        <img src="<?php echo e(asset('web')); ?>/Methodology/We-invest-in-training.png" alt="">
                    </div>
                </div>
            </div>
        </div>

    </section>


    <!-- ==========================================================================
        METHODOLOGY INVEST FOR TRAINING SECTION END
==========================================================================  -->



    <!-- ==========================================================================
INVEST FOR INTERNATIONAL RELATION SECTION START
==========================================================================  -->
    <section class="invest-knowledged-relation">
        .<div class="container">
            <div class="row">

                <div class="col-lg-6 col-md-6 col-sm-12">
                    <div class="methodology-build-image">
                        <img src="<?php echo e(asset('web')); ?>/Methodology/We-invest-in-international-relations.png" alt="">
                    </div>
                </div>

                <div class="col-lg-6 col-md-6 col-sm-12">
                    <div class="invest-content">
                        <h1> <?php echo app('translator')->get('home.We_invest_in_international'); ?></h1>
                        <p> <?php echo app('translator')->get('home.We_invest_in_international_p'); ?>
                        </p>
                    </div>

                    <div class="more-inf0-inner">
                        <button class="btn"> <?php echo app('translator')->get('home.For_More_Information'); ?></button>
                    </div>
                </div>

            </div>
        </div>

    </section>


    <!-- ==========================================================================
INVEST FOR INTERNATIONAL RELATION SECTION END
==========================================================================  -->



<?php echo $__env->make('web.component.subscribe', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>; 

<?php $__env->stopSection(); ?>


<?php echo $__env->make('web.layouts.app', ['title' => 'Methodology'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\local_server\htdocs\disclea\resources\views/web/methodology.blade.php ENDPATH**/ ?>