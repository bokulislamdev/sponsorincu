



<?php $__env->startSection('content'); ?>
               <!--start content-->
               <main class="page-content">
                <!--breadcrumb-->
                <div class="page-breadcrumb d-none d-sm-flex align-items-center py-2 px-3" style="background: rgb(46 57 78);">
                  <div class="pe-3"><h5 class="text-white m-0">Admin Users</h5></div>
                  <div class="ms-auto">
                    
                  </div>
                </div>
                <!--end breadcrumb-->
    
                <div class="card">
                    <div class="card-body">
                        <form action="<?php echo e(route('admin.user.update',$user->id)); ?>" method="post" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('put'); ?>
                            <div class="row">
                                <div class="col-12 col-md-6 py-2">
                                    <label for="" class="form-label">Username <span class="text-danger">*</span></label>
                                    <input type="text" class="form-control" name="username" value="<?php echo e($user->username); ?>">
                                    <span class="text-danger"><?php echo e($errors->first('username')); ?></span>
                                </div>
                                <div class="col-12 col-md-6 py-2">
                                    <label for="" class="form-label">Name <span class="text-danger">*</span></label>
                                    <input type="text" class="form-control" name="name" value="<?php echo e($user->name); ?>">
                                    <span class="text-danger"><?php echo e($errors->first('name')); ?></span>
                                </div>
                                <div class="col-12 col-md-6 py-2">
                                    <label for="" class="form-label">Email <span class="text-danger">*</span></label>
                                    <input type="text" class="form-control" name="email" value="<?php echo e($user->email); ?>">
                                    <span class="text-danger"><?php echo e($errors->first('email')); ?></span>
                                </div>
                                <div class="col-12 col-md-6 py-2">
                                    <label for="" class="form-label">Phone</label>
                                    <input type="text" class="form-control" name="phone" value="<?php echo e($user->phone); ?>">
                                </div>
                                <div class="col-12 col-md-6 py-2">
                                    <label for="" class="form-label">Country</label>
                                    <input type="text" class="form-control" name="country" value="<?php echo e($user->country); ?>">
                                </div>
                                <div class="col-12 col-md-6 py-2">
                                    <label for="" class="form-label">Country</label>
                                    <input type="text" class="form-control" name="country" value="<?php echo e($user->country); ?>">
                                </div>
                                <div class="col-12 col-md-6 py-2">
                                    <label for="" class="form-label">City</label>
                                    <input type="text" class="form-control" name="city" value="<?php echo e($user->city); ?>">
                                </div>
                                <div class="col-12 col-md-6 py-2">
                                    <label for="" class="form-label">Address</label>
                                    <input type="text" class="form-control" name="address" value="<?php echo e($user->address); ?>">
                                </div>
                                
                                <div class="col-12 col-md-6 py-2">
                                    <label for="" class="form-label">User permission</label>
                                    <select name="role" id="" class="form-control">
                                        <option value="1" <?php echo e($user->role == 1 ? 'selected' : ""); ?>>Admin</option>
                                        <option value="2" <?php echo e($user->role == 2 ? 'selected' : ""); ?>>Vendor</option>
                                        <option value="3" <?php echo e($user->role == 2 ? 'selected' : ""); ?>>Genarel User</option>
                                    </select>
                                </div>
                                <div class="col-12 col-md-6 py-2">
                                    <label for="" class="form-label">Status</label>
                                    <select name="status" id="" class="form-control">
                                        <option value="1" <?php echo e($user->status == 1 ? 'selected' : ""); ?>>Active</option>
                                        <option value="2" <?php echo e($user->status == 2 ? 'selected' : ""); ?>>Dactive</option>
                                    </select>
                                </div>
                                <div class="col-12 col-md-6 py-2">
                                    <label for="" class="form-label">Profile Image <img src="<?php echo e(asset($user->image)); ?>" alt="Profile Photo" style="height: 100px;"></label>
                                    <input type="file" class="form-control" name="image">
                                </div>
                                <div class="col-12 text-center mt-5">
                                    <a href="<?php echo e(route('admin.user.index')); ?>" class="btn btn-warning" style="margin-right: 20px;">Cancel</a>
                                    <button type="submit" class="btn btn-primary">Update</button>

                                </div>
                            </div>
                        </form>
                    </div>
                  </div>
                        
    
              </main>
           <!--end page main-->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('account.layouts.app',['title' => 'Edit Users'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\local_server\htdocs\sponser\resources\views/account/admin/user/edit.blade.php ENDPATH**/ ?>