


<?php $__env->startSection('content'); ?>

          <!--    PAGE HEAD SECTION-->
    <section class="page-head-section py-5">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <h2><?php echo app('translator')->get('home.About_Us'); ?></h2>
                   
                </div>
            </div>
        </div>
    </section>
    <!--    PAGE HEAD SECTION END-->

    <!--    ABOUT SECTION-->
    <section class="about-section py-5">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-12 col-md-6">
                    <div class="about-image">
                        <img src="<?php echo e(asset('web')); ?>/images/photos/about.png" alt="Image">
                    </div>
                </div>
                <div class="col-12 col-md-6 mt-4 mt-md-0">
                    <div class="about-text">
                        <h4><?php echo app('translator')->get('home.who_are_we'); ?></h4>
                        <p>
                            <?php echo app('translator')->get('home.about_p1'); ?>
                        </p>
                        <ul>
                            <li>
                                <span></span>
                                <?php echo app('translator')->get('home.about_p2'); ?>
                            </li>
                            <li>
                                <span></span>
                                <?php echo app('translator')->get('home.about_p3'); ?>
                            </li>
                            <li>
                                <span></span>
                                <?php echo app('translator')->get('home.about_p4'); ?>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--    ABOUT SECTION END-->

    <!--    VISSION MISSION SECTION-->
    
    <!--    VISSION MISSION SECTION END-->
    


<?php $__env->stopSection(); ?>


<?php echo $__env->make('web.layouts.app', ['title' => 'About'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\local_server\htdocs\sponser\resources\views/web/about.blade.php ENDPATH**/ ?>