



<?php $__env->startSection('content'); ?>
    <!--start content-->
    <main class="page-content">
    <!--breadcrumb-->
    <div class="page-breadcrumb d-none d-sm-flex align-items-center py-2 px-3" style="background: rgb(46 57 78);">
        <div class="pe-3"><h5 class="text-white m-0">Sliders</h5></div>
        <div class="ms-auto">
            <a href="<?php echo e(route('admin.slider.create')); ?>" class="btn btn-primary"> <i class="lni lni-circle-plus custom-head-link"></i> Create Slider</a>
        </div>
    </div>
    <!--end breadcrumb-->

    <div class="card">
        <div class="card-body">
            <div class="table-responsive mt-3">
            <table class="table align-middle">
                <thead class="table-secondary">
                <tr>
                    <th>#</th>
                    <th>Title</th>
                    <th>Image</th>
                    <th>Status</th>
                    <th>Actions</th>
                </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($loop->iteration); ?></td>
                    <td><?php echo e($item->title); ?></td>
                    <td>
                        <img src="<?php echo e(asset($item->image)); ?>" alt="Slider Photo" style="width: 150px;">
                    </td>
                    <td>
                        <?php if($item->status == 1): ?>
                            <span class="btn btn-success status-btn">Active</span>
                        <?php elseif($item->status == 2): ?>
                            Dactive
                        <?php endif; ?>
                    </td>
                    <td>
                    <div class="table-actions d-flex align-items-center gap-3 fs-6">
                       
                        <a href="<?php echo e(route('admin.slider.edit',$item->id)); ?>" class="text-warning" data-bs-toggle="tooltip" data-bs-placement="bottom" title="" data-bs-original-title="Edit" aria-label="Edit"><i class="bi bi-pencil-fill"></i></a>
                        <form action="<?php echo e(route('admin.slider.destroy',$item->id)); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('delete'); ?>
                        <button type="submit" class="delete-admin">
                            <span  class="text-danger" data-bs-toggle="tooltip" data-bs-placement="bottom" title="" data-bs-original-title="Delete" aria-label="Delete"><i class="bi bi-trash-fill"></i></span>
                        </button>
                        </form>
                            
                    </div>
                    </td>
                </tr>
                
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </tbody>
            </table>
            </div>
        </div>
        </div>

    </main>
<!--end page main-->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('account.layouts.app',['title' => 'Slider All'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\halalincu\resources\views/account/admin/slider/index.blade.php ENDPATH**/ ?>