<?php $__currentLoopData = $wishlists; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $wishlist): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td>
            <div class="shipping-product d-flex bd-highlight">
                <div class="shipping-image p-2 flex-shrink-1 bd-highlight">
                    <img src="<?php echo e(asset($wishlist->product ? $wishlist->product->image : '')); ?>" alt="">
                    <a href="javascript:void(0)" class="wish_remove_click" data-id="<?php echo e($wishlist->id); ?>">
                        <i class="fas fa-times-circle"></i>
                    </a>
                </div>
                <div class="p-2 w-100 bd-highlight">
                    <div class="shipping-product-details">
                        <a href="<?php echo e(route('product.details', $wishlist->product->slug)); ?>">
                            <h4><?php echo e($wishlist->product ? $wishlist->product->name : ''); ?>

                            </h4>
                        </a>
                        <h6>Color:<?php echo e($wishlist->product->productcolor ? $wishlist->product->productcolor->name : ''); ?>

                        </h6>

                    </div>
                </div>
            </div>
        </td>
        <td> SAR <?php echo e($wishlist->product ? $wishlist->product->price : ''); ?></td>
    </tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH D:\local_server\htdocs\halalincu2\halalincu\resources\views/web/component/wish-table.blade.php ENDPATH**/ ?>