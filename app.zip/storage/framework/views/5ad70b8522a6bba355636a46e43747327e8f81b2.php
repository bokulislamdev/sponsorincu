


<?php $__env->startSection('content'); ?>
<main class="full-body">

    <section class="services-slider-section section">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12">
                    <div class="services-heading">
                        <h1><?php echo app('translator')->get('home.Our_Services'); ?></h1>
                        <hr>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- ==========================================================================
SERVICES-SLIDER SECTION END
==========================================================================  -->


    <!-- ==========================================================================
SERVICES-LEADER-SECTOR SECTION START
==========================================================================  -->

    <section class="services-leader-section">
        <div class="container">
            <div class="row">
                <div class="col-lg-3 col-md-6 col-sm-12">
                    <div class="card services-img">
                        <img src="<?php echo e(asset('web')); ?>/Services/discover-the-leader.png" class="card-img-top"
                            alt="discover-the-leader.png">
                        <div class="card-body mt-3 services-des">
                            <h4><?php echo app('translator')->get('home.Discover_the_leaders'); ?></h4>
                            <p class="card-text">
                                <?php echo app('translator')->get('home.Discover_the_leaders_p'); ?>
                            </p>
                        </div>
                    </div>
                </div>


                <div class="col-lg-3 col-md-6 col-sm-12">
                    <div class="card services-img">
                        <img src="<?php echo e(asset('web')); ?>/Services/Industry-leaders.png" class="card-img-top"
                            alt="Industry-leaders.png">
                        <div class="card-body mt-3 services-des">
                            <h4><?php echo app('translator')->get('home.Industry_leaders'); ?></h4>
                            <p class="card-text">
                                <?php echo app('translator')->get('home.Industry_leaders_p'); ?>
                            </p>
                        </div>
                    </div>
                </div>

                <div class="col-lg-3 col-md-6 col-sm-12">
                    <div class="card services-img">
                        <img src="<?php echo e(asset('web')); ?>/Services/Leadership-and-Marketing-Management.png" class="card-img-top"
                            alt="...">
                        <div class="card-body mt-3 services-des">
                            <h4><?php echo app('translator')->get('home.Leadership_and_Marketing_Management'); ?></h4>
                            <p class="card-text">
                                <?php echo app('translator')->get('home.Leadership_and_Marketing_Management_p'); ?>
                            </p>
                        </div>
                    </div>
                </div>

                <div class="col-lg-3 col-md-6 col-sm-12">
                    <div class="card services-img">
                        <img src="<?php echo e(asset('web')); ?>/Services/Choice-of-leaders.png" class="card-img-top"
                            alt="Choice-of-leaders.png">
                        <div class="card-body mt-3 services-des">
                            <h4><?php echo app('translator')->get('home.Choice_of_leaders'); ?></h4>
                            <p class="card-text">
                                <?php echo app('translator')->get('home.Choice_of_leaders_p'); ?>
                            </p>
                        </div>
                    </div>
                </div>

                <div class="col-lg-3 col-md-6 col-sm-12">
                    <div class="card services-img">
                        <img src="<?php echo e(asset('web')); ?>/Services/Incubating-leadership-projects.png" class="card-img-top"
                            alt="Incubating-leadership-projects.png">
                        <div class="card-body mt-3 services-des">
                            <h4><?php echo app('translator')->get('home.Incubating_leadership_projects'); ?></h4>
                            <p class="card-text">
                                <?php echo app('translator')->get('home.Incubating_leadership_projects_p'); ?>
                            </p>
                        </div>
                    </div>
                </div>

                <div class="col-lg-3 col-md-6 col-sm-12">
                    <div class="card services-img">
                        <img src="<?php echo e(asset('web')); ?>/Services/Leadership-care.png" class="card-img-top" alt="Leadership-care.pn">
                        <div class="card-body mt-3 services-des">
                            <h4><?php echo app('translator')->get('home.Leadership_care'); ?></h4>
                            <p class="card-text">
                                <?php echo app('translator')->get('home.Leadership_care_p'); ?>
                            </p>
                        </div>
                    </div>
                </div>

                <div class="col-lg-3 col-md-6 col-sm-12">
                    <div class="card services-img">
                        <img src="<?php echo e(asset('web')); ?>/Services/Promotion-and-marketing-of-leadership-related-products.png"
                            class="card-img-top" alt="Promotion-and-marketing">
                        <div class="card-body mt-3 services-des">
                            <h4><?php echo app('translator')->get('home.Promotion_and_marketing'); ?></h4>
                            <p class="card-text">
                                <?php echo app('translator')->get('home.Promotion_and_marketing_p'); ?>
                            </p>
                        </div>
                    </div>
                </div>

                <div class="col-lg-3 col-md-6 col-sm-12">
                    <div class="card services-img">
                        <img src="<?php echo e(asset('web')); ?>/Services/Administrative-succession.png" class="card-img-top"
                            alt="Administrative-succession.png">
                        <div class="card-body mt-3 services-des">
                            <h4><?php echo app('translator')->get('home.Administrative_succession'); ?></h4>
                            <p class="card-text">
                                <?php echo app('translator')->get('home.Administrative_succession_p'); ?>
                            </p>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </section>

    <!-- ==========================================================================
SERVICES-LEADER-SECTOR SECTION END
==========================================================================  -->





<?php echo $__env->make('web.component.subscribe', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>; 




</main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('web.layouts.app', ['title' => 'Services'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\local_server\htdocs\disclea\resources\views/web/services.blade.php ENDPATH**/ ?>