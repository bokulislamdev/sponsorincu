

<?php $__env->startSection('content'); ?>

<main class="page-content">

    <div class="row row-cols-1 row-cols-sm-2 row-cols-md-3 row-cols-xl-4 row-cols-xxl-4">
        

    </main>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('account.layouts.app',['title' => 'User Dashboard'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\local_server\htdocs\disclea\resources\views/account/user/dashboard.blade.php ENDPATH**/ ?>