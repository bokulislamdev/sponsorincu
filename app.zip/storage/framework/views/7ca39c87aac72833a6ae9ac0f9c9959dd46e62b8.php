<?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<tr>
    <td>
        <div class="shipping-product d-flex bd-highlight">
            <div class="shipping-image p-2 flex-shrink-1 bd-highlight">
              <img src="<?php echo e(asset($product->options['image'])); ?>" alt="image">
              
                <a href="javascript:void(0)" data-id="<?php echo e($product->rowId); ?>" class="removecart">
                
                    <i class="fas fa-times-circle"></i>
                </a>
            </div>
            <div class="p-2 w-100 bd-highlight">
                <div class="shipping-product-details">
                    <h4><?php echo e($product->name); ?></h4>
                    
                    
                </div>
            </div>
        </div>
    </td>
    <td>SAR<?php echo e($product->price); ?></td>
    <td>
        <div class="shipping-count">
            <button class="incrementCart" data-id="<?php echo e($product->rowId); ?>">+</button>
            <span><?php echo e($product->qty); ?></span>
            <button class="decrementCart" data-id="<?php echo e($product->rowId); ?>">-</button>
        </div>
    </td>
    <td>SAR <?php echo e($product->priceTotal); ?></td>
</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php /**PATH D:\local_server\htdocs\blaghat\resources\views/web/component/carttable.blade.php ENDPATH**/ ?>