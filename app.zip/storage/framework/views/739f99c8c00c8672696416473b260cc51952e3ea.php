



<?php $__env->startSection('content'); ?>
<!--start content-->
<main class="page-content">
<!--breadcrumb-->
<div class="page-breadcrumb d-none d-sm-flex align-items-center py-2 px-3" style="background: rgb(46 57 78);">
    <div class="pe-3"><h5 class="text-white m-0">Evnet Topic</h5></div>
    <div class="ms-auto">
    <a href="<?php echo e(route('admin.event-topic.index')); ?>" class="btn btn-primary custom-head-link"> <i class="fadeIn animated bx bx-undo"></i> Back To Evnet Topic</a>
    </div>
</div>
<!--end breadcrumb-->

<div class="card">
    <div class="card-body">
        <form action="<?php echo e(route('admin.event-topic.store')); ?>" method="post" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="row">
                <div class="col-12 col-md-6 py-2">
                    <label for="" class="form-label">Name <span class="text-danger">*</span></label>
                    <input type="text" class="form-control" name="name" value="<?php echo e(old('name')); ?>">
                    <span class="text-danger"><?php echo e($errors->first('name')); ?></span>
                </div>
                <div class="col-12 col-md-6 py-2">
                    <label for="" class="form-label">Name Arabic</label>
                    <input type="text" class="form-control" name="name_ar" value="<?php echo e(old('name_ar')); ?>">
                </div>

                <div class="col-12 text-center mt-5">
                    <a href="<?php echo e(route('admin.event-topic.index')); ?>" class="btn btn-warning" style="margin-right: 20px;">Cancel</a>
                    <button type="submit" class="btn btn-primary">Create</button>

                </div>
            </div>
        </form>
    </div>
    </div>
        

</main>
<!--end page main-->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('account.layouts.app',['title' => 'Create Evnet Topic'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\local_server\htdocs\sponser\resources\views/account/admin/event_topic/create.blade.php ENDPATH**/ ?>