    <!--    FOOTER-->
    <footer class="pt-5 pb-0 pb-md-5">
        <div class="container">
            <div class="row py-4">
                <div class="mobile-apps">
                    <span>Free App: </span>
                    <a href="#">
                        <img src="<?php echo e(asset('web')); ?>/images/icons/app.png" alt="">
                    </a>
                    <a href="#">
                        <img src="<?php echo e(asset('web')); ?>/images/icons/google.png" alt="">
                    </a>
                </div>
            </div>
        </div>
        <div class="container top-border">
            <div class="single-footer">
                <a href="<?php echo e(route('about')); ?>">About us</a>
                <a href="<?php echo e(route('faq')); ?>">FAQ</a>
                <a href="<?php echo e(route('contact')); ?>">Contact Us</a>
                <a href="javascript:void(0)">Site Map</a>
            </div>

            <div class="single-footer2">
                <a href="javascript:void(0)">Poultry Digital</a>
                <a href="javascript:void(0)">Newsletter</a>
                <a href="<?php echo e(route('contact')); ?>">Advertise with us</a>
            </div>
            <div class="single-footer">
                <a href="javascript:void(0)">Privacy Policy</a>
                <a href="javascript:void(0)">Terms & Conditions</a>
            </div>
        </div>
    </footer>
    <!--    FOOTER END-->

    <!--    COPYRIGHT-->
    <section class="copyright-section">
        <div class="container">
            <div class="copyright-content">
                <div class="col-12">
                    <p>Copyright © 2022 Dajajah Incubator. All Rights Reserved.</p>
                </div>
            </div>
        </div>
    </section>
    <!--    COPYRIGHT END--><?php /**PATH D:\local_server\htdocs\dajajah\resources\views/web/layouts/inc/footer.blade.php ENDPATH**/ ?>