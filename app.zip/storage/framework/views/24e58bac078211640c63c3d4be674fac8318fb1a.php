


<?php $__env->startSection('content'); ?>

<main class="full-body">

    <section class="training-slider-section section">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12">
                    <div class="training-heading">
                        <h1><?php echo app('translator')->get('home.Training'); ?></h1></h1>
                        <hr>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- ==========================================================================
TRAINING-SLIDER SECTION END
==========================================================================  -->


    <!-- ==========================================================================
TRAINING INCUBATOR PLATFORM SECTION START
==========================================================================  -->
    <section class="training-incubator-platform">
        <div class="container">
            <div class="training-incubator-heading">
                <h1><?php echo app('translator')->get('home.Training_Incubator'); ?></h1>
                <p><?php echo app('translator')->get('home.Training_Incubator_platform'); ?>
                </p>
            </div>

            <div class="row">
                <div class="col-lg-3 col-md-6 col-sm-12 pb-4">
                    <div class="card card-lead  h-100">
                        <div class="card-body proud-content">
                            <p class="card-text"><?php echo app('translator')->get('home.Training_Incubator_platform_li1_1'); ?>
                            </p>
                        </div>
                    </div>
                </div>

                <div class="col-lg-3 col-md-6 col-sm-12 pb-4">
                    <div class="card card-lead  h-100">
                        <div class="card-body proud-content">
                            <p class="card-text"><?php echo app('translator')->get('home.Training_Incubator_platform_li1_2'); ?>
                            </p>
                        </div>
                    </div>
                </div>

                <div class="col-lg-3 col-md-6 col-sm-12 pb-4">
                    <div class="card card-lead  h-100">
                        <div class="card-body proud-content">
                            <p class="card-text"><?php echo app('translator')->get('home.Training_Incubator_platform_li2'); ?>
                            </p>
                        </div>
                    </div>
                </div>

                <div class="col-lg-3 col-md-6 col-sm-12 pb-4">
                    <div class="card card-lead  h-100">
                        <div class="card-body proud-content">
                            <p class="card-text"><?php echo app('translator')->get('home.Training_Incubator_platform_li7'); ?>
                            </p>
                        </div>
                    </div>
                </div>

                <div class="col-lg-3 col-md-6 col-sm-12 pb-4">
                    <div class="card card-lead  h-100">
                        <div class="card-body proud-content">
                            <p class="card-text"><?php echo app('translator')->get('home.Training_Incubator_platform_li3'); ?>
                            </p>
                        </div>
                    </div>
                </div>

                <div class="col-lg-3 col-md-6 col-sm-12 pb-4">
                    <div class="card card-lead  h-100">
                        <div class="card-body proud-content">
                            <p class="card-text"><?php echo app('translator')->get('home.Training_Incubator_platform_li4'); ?>
                            </p>
                        </div>
                    </div>
                </div>

                <div class="col-lg-3 col-md-6 col-sm-12 pb-4">
                    <div class="card card-lead  h-100">
                        <div class="card-body proud-content">
                            <p class="card-text"><?php echo app('translator')->get('home.Training_Incubator_platform_li5'); ?>
                            </p>
                        </div>
                    </div>
                </div>

                <div class="col-lg-3 col-md-6 col-sm-12 pb-4">
                    <div class="card card-lead  h-100">
                        <div class="card-body proud-content">
                            <p class="card-text"><?php echo app('translator')->get('home.Training_Incubator_platform_li6'); ?>
                            </p>
                        </div>
                    </div>
                </div>

                
            </div>

        </div>

    </section>

    <!-- ==========================================================================
TRAINING INCUBATOR PLATFORM SECTION  END
==========================================================================  -->


    <!-- ==========================================================================
TRAINING INCUBATOR TRUSTED LINK PLATFORM SECTION START
==========================================================================  -->
    <section class="training-trusted-link">
        <div class="container">
            <div class="row">
                <div class="col-lg-3 col-md-6 col-sm-12">
                    <div class="card training-trusted-img">
                        <img src="<?php echo e(asset('web')); ?>/Training/t.link1.png" class="card-img-top" alt="...">
                    </div>
                </div>

                <div class="col-lg-3 col-md-6 col-sm-12">
                    <div class="card training-trusted-img">
                        <img src="<?php echo e(asset('web')); ?>/Training/t.link2.png" class="card-img-top" alt="...">
                    </div>
                </div>

                <div class="col-lg-3 col-md-6 col-sm-12">
                    <div class="card training-trusted-img">
                        <img src="<?php echo e(asset('web')); ?>/Training/t.link3.png" class="card-img-top" alt="...">
                    </div>
                </div>

                <div class="col-lg-3 col-md-6 col-sm-12">
                    <div class="card training-trusted-img">
                        <img src="<?php echo e(asset('web')); ?>/Training/t.link4.png" class="card-img-top" alt="...">
                    </div>
                </div>

                <div class="col-lg-3 col-md-6 col-sm-12">
                    <div class="card training-trusted-img">
                        <img src="<?php echo e(asset('web')); ?>/Training/t.link5.png" class="card-img-top" alt="...">
                    </div>
                </div>

                <div class="col-lg-3 col-md-6 col-sm-12">
                    <div class="card training-trusted-img">
                        <img src="<?php echo e(asset('web')); ?>/Training/t.link1.png" class="card-img-top" alt="...">
                    </div>
                </div>

                <div class="col-lg-3 col-md-6 col-sm-12">
                    <div class="card training-trusted-img">
                        <img src="<?php echo e(asset('web')); ?>/Training/t.link2.png" class="card-img-top" alt="...">
                    </div>
                </div>

                <div class="col-lg-3 col-md-6 col-sm-12">
                    <div class="card training-trusted-img">
                        <img src="<?php echo e(asset('web')); ?>/Training/t.link3.png" class="card-img-top" alt="...">
                    </div>
                </div>

                <div class="col-lg-3 col-md-6 col-sm-12">
                    <div class="card training-trusted-img">
                        <img src="<?php echo e(asset('web')); ?>/Training/t.link4.png" class="card-img-top" alt="...">
                    </div>
                </div>

                <div class="col-lg-3 col-md-6 col-sm-12">
                    <div class="card training-trusted-img">
                        <img src="<?php echo e(asset('web')); ?>/Training/t.link5.png" class="card-img-top" alt="...">
                    </div>
                </div>

                <div class="col-lg-3 col-md-6 col-sm-12">
                    <div class="card training-trusted-img">
                        <img src="<?php echo e(asset('web')); ?>/Training/t.link1.png" class="card-img-top" alt="...">
                    </div>
                </div>

                <div class="col-lg-3 col-md-6 col-sm-12">
                    <div class="card training-trusted-img">
                        <img src="<?php echo e(asset('web')); ?>/Training/t.link2.png" class="card-img-top" alt="...">
                    </div>
                </div>

                <div class="col-lg-3 col-md-6 col-sm-12">
                    <div class="card training-trusted-img">
                        <img src="<?php echo e(asset('web')); ?>/Training/t.link3.png" class="card-img-top" alt="...">
                    </div>
                </div>

                <div class="col-lg-3 col-md-6 col-sm-12">
                    <div class="card training-trusted-img">
                        <img src="<?php echo e(asset('web')); ?>/Training/t.link4.png" class="card-img-top" alt="...">
                    </div>
                </div>

                <div class="col-lg-3 col-md-6 col-sm-12">
                    <div class="card training-trusted-img">
                        <img src="<?php echo e(asset('web')); ?>/Training/t.link5.png" class="card-img-top" alt="...">
                    </div>
                </div>

                <div class="col-lg-3 col-md-6 col-sm-12">
                    <div class="card training-trusted-img">
                        <img src="<?php echo e(asset('web')); ?>/Training/t.link4.png" class="card-img-top" alt="...">
                    </div>
                </div>
            </div>
        </div>

    </section>

    <!-- ==========================================================================
TRAINING INCUBATOR TRUSTED LINK PLATFORM SECTION  END
==========================================================================  -->

<?php echo $__env->make('web.component.subscribe', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>; 




</main>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('web.layouts.app', ['title' => 'Traning'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\local_server\htdocs\disclea\resources\views/web/traning.blade.php ENDPATH**/ ?>