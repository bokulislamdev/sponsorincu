


<?php $__env->startSection('content'); ?>


        <!-- ==========================================================================
ABOUT-SLIDER SECTION START
==========================================================================  -->

<main class="full-body">

    <section class="about-slider-section section">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12">
                    <div class="about-heading">
                        <h1><?php echo app('translator')->get('home.About_Us'); ?></h1>
                        <hr>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- ==========================================================================
ABOUT-SLIDER SECTION END
==========================================================================  -->


    <!-- ================================================================
ABOUT-DISCOVERING-LEADERSHIP-CENTER START
=================================================================-->
    <section class="about-discover-center">
        .<div class="container">
            <div class="row">
                <div class="col-lg-6 col-md-6 col-sm-12">
                    <div class="discover-center-content">
                        <h1><?php echo app('translator')->get('home.Leadership_Discovery_Center'); ?></h1>
                        <p><?php echo app('translator')->get('home.Discovering_Leadership_Center'); ?></p>
                    </div>
                </div>

                <div class="col-lg-6 col-md-6 col-sm-12">
                    <div class="discover-center-image">
                        <img src="<?php echo e(asset('web')); ?>/About/Discovering-Leadership-Center.png" alt="">
                    </div>
                </div>
            </div>
        </div>

    </section>


    <!-- ================================================================
ABOUT-DISCOVERING-LEADERSHIP-CENTER START
=================================================================-->


    <!-- ================================================================
        DISCOVERING-LEADERSHIP-CENTER-END PART START
=================================================================-->

    <section class="leadership-center-end-section">
        .<div class="container">
            <div class="proud-heading">
                <h1><?php echo app('translator')->get('home.At_Discovering_Leadership'); ?></h1>
               
            </div>
            <div class="row">
                <div class="col-lg-4 col-md-6 col-sm-12 pb-4">
                    <div class="card card-lead h-100">
                        <div class="card-body proud-content">
                            <h1>01</h1>
                            <p class="card-text"><?php echo app('translator')->get('home.Part_of_transformation'); ?>
                            </p>
                        </div>
                    </div>
                </div>

                <div class="col-lg-4 col-md-6 col-sm-12 pb-4">
                    <div class="card card-lead h-100">
                        <div class="card-body proud-content">
                            <h1>02</h1>
                            <p class="card-text">
                                <?php echo app('translator')->get('home.A_global_model'); ?>
                            </p>
                        </div>
                    </div>
                </div>

                <div class="col-lg-4 col-md-6 col-sm-12 pb-4">
                    <div class="card card-lead h-100">
                        <div class="card-body proud-content">
                            <h1>03</h1>
                            <p class="card-text"><?php echo app('translator')->get('home.We_created_sustainable'); ?>
                            </p>
                        </div>
                    </div>
                </div>

                <div class="col-lg-4 col-md-6 col-sm-12 pb-4">
                    <div class="card card-lead h-100">
                        <div class="card-body proud-content">
                            <h1>04</h1>
                            <p class="card-text">
                                <?php echo app('translator')->get('home.We_have_integrated'); ?>
                            </p>
                        </div>
                    </div>
                </div>

                <div class="col-lg-4 col-md-6 col-sm-12 pb-4">
                    <div class="card card-lead h-100">
                        <div class="card-body proud-content">
                            <h1>05</h1>
                            <p class="card-text">
                                <?php echo app('translator')->get('home.Keeping_pace_with'); ?>
                            </p>
                        </div>
                    </div>
                </div>

                <div class="col-lg-4 col-md-6 col-sm-12 pb-4">
                    <div class="card card-lead h-100">
                        <div class="card-body proud-content">
                            <h1>06</h1>
                            <p class="card-text">
                                <?php echo app('translator')->get('home.Providing_many_programs'); ?>
                            </p>
                        </div>
                    </div>
                </div>

                <div class="col-lg-4 col-md-6 col-sm-12 pb-4">
                    <div class="card card-lead h-100">
                        <div class="card-body proud-content">
                            <h1>07</h1>
                            <p class="card-text">
                                <?php echo app('translator')->get('home.Providing_a_package'); ?>
                            </p>
                        </div>
                    </div>
                </div>

                <div class="col-lg-4 col-md-6 col-sm-12 pb-4">
                    <div class="card card-lead h-100">
                        <div class="card-body proud-content">
                            <h1>08</h1>
                            <p class="card-text">
                                <?php echo app('translator')->get('home.Providing_many_solutions'); ?>
                            </p>
                        </div>
                    </div>
                </div>

                <div class="col-lg-4 col-md-6 col-sm-12 pb-4">
                    <div class="card card-lead h-100">
                        <div class="card-body proud-content">
                            <h1>09</h1>
                            <p class="card-text">
                                <?php echo app('translator')->get('home.The_use_of_many'); ?>
                            </p>
                        </div>
                    </div>
                </div>


            </div>
        </div>

    </section>



    <!-- ================================================================
        DISCOVERING-LEADERSHIP-CENTER-END PART START
=================================================================-->


    <!-- ==========================================================================
ABOUT US PAGE SOME SERVICES SECTION START
==========================================================================  -->

    <section class="about-page-service-sec">
        <div class="container">
            <div class="row">
                <div class="col-lg-4 col-md-6 col-sm-12 mb-md-3 mb-sm-3">
                    <div class="card card-img h-100">
                        <img src="<?php echo e(asset('web')); ?>/icons/trophy.png" class="card-img-top" alt="...">
                        <div class="card-body">
                            <p class="card-text"> <?php echo app('translator')->get('home.At_Leadership_Discovery'); ?>
                            </p>
                        </div>
                    </div>
                </div>


                <div class="col-lg-4 col-md-6 col-sm-12 mb-md-3 mb-sm-3">
                    <div class="card card-img h-100">
                        <img src="<?php echo e(asset('web')); ?>/icons/service%20bag.png" class="card-img-top" alt="...">
                        <div class="card-body">
                            <p class="card-text"> <?php echo app('translator')->get('home.Discovering_Leadership_Center'); ?>
                            </p>
                        </div>
                    </div>
                </div>


                <div class="col-lg-4 col-md-6 col-sm-12 mb-md-3 mb-sm-3">
                    <div class="card card-img h-100">
                        <img src="<?php echo e(asset('web')); ?>/icons/home.png" class="card-img-top" alt="...">
                        <div class="card-body">
                            <p class="card-text">
                                <?php echo app('translator')->get('home.One_fact_remains'); ?>
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>


    <!-- ==========================================================================
ABOUT US PAGE SOME SERVICES SECTION END
==========================================================================  -->


    <!-- =================================================================
ABOUT US PAGE SECTOR SERVE SECTION START
===================================================================== -->

    <section class="about-discover-center">
        <div class="container">
            <div class="row">
                <div class="col-lg-6 col-md-6 col-sm-12">
                    <div class="discover-center-content">
                        <h1><?php echo app('translator')->get('home.Sectors_we_serve'); ?></h1>
                        <p>
                            <?php echo app('translator')->get('home.There_are_many'); ?>
                        </p>
                        <p>
                            <?php echo app('translator')->get('home.Contact_us_to_build'); ?>
                        </p>

                        <div class="more-inf0-inner">
                            <button class="btn"><?php echo app('translator')->get('home.Contact_Us'); ?></button>
                        </div>

                    </div>
                </div>

                <div class="col-lg-6 col-md-6 col-sm-12">
                    <div class="discover-center-image">
                        <img src="<?php echo e(asset('web')); ?>/About/sectors-we-serve.png" alt="">
                    </div>
                </div>

            </div>
        </div>

    </section>
    <!-- =================================================================
ABOUT US PAGE SECTOR SERVE SECTION START
===================================================================== -->

    <!-- ==========================================================================
ACTIVITIES & SECTORS SECTION START
==========================================================================  -->
    <section class="activities-sectors-section">
        .<div class="container">
            <div class="activities-heading">
                <h1><?php echo app('translator')->get('home.The_activities_and_sectors'); ?></h1>
                <hr>
            </div>
            <div class="row">

                <div class="col-lg-4 col-md-6 col-sm-12 pb-4">
                    <div class="card activities-img h-100">
                        <img src="<?php echo e(asset('web')); ?>/About/The%20activities%20and%20sectors%20served%20by%20Discovering%20Leadership%20center/Agricultural-sector.png"
                            class="card-img-top" alt="Agricultural-sector.png">
                        <div class="card-body activities-img-content mt-3">
                            <h3><?php echo app('translator')->get('home.Agricultural_sector'); ?></h3>
                        </div>
                    </div>
                </div>

                <div class="col-lg-4 col-md-6 col-sm-12 pb-4">
                    <div class="card activities-img h-100">
                        <img src="<?php echo e(asset('web')); ?>/About/The%20activities%20and%20sectors%20served%20by%20Discovering%20Leadership%20center/industrial-sector.png"
                            class="card-img-top" alt="Agricultural-sector.png">
                        <div class="card-body activities-img-content mt-3">
                            <h3><?php echo app('translator')->get('home.Industrial_sector'); ?></h3>
                        </div>
                    </div>
                </div>

                <div class="col-lg-4 col-md-6 col-sm-12 pb-4">
                    <div class="card activities-img h-100">
                        <img src="<?php echo e(asset('web')); ?>/About/The%20activities%20and%20sectors%20served%20by%20Discovering%20Leadership%20center/Mining-%26-Petrochamical-sector.png"
                            class="card-img-top" alt="Agricultural-sector.png">
                        <div class="card-body activities-img-content mt-3">
                            <h3><?php echo app('translator')->get('home.Mining_and_petrochemical'); ?></h3>
                        </div>
                    </div>
                </div>

                <div class="col-lg-4 col-md-6 col-sm-12 pb-4">
                    <div class="card activities-img h-100">
                        <img src="<?php echo e(asset('web')); ?>/About/The%20activities%20and%20sectors%20served%20by%20Discovering%20Leadership%20center/Construction-sector.png"
                            class="card-img-top" alt="Agricultural-sector.png">
                        <div class="card-body activities-img-content mt-3">
                            <h3><?php echo app('translator')->get('home.Construction_sector'); ?></h3>
                        </div>
                    </div>
                </div>

                <div class="col-lg-4 col-md-6 col-sm-12 pb-4">
                    <div class="card activities-img h-100">
                        <img src="<?php echo e(asset('web')); ?>/About/The%20activities%20and%20sectors%20served%20by%20Discovering%20Leadership%20center/Services-sector.png"
                            class="card-img-top" alt="Agricultural-sector.png">
                        <div class="card-body activities-img-content mt-3">
                            <h3><?php echo app('translator')->get('home.Services_sector'); ?></h3>
                        </div>
                    </div>
                </div>

                <div class="col-lg-4 col-md-6 col-sm-12 pb-4">
                    <div class="card activities-img h-100">
                        <img src="<?php echo e(asset('web')); ?>/About/The%20activities%20and%20sectors%20served%20by%20Discovering%20Leadership%20center/Tourism-sector.png"
                            class="card-img-top" alt="Agricultural-sector.png">
                        <div class="card-body activities-img-content mt-3">
                            <h3><?php echo app('translator')->get('home.Tourism_sector'); ?></h3>
                        </div>
                    </div>
                </div>

                <div class="col-lg-4 col-md-6 col-sm-12 pb-4">
                    <div class="card activities-img h-100">
                        <img src="<?php echo e(asset('web')); ?>/About/The%20activities%20and%20sectors%20served%20by%20Discovering%20Leadership%20center/financial-sector.png"
                            class="card-img-top" alt="Agricultural-sector.png">
                        <div class="card-body activities-img-content mt-3">
                            <h3><?php echo app('translator')->get('home.Financial_sector'); ?></h3>
                        </div>
                    </div>
                </div>

                <div class="col-lg-4 col-md-6 col-sm-12 pb-4">
                    <div class="card activities-img h-100">
                        <img src="<?php echo e(asset('web')); ?>/About/The%20activities%20and%20sectors%20served%20by%20Discovering%20Leadership%20center/Telecom-sector.png"
                            class="card-img-top" alt="Agricultural-sector.png">
                        <div class="card-body activities-img-content mt-3">
                            <h3><?php echo app('translator')->get('home.Telecom_sector'); ?></h3>
                        </div>
                    </div>
                </div>

                <div class="col-lg-4 col-md-6 col-sm-12 pb-4">
                    <div class="card activities-img h-100">
                        <img src="<?php echo e(asset('web')); ?>/About/The%20activities%20and%20sectors%20served%20by%20Discovering%20Leadership%20center/Transport-sector.png"
                            class="card-img-top" alt="Agricultural-sector.png">
                        <div class="card-body activities-img-content mt-3">
                            <h3><?php echo app('translator')->get('home.Transport_sector'); ?></h3>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </section>

    <!-- ==========================================================================
ACTIVITIES & SECTORS SECTION END
==========================================================================  -->


    <!-- =====================================================================
BRAND SECTION START
=============================================================================-->

    <section class="brand-section">
        <div class="container">
            <div class="row">
                <div class="col-lg-2 col-md-4 col-sm-6">
                    <div class="brand-img">
                        <img src="<?php echo e(asset('web')); ?>/brands/brand1.png" alt="...">
                    </div>
                </div>

                <div class="col-lg-2 col-md-4 col-sm-6">
                    <div class="brand-img">
                        <img src="<?php echo e(asset('web')); ?>/brands/brand2.png" alt="...">
                    </div>
                </div>

                <div class="col-lg-2 col-md-4 col-sm-6">
                    <div class="brand-img">
                        <img src="<?php echo e(asset('web')); ?>/brands/brand3.png" alt="...">
                    </div>
                </div>

                <div class="col-lg-2 col-md-4 col-sm-6">
                    <div class="brand-img">
                        <img src="<?php echo e(asset('web')); ?>/brands/brand4.png" alt="...">
                    </div>
                </div>

                <div class="col-lg-2 col-md-4 col-sm-6">
                    <div class="brand-img">
                        <img src="<?php echo e(asset('web')); ?>/brands/brand5.png" alt="...">
                    </div>
                </div>

                <div class="col-lg-2 col-md-4 col-sm-6">
                    <div class="brand-img">
                        <img src="<?php echo e(asset('web')); ?>/brands/brand6.png" alt="...">
                    </div>
                </div>
            </div>
        </div>
    </section>


    <!-- =====================================================================
      BRAND SECTION END
=============================================================================-->



    <!-- ==========================================================================
IN ABOUT PAGE BELOW THE BRAND SECTION SECTION START
==========================================================================  -->
    <section class="activities-sector-learn-section">
        <div class="container">
            <div class="row">

                <div class="col-lg-4 col-md-6 col-sm-12 pb-4">
                    <div class="card learn-img h-100">
                        <img src="<?php echo e(asset('web')); ?>/About/Learn-the-leaders-in-the-military.png" class="card-img-top" alt="...">
                        <div class="card-body learn-desc">
                            <h2><?php echo app('translator')->get('home.Learn_the_leaders'); ?></h2>
                            <p class="card-text"><?php echo app('translator')->get('home.Learn_the_leaders_p'); ?>
                            </p>
                        </div>
                    </div>
                </div>

                <div class="col-lg-4 col-md-6 col-sm-12 pb-4">
                    <div class="card learn-img h-100">
                        <img src="<?php echo e(asset('web')); ?>/About/Education-of-health-leaders.png" class="card-img-top" alt="...">
                        <div class="card-body learn-desc">
                            <h2><?php echo app('translator')->get('home.Education_of_health_leaders'); ?></h2>
                            <p class="card-text">
                                <?php echo app('translator')->get('home.Education_of_health_leaders_p'); ?>
                            </p>
                        </div>
                    </div>
                </div>


                <div class="col-lg-4 col-md-6 col-sm-12 pb-4">
                    <div class="card learn-img h-100">
                        <img src="<?php echo e(asset('web')); ?>/About/See-our-Social-sector.png" class="card-img-top" alt="...">
                        <div class="card-body learn-desc">
                            <h2> <?php echo app('translator')->get('home.Social_sector'); ?></h2>
                            <p class="card-text">
                                <?php echo app('translator')->get('home.Social_sector_p'); ?>
                            </p>
                        </div>
                    </div>
                </div>


                <div class="col-lg-4 col-md-6 col-sm-12 pb-4">
                    <div class="card learn-img h-100">
                        <img src="<?php echo e(asset('web')); ?>/About/Leaders-in-the-energy-sector.png" class="card-img-top" alt="...">
                        <div class="card-body learn-desc">
                            <h2> <?php echo app('translator')->get('home.Leaders_in_the_energy_sector'); ?></h2>
                            <p class="card-text">
                                <?php echo app('translator')->get('home.Leaders_in_the_energy_sector_p'); ?>
                            </p>
                        </div>
                    </div>
                </div>


                <div class="col-lg-4 col-md-6 col-sm-12 pb-4">
                    <div class="card learn-img h-100">
                        <img src="<?php echo e(asset('web')); ?>/About/our-Financial-Services.png" class="card-img-top" alt="...">
                        <div class="card-body learn-desc">
                            <h2> <?php echo app('translator')->get('home.Financial_Services'); ?></h2>
                            <p class="card-text">
                                <?php echo app('translator')->get('home.Financial_Services_p'); ?>
                            </p>
                        </div>
                    </div>
                </div>


                <div class="col-lg-4 col-md-6 col-sm-12 pb-4">
                    <div class="card learn-img h-100">
                        <img src="<?php echo e(asset('web')); ?>/About/our-Government-sector.png" class="card-img-top" alt="...">
                        <div class="card-body learn-desc">
                            <h2> <?php echo app('translator')->get('home.Government_sector'); ?></h2>
                            <p class="card-text">
                                <?php echo app('translator')->get('home.Government_sector_p'); ?>
                            </p>
                        </div>
                    </div>
                </div>


            </div>
        </div>
    </section>

    <!-- ==========================================================================
IN ABOUT PAGE BELOW THE BRAND SECTION SECTION START
==========================================================================  -->

        <?php echo $__env->make('web.component.client', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>; 
        <?php echo $__env->make('web.component.subscribe', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>; 


<?php $__env->stopSection(); ?>


<?php echo $__env->make('web.layouts.app', ['title' => 'About'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\local_server\htdocs\disclea\resources\views/web/about.blade.php ENDPATH**/ ?>