 <!-- ==========================================================================
FOOTER SECTIONS START
==========================================================================  -->
<footer>
    <section class="footer-menu-area p-spacer footer-contents">
      <div class="container">
        <div class="row">
          <div class="col-lg-4 col-md-4 col-sm-12">
            <div class="footer-mainmenu footer-contents">
              <div class="menubar-left footer-img">
                <a class="navbar-brand font-weight-bolder" href="index-2.html">
                  <img src="<?php echo e(asset('web')); ?>/brands/footer%20img.png" alt="Logo" style="width:150px; height: 50px;">
                </a>
              </div>
              <br>
              <p>
                <?php echo app('translator')->get('home.footer_description'); ?>
              </p>
              <hr>
              <span class="copyright-t"><?php echo app('translator')->get('home.copyright'); ?></span> </span>
            </div>
          </div>


          <div class="col-lg-4 col-md-4 coli-sm-12">
            <div class="footer-important-link">
              <h6 class="font-weight-bolder" style="color: #FFF;"><?php echo app('translator')->get('home.Important_LINK'); ?></h6>

              <hr>
              <ul>
                <li><a href="#"><?php echo app('translator')->get('home.Homepage'); ?></a></li>
                <li><a href="#"><?php echo app('translator')->get('home.Training'); ?></a></li>
                <li><a href="#"><?php echo app('translator')->get('home.Our_Services'); ?></a></li>
                <li><a href="#"><?php echo app('translator')->get('home.Solutions_and_Services2'); ?></a></li>
                <li><a href="#"><?php echo app('translator')->get('home.Our_methodology'); ?></a></li>
                <li><a href="#"><?php echo app('translator')->get('home.Our_Latest_Project'); ?></a></li>
                <li><a href="#"><?php echo app('translator')->get('home.About_Us'); ?></a></li>
                <li><a href="#"><?php echo app('translator')->get('home.Help_Support'); ?></a></li>
              </ul>
            </div>
          </div>
          <div class="col-lg-4 col-md-4 col-sm-12">
            <div class="footer-message footer-important-link">
              <h6 class="font-weight-bolder" style="color: #FFF;"><?php echo app('translator')->get('home.Contact_Info'); ?></h6>
              <hr>
              <br>
              <div class="footer-mainmenu footer-contents">

                <ul>
                  <li><a href="#"><?php echo app('translator')->get('home.Phone'); ?> : <span class="color-c"> <?php echo e($websetting->phone); ?></span></a></li>
                  <li><a href="#"><?php echo app('translator')->get('home.whats_app'); ?> : <span class="color-c"> +996 0551175959</span> </a></li>
                  <li><a href="#"><?php echo app('translator')->get('home.Email'); ?> : <span class="color-c"> <?php echo e($websetting->email); ?></span> </a></li>
                </ul>
                <p><?php echo app('translator')->get('home.address'); ?>: <?php echo app('translator')->get('home.address_details'); ?> </p>
              </div>


              <form action="#">
                <div class="form-group">
                  <input type="email" class="form-control" name="Email" placeholder="<?php echo app('translator')->get('home.email_address'); ?>">
                </div>
                <button type="submit"><?php echo app('translator')->get('home.send'); ?></button>
              </form>
            </div>
            <div class="footer-icon">
              <div class="topbar-menu">
                <?php echo app('translator')->get('home.FOLLOW_US_ON'); ?> :
                <ul class="icones-color">
                  <li>
                    <a href="#"><i class="fab fa-facebook mx-2" aria-hidden="true"></i></a>
                  </li>

                  <li>
                    <a href="#"><i class="fab fa-google mx-2" aria-hidden="true"></i></a>
                  </li>

                  <li>
                    <a href="#"><i class="fab fa-instagram mx-2" aria-hidden="true"></i></a>
                  </li>

                  <li>
                    <a href="#"><i class="fab fa-youtube mx-2" aria-hidden="true"></i></a>
                  </li>
                </ul>
                <span class="mx-2"></span>

              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  </footer>

  <!-- ==========================================================================
FOOTER SECTIONS START
==========================================================================  -->
<?php /**PATH D:\local_server\htdocs\disclea\resources\views/web/layouts/inc/footer.blade.php ENDPATH**/ ?>