<?php $__env->startSection('content'); ?>

    <!--    SLIDER SECTION-->
    <section class="slider-section">
        <div id="carouselExampleDark" class="carousel carousel-dark slide" data-bs-ride="carousel">
            <div class="carousel-indicators">
                <button type="button" data-bs-target="#carouselExampleDark" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>
                <button type="button" data-bs-target="#carouselExampleDark" data-bs-slide-to="1" aria-label="Slide 2"></button>
                <button type="button" data-bs-target="#carouselExampleDark" data-bs-slide-to="2" aria-label="Slide 3"></button>
            </div>
            <div class="carousel-inner">
                <?php $__currentLoopData = $sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="carousel-item <?php echo e($key == 0 ? 'active' : ''); ?>" data-bs-interval="10000">
                   <img src="<?php echo e(asset($slider->image)); ?>" class="d-block w-100" alt="...">
                    <div class="carousel-caption custom">
                        <h5>Aswaq.com platform for marketing Halal food products and related activities</h5>
                        <a href="#">Shop Now</a>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div>
            <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleDark" data-bs-slide="prev">
                <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                <span class="visually-hidden">Previous</span>
            </button>
            <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleDark" data-bs-slide="next">
                <span class="carousel-control-next-icon" aria-hidden="true"></span>
                <span class="visually-hidden">Next</span>
            </button>
        </div>
    </section>
    <!--    SLIDER SECTION END-->



    <!--    FETURE SECTION-->
    <section class="feture-section py-5">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="section-title text-center">
                        <h4>Featured Products</h4>
                    </div>
                </div>
            </div>
            <div class="row mt-5">
                <?php $__currentLoopData = $feture_products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


                <div class="col-12 col-sm-6 col-md-4 col-lg-3 mb-4">
                    <div class="product-box d-flex align-content-between flex-wrap">
                        <div class="product-image">
                           <img src="<?php echo e(asset($product->image)); ?>" alt="Product Image">
                            <div class="cart-overlay">
                                <a href="javascript:void(0)" class="product_id" data-id="<?php echo e($product->id); ?>">
                                    <i class="far fa-cart-plus"></i>
                                </a>
                                <a href="javascript:void(0)">
                                    <i class="far fa-heart"></i>
                                </a>
                                <a href="javascript:void(0)">
                                    <i class="far fa-search-plus"></i>
                                </a>
                            </div>
                        </div>
                        <div class="w-100">
                            <div class="details-overlay py-2 text-center">
                                <a href="<?php echo e(route('product.details',$product->slug)); ?>">
                                    View Details
                                </a>
                            </div>
                            <div class="product-text">
                                <h4><?php echo e($product->name); ?></h4>
                                <div class="product-color py-2">
                                    <span style="background: red;"></span>
                                    <span style="background: #EF8000;"></span>
                                    <span style="background: #cccccc;"></span>
                                </div>
                                <h5>Code - #<?php echo e($product->id); ?></h5>
                                <p>SAR <?php echo e($product->price); ?></p>
                            </div>
                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div>

        </div>
    </section>
    <!--    FETURE SECTION END-->



    <!--    LATEST PRODUCT-->
    <section class="latest-product py-5">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="section-title text-center">
                        <h4>Latest Products</h4>
                        <div class="latest-filter">
                            <button type="button" data-filter=".new">New Arrival</button>
                            <button type="button" data-filter=".best-sell">Best Seller</button>
                            <button type="button" data-filter=".featured">Featured</button>
                            <button type="button" data-filter=".offer">Special Offer</button>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row mixit-js mt-5">
                <?php $__currentLoopData = $new_arrival; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-12 col-sm-6 col-md-4 mb-4 mix new">
                    <div class="latest-product-box d-flex align-content-between flex-wrap">
                        <div class="latest-product-img">
                            <a href="<?php echo e(route('product.details',$product->slug)); ?>">
                               <img src="<?php echo e(asset($product->image)); ?>" alt="">
                            </a>
                            <div class="latest-product-overlay">
                                <div class="sale-img">
                                   <img src="<?php echo e(asset('web')); ?>/images/icons/sale.png" alt="">
                                </div>
                                <div class="cart-img">
                                    <a href="javascript:void(0)" class="product_id" data-id="<?php echo e($product->id); ?>">
                                       <img src="<?php echo e(asset('web')); ?>/images/icons/cart2.png" alt="">
                                    </a>
                                    <a href="#">
                                       <img src="<?php echo e(asset('web')); ?>/images/icons/love2.png" alt="">
                                    </a>
                                    <a href="#">
                                       <img src="<?php echo e(asset('web')); ?>/images/icons/zoom.png" alt="">
                                    </a>
                                </div>
                            </div>
                        </div>
                        <div class="latest-product-text py-3 w-100">
                            <div class="d-flex bd-highlight">
                                <div class="w-100 bd-highlight">
                                    <h5><?php echo e($product->name); ?></h5>
                                </div>
                                <div class="flex-shrink-1 bd-highlight">
                                    <p>
                                        <span>SAR <?php echo e($product->discount_price); ?></span>
                                        <span><del><?php echo e($product->price); ?></del></span>
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <?php $__currentLoopData = $feture_products2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-12 col-sm-6 col-md-4 mb-4 mix featured">
                    <div class="latest-product-box d-flex align-content-between flex-wrap">
                        <div class="latest-product-img">
                            <a href="#">
                               <img src="<?php echo e(asset($product->image)); ?>" alt="">
                            </a>
                            <div class="latest-product-overlay">
                                <div class="sale-img">
                                   <img src="<?php echo e(asset('web')); ?>/images/icons/sale.png" alt="">
                                </div>
                                <div class="cart-img">
                                    <a href="javascript:void(0)" class="product_id" data-id="<?php echo e($product->id); ?>">
                                       <img src="<?php echo e(asset('web')); ?>/images/icons/cart2.png" alt="">
                                    </a>
                                    <a href="#">
                                       <img src="<?php echo e(asset('web')); ?>/images/icons/love2.png" alt="">
                                    </a>
                                    <a href="#">
                                       <img src="<?php echo e(asset('web')); ?>/images/icons/zoom.png" alt="">
                                    </a>
                                </div>
                            </div>
                        </div>
                        <div class="latest-product-text py-3 w-100">
                            <div class="d-flex bd-highlight">
                                <div class="w-100 bd-highlight">
                                    <h5><?php echo e($product->name); ?></h5>
                                </div>
                                <div class="flex-shrink-1 bd-highlight">
                                    <p>
                                        <span>SAR <?php echo e($product->discount_price); ?></span>
                                        <span><del><?php echo e($product->price); ?></del></span>
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                <?php $__currentLoopData = $special_offer; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-12 col-sm-6 col-md-4 mb-4 mix offer">
                    <div class="latest-product-box d-flex align-content-between flex-wrap">
                        <div class="latest-product-img">
                            <a href="#">
                               <img src="<?php echo e(asset($product->image)); ?>" alt="">
                            </a>
                            <div class="latest-product-overlay">
                                <div class="sale-img">
                                   <img src="<?php echo e(asset('web')); ?>/images/icons/sale.png" alt="">
                                </div>
                                <div class="cart-img">
                                    <a href="javascript:void(0)" class="product_id" data-id="<?php echo e($product->id); ?>">
                                       <img src="<?php echo e(asset('web')); ?>/images/icons/cart2.png" alt="">
                                    </a>
                                    <a href="#">
                                       <img src="<?php echo e(asset('web')); ?>/images/icons/love2.png" alt="">
                                    </a>
                                    <a href="#">
                                       <img src="<?php echo e(asset('web')); ?>/images/icons/zoom.png" alt="">
                                    </a>
                                </div>
                            </div>
                        </div>
                        <div class="latest-product-text py-3 w-100">
                            <div class="d-flex bd-highlight">
                                <div class="w-100 bd-highlight">
                                    <h5><?php echo e($product->name); ?></h5>
                                </div>
                                <div class="flex-shrink-1 bd-highlight">
                                    <p>
                                        <span>SAR <?php echo e($product->discount_price); ?></span>
                                        <span><del><?php echo e($product->price); ?></del></span>
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>


                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div>
        </div>
    </section>
    <!--    LATEST PRODUCT END-->

    <!--    OFFER SECTION-->
    <section class="offer-section py-5">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="section-title text-center">
                        <h4>What HalalFood Offer!</h4>
                    </div>
                </div>
            </div>
            <div class="row mt-5">
                <div class="col-12 col-sm-6 col-md-4 col-lg-3 mb-4">
                    <div class="offer-box d-flex align-content-between flex-wrap">
                        <div class="offer-image w-100">
                           <img src="<?php echo e(asset('web')); ?>/images/icons/offer1.png" alt="">
                        </div>
                        <div class="offer-text w-100">
                            <h4>24/7 Support</h4>
                            <p>
                                Lorem ipsum dolor sit amet, consectetur adipiscing elit. Massa purus gravida.
                            </p>
                        </div>
                    </div>
                </div>
                <div class="col-12 col-sm-6 col-md-4 col-lg-3 mb-4">
                    <div class="offer-box d-flex align-content-between flex-wrap">
                        <div class="offer-image w-100">
                           <img src="<?php echo e(asset('web')); ?>/images/icons/offer2.png" alt="">
                        </div>
                        <div class="offer-text w-100">
                            <h4>24/7 Support</h4>
                            <p>
                                Lorem ipsum dolor sit amet, consectetur adipiscing elit. Massa purus gravida.
                            </p>
                        </div>
                    </div>
                </div>
                <div class="col-12 col-sm-6 col-md-4 col-lg-3 mb-4">
                    <div class="offer-box d-flex align-content-between flex-wrap">
                        <div class="offer-image w-100">
                           <img src="<?php echo e(asset('web')); ?>/images/icons/offer3.png" alt="">
                        </div>
                        <div class="offer-text w-100">
                            <h4>24/7 Support</h4>
                            <p>
                                Lorem ipsum dolor sit amet, consectetur adipiscing elit. Massa purus gravida.
                            </p>
                        </div>
                    </div>
                </div>
                <div class="col-12 col-sm-6 col-md-4 col-lg-3 mb-4">
                    <div class="offer-box">
                        <div class="offer-image">
                           <img src="<?php echo e(asset('web')); ?>/images/icons/offer4.png" alt="">
                        </div>
                        <div class="offer-text">
                            <h4>24/7 Support</h4>
                            <p>
                                Lorem ipsum dolor sit amet, consectetur adipiscing elit. Massa purus gravida.
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--    OFFER SECTION END-->

    <!--    Unique PRODUCT SECTION-->
    <section class="unique-product py-5">
        <div class="container">
            <div class="row mt-5">
                <div class="col-12 col-md-6">
                    <div class="unique-img">
                       <img src="<?php echo e(asset('web')); ?>/images/photos/trending.png" alt="Tranding Product Image">
                    </div>
                </div>
                <div class="col-12 col-md-6">
                    <div class="unique-text">
                        <h2>Unique Features Of leatest & Trending Poducts</h2>
                        <div class="unique-list py-5">
                            <div class="list-single">
                                <span style="background: #F52B70;"></span>
                                <p>All Products are Halal Certified</p>
                            </div>
                            <div class="list-single">
                                <span style="background: #2B2BF5;"></span>
                                <p>Varities Products are Available 24/7</p>
                            </div>
                            <div class="list-single">
                                <span style="background: #2BF5CC;"></span>
                                <p>Trusted & Clients Satisfaction</p>
                            </div>
                        </div>
                        <div class="unique-cart d-flex align-items-center">
                            <a href="<?php echo e(route('trending-product')); ?>">Add To Cart</a>
                            
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--  UNIQUE PRODUCT SECTION END-->

    <!--    TRENDING PRODUCT-->
    <section class="trending-prodcut py-5">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="section-title text-center">
                        <h4>Trending Products</h4>
                    </div>
                </div>
            </div>
            <div class="row mt-5">
                <?php $__currentLoopData = $trending_product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


                <div class="col-12 col-sm-6 col-md-4 col-lg-3 mb-4">
                    <div class="trending-product d-flex align-content-between flex-wrap">
                        <div class="trending-product-image w-100">
                            <a href="<?php echo e(route('product.details',$product->slug)); ?>">
                               <img src="<?php echo e(asset($product->image)); ?>" alt="Product Photo">
                            </a>
                        </div>
                        <div class="trending-product-text w-100 py-2">
                            <h6><?php echo e($product->name); ?></h6>
                            <div class="trending-product-price">
                                <span><?php echo e($product->discount_price); ?> </span>
                                <span> <del><?php echo e($product->discount_price); ?></del></span>
                            </div>
                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </section>
    <!--    TRENDING PRODUCT END-->

    <!--    OFFER ALL-->
    <section class="offer-all">
        <div class="container">
            <div class="row">
                <div class="col-12 col-md-6 col-lg-8 mb-5 mb-md-0">
                    <div class="row">
                        <?php $__currentLoopData = $trending_product2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


                        <div class="col-12 col-sm-6 col-md-12 col-lg-6">
                            <div class="offer-all-box">
                                <h4>23% off in all products</h4>
                                <a href="<?php echo e(route('product.details',$product->slug)); ?>">Shop Now</a>
                                <div class="offer-all-img">
                                   <img src="<?php echo e(asset($product->image)); ?>" alt="Product Photo">
                                </div>
                            </div>
                        </div>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



                    </div>
                </div>
                <div class="col-12 col-md-6 col-lg-4">
                    <?php $__currentLoopData = $trending_product3; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="offer-multiple pb-3">
                        <div class="d-flex bd-highlight align-items-center">
                            <div class="flex-shrink-1 bd-highlight">
                                <a href="#">
                                   <img src="<?php echo e(asset($product->image)); ?>" alt="Product Photo">
                                </a>
                            </div>
                            <div class="w-100 bd-highlight">
                                <h6><?php echo e($product->title); ?></h6>
                                <span>VAR <?php echo e($product->discount_price); ?></span>
                                <span><del><?php echo e($product->price); ?></del></span>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </section>
    <!--    OFFER ALL END-->


    <!--    DISCOUNT ITEM-->
    <section class="discount-item py-5">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="section-title text-center">
                        <h4>Discount Item</h4>
                    </div>
                </div>
            </div>
            <div class="row align-items-center mt-5">
                <div class="col-12 col-md-6">
                    <div class="discount-item-text">
                        <h2>20% Discount Of All Products</h2>
                        <h6>Lorem ipsum dolor</h6>
                        <div class="py-3">
                            <p>
                                Lorem ipsum dolor sit amet, consectetur adipiscing elit. Eu eget feugiat habitasse nec, bibendum condimentum.
                            </p>
                        </div>
                        <div class="discount-item-tag d-flex flex-wrap">
                            <span>
                                <i class="far fa-check"></i>
                                Material expose like metals
                            </span>
                            <span>
                                <i class="far fa-check"></i>
                                Clear lines and geomatric figures
                            </span>
                            <span>
                                <i class="far fa-check"></i>
                                Simple neutral colours.
                            </span>
                            <span>
                                <i class="far fa-check"></i>
                                Material expose like metals
                            </span>
                        </div>
                        <div class="discount-shop mt-5">
                            <a href="#">Shop Now</a>
                        </div>
                    </div>
                </div>
                <div class="col-6 d-none d-md-block">
                    <div class="discount-img">
                       <img src="<?php echo e(asset('web')); ?>/images/products/17.png" alt="Product Image">
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--    DISCOUNT ITEM END-->

    <!--    TOP CATEGORY-->
    <section class="top-category py-5">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="section-title text-center">
                        <h4>Top Categories</h4>
                    </div>
                </div>
            </div>
            <div class="autoplay">
                <?php $__currentLoopData = $product_categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="top-category-box d-flex align-content-between flex-wrap">
                    <div class="top-cat-img w-100">
                       <img src="<?php echo e(asset($category->image)); ?>" alt="Product Photo">
                        <a href="#"><?php echo e($category->name); ?></a>
                    </div>
                    
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </section>
    <!--    TOP CATEGORY END-->

    <!--    SUBSCRIBE-->
    <section class="subscribe-section py-5" style="background: url(<?php echo e(asset('web')); ?>/images/photos/subscribe-bg.png) no-repeat center center / cover;">
        <div class="container">
            <div class="subscribe-box py-5">
                <h4>
                    Get Leatest Update By Subscribe
                    0ur Newslater
                </h4>
                <a href="#">Shop Now</a>
            </div>
        </div>
    </section>
    <!--    SUBSCRIBE-->



  <!--    PARTIES-->
  <section class="parties-section py-5">
    <div class="container-fluid">
        <div class="row">
            <div class="col-12">
                <div class="section-title text-center">
                    <h4>Related parties</h4>
                </div>
            </div>
        </div>
        <div class="marties-box custom-row d-flex align-items-center justify-content-center mt-5">
            <a href="#">
               <img src="<?php echo e(asset('web')); ?>/images/parties/1.png" alt="">
            </a>
            <a href="#">
               <img src="<?php echo e(asset('web')); ?>/images/parties/2.png" alt="">
            </a>
            <a href="#">
               <img src="<?php echo e(asset('web')); ?>/images/parties/3.png" alt="">
            </a>
            <a href="#">
               <img src="<?php echo e(asset('web')); ?>/images/parties/4.png" alt="">
            </a>
            <a href="#">
               <img src="<?php echo e(asset('web')); ?>/images/parties/5.png" alt="">
            </a>
            <a href="#">
               <img src="<?php echo e(asset('web')); ?>/images/parties/6.png" alt="">
            </a>
            <a href="#">
               <img src="<?php echo e(asset('web')); ?>/images/parties/7.png" alt="">
            </a>
            <a href="#">
               <img src="<?php echo e(asset('web')); ?>/images/parties/8.png" alt="">
            </a>
            <a href="#">
               <img src="<?php echo e(asset('web')); ?>/images/parties/9.png" alt="">
            </a>
        </div>
    </div>
</section>
<!--    PARTIES END-->


    <!--    BLOG-->
    <section class="blog py-5">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="section-title text-center">
                        <h4>Leatest Blog</h4>
                    </div>
                </div>
            </div>
            <div class="row mt-5">
                <?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-12 col-sm-6 col-md-4 pb-4">
                    <div class="blog-box d-flex align-content-between flex-wrap">
                        <div class="blog-image w-100">
                            <a href="<?php echo e(route('blog.details',$blog->slug)); ?>">
                               <img src="<?php echo e(asset($blog->image)); ?>" alt="Blog Image">
                            </a>
                        </div>
                        <div class="blog-text py-2 w-100">
                            <div class="blog-date py-2">
                                <span>
                                   <img src="<?php echo e(asset('web')); ?>/images/icons/ink.png" alt="">
                                    <?php echo e($blog->user->name ? $blog->user->name : ''); ?>

                                </span>
                                <span>
                                   <img src="<?php echo e(asset('web')); ?>/images/icons/calendar.png" alt="">
                                    <?php echo e($blog->created_at->format('d M Y')); ?>

                                </span>
                            </div>

                            <h4><?php echo e($blog->title); ?></h4>
                            


                            <a href="<?php echo e(route('blog.details',$blog->slug)); ?>">Read More</a>
                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div>
        </div>
    </section>
    <!--    BLOG END-->


<?php $__env->stopSection(); ?>


<?php echo $__env->make('web.layouts.app', ['title' => 'Home'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\halalincu\resources\views/web/homepage.blade.php ENDPATH**/ ?>