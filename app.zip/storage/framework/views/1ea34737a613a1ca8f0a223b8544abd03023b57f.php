<?php $__env->startSection('content'); ?>
    <!--start content-->
    <main class="page-content">
    <!--breadcrumb-->
    <div class="page-breadcrumb d-none d-sm-flex align-items-center py-2 px-3" style="background: rgb(46 57 78);">
        <div class="pe-3"><h5 class="text-white m-0">Order List</h5></div>

    </div>
    <!--end breadcrumb-->

    <div class="card">
        <div class="card-body">
            <div class="table-responsive mt-3">
            <table class="table align-middle">
                <thead class="table-secondary">
                <tr>
                    <th>SL#</th>
                    <th>Product_ID</th>
                    <th>Product_Name</th>


                    <th>DATE</th>
                    <th>PRICE</th>
                    <th>QTY</th>
                    <th>TOTAL_PRICE</th>
                    <th>STATUS</th>

                </tr>
                </thead>
                 <tbody>
                <?php $__currentLoopData = $product_order; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($loop->iteration); ?></td>
                    <td><?php echo e($item->product ? $item->product->id : ''); ?></td>
                    <td><?php echo e($item->product ? $item->product->name : ''); ?></td>
                    <td><?php echo e($item->created_at->format('d M Y')); ?></td>
                    <td><?php echo e($item->price); ?></td>
                    <td><?php echo e($item->qty); ?></td>
                    <td><?php echo e($item->total_price); ?></td>
                    <td>

                        <?php if($item->status == 0): ?>
                            <span class="btn btn-danger status-btn ">Cancel</span>
                        <?php elseif($item->status == 1): ?>
                        <span class="btn btn-success status-btn">Confirmed</span>
                        <?php elseif($item->status == 2): ?>
                        <span class="btn btn-warning status-btn">Pending</span>
                        <?php elseif($item->status == 3): ?>
                        <span class="btn btn-info status-btn">Processing</span>
                        <?php elseif($item->status == 4): ?>
                        <span class="btn btn-primary status-btn">Out Of Delivery</span>
                        <?php elseif($item->status == 5): ?>
                        <span class="btn btn-warning status-btn">Delivered</span>
                        <?php elseif($item->status == 6): ?>
                        <span class="btn btn-secondary status-btn">Returned</span>
                        <?php elseif($item->status == 7): ?>
                        <span class="btn btn-dark status-btn">Failed</span>

                        <?php endif; ?>

                    </td>
                    
                </tr>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </tbody>
            </table>
            </div>
        </div>
        </div>


    </main>
<!--end page main-->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('account.layouts.app',['title' => 'Product  List'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\halalincu\resources\views/account/vendor/order/userorder.blade.php ENDPATH**/ ?>