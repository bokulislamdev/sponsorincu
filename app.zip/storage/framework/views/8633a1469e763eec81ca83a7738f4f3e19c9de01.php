


<?php $__env->startSection('content'); ?>

    <!--    PAGE HEAD-->
    <section class="page-head-section text-center py-5">
        <div class="container mt-5 pt-5">
            <h2><?php echo app('translator')->get('home.contact_us'); ?></h2>
            <p>
                <a href="<?php echo e(route('homepage')); ?>">Home</a>
                <span>/</span>
                <span><?php echo app('translator')->get('home.contact_us'); ?></span>
            </p>
        </div>
    </section>
    <!--    PAGE HEAD END-->



    
        <!--    ABOUT-->
        <section class="about-section py-5">
            <div class="container">
                <div class="row">
                   <div class="col-12">
                    <h4 class="mb-5 text-center">
                        <?php echo app('translator')->get('home.get_in_touch'); ?>
                    </h4>
                   </div>
    
                    <div class="col-12">
                        <div class="contact-info">
                            <p><b><?php echo app('translator')->get('home.Phone'); ?> : </b><?php echo e($websetting->phone); ?></p>
                        <p><b><?php echo app('translator')->get('home.whats_app'); ?> : </b>  +996 0551175959</p>
                        <p><b><?php echo app('translator')->get('home.Email'); ?> : </b><?php echo e($websetting->email); ?></p>
                        <p><b><?php echo app('translator')->get('home.address'); ?> :  </b><?php echo app('translator')->get('home.address_details'); ?></p>
                        </div>
        
                    </div>
                </div>
       
    
                <div class="contact-form contact-page-form mt-5">
                    <h4 class="mb-5"><?php echo app('translator')->get('home.yout_message'); ?></h4>
                    <form action="<?php echo e(route('contact.store')); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <input type="text" placeholder="<?php echo app('translator')->get('home.Enter_Your_Name'); ?>" name="name" value="<?php echo e(old('name')); ?>">
                        <span class="text-danger"><?php echo e($errors->first('name')); ?></span>
                        <input type="text" placeholder="<?php echo app('translator')->get('home.Enter_Your_email'); ?>" name="email" value="<?php echo e(old('email')); ?>">
                        <span class="text-danger"><?php echo e($errors->first('email')); ?></span>
                        <textarea name="message" id="" cols="30" rows="10" placeholder="<?php echo app('translator')->get('home.write_yout_message'); ?>"><?php echo e(old('message')); ?></textarea>
                        <span class="text-danger"><?php echo e($errors->first('message')); ?></span>
                        <div>
                            <button type="submit"><?php echo app('translator')->get('home.yout_message'); ?></button>
                        </div>
                    </form>
                </div>
    
            </div>
        </section>
        <!--    ABOUT END-->


        <?php echo $__env->make('web.component.subscribe', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>; 

<?php $__env->stopSection(); ?>


<?php echo $__env->make('web.layouts.app', ['title' => 'Contact'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\local_server\htdocs\blaghat\resources\views/web/contact.blade.php ENDPATH**/ ?>