    <!--    BRAND SECTION-->
    <div class="section-brand-section py-5">
        <div class="container">
            <div class="row">
            <div class="section-title text-center">
                <h4>Our Business Partners</h4>
            </div>
        </div>
        </div>
        <div class="brand-section-main mt-5">
            <div class="container">
                <div class="picture_slider">
                    <div class="brand-box">
                        <a href="#">
                            <img src="{{asset('web')}}/images/brands/1.png" alt="Image">
                        </a>
                    </div>
                    <div class="brand-box">
                        <a href="#">
                            <img src="{{asset('web')}}/images/brands/2.png" alt="Image">
                        </a>
                    </div>
                    <div class="brand-box">
                        <a href="eventincu.com">
                            <img src="{{asset('web')}}/images/brands/3.png" alt="Image">
                        </a>
                    </div>
                    <div class="brand-box">
                        <a href="https://exportincu.com/">
                            <img src="{{asset('web')}}/images/brands/4.png" alt="Image">
                        </a>
                    </div>
                    <div class="brand-box">
                        <a href="#">
                            <img src="{{asset('web')}}/images/brands/5.png" alt="Image">
                        </a>
                    </div>
                    <div class="brand-box">
                        <a href="https://jobincu.com/">
                            <img src="{{asset('web')}}/images/brands/6.png" alt="Image">
                        </a>
                    </div>
                    <div class="brand-box">
                        <a href="#">
                            <img src="{{asset('web')}}/images/brands/1.png" alt="Image">
                        </a>
                    </div>
                    <div class="brand-box">
                        <a href="#">
                            <img src="{{asset('web')}}/images/brands/2.png" alt="Image">
                        </a>
                    </div>
                    <div class="brand-box">
                        <a href="#">
                            <img src="{{asset('web')}}/images/brands/3.png" alt="Image">
                        </a>
                    </div>
                    <div class="brand-box">
                        <a href="#">
                            <img src="{{asset('web')}}/images/brands/4.png" alt="Image">
                        </a>
                    </div>
                    <div class="brand-box">
                        <a href="#">
                            <img src="{{asset('web')}}/images/brands/5.png" alt="Image">
                        </a>
                    </div>
                    <div class="brand-box">
                        <a href="#">
                            <img src="{{asset('web')}}/images/brands/6.png" alt="Image">
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--    BRAND SECTION END-->